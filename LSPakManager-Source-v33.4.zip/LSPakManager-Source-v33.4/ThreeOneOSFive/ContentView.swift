import SwiftUI
import UIKit
import AVFoundation
import Combine
import UniformTypeIdentifiers
import CryptoKit
import Security
import CFNetwork
import SystemConfiguration
import Darwin

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var license: LicenseManager
    @ObservedObject private var importer = PaksImporter.shared
    @ObservedObject private var appLog = AppLog.shared

    @State private var showSettings = false
    @State private var showCleaner = false
    @State private var showPicker = false
    @State private var showGamePakList = false
    @State private var showAdvanced = false

    @StateObject private var patchStore = PatchProjectStore()
    @State private var patchOperationBusy = false
    @State private var patchMessage = "READY — SELECT A PATCH"
    @State private var aimDragEnabled = false
    @State private var aimNeckEnabled = false
    @State private var hspeitoffEnabled = false
    @State private var hyperBalamagicaEnabled = false
    @State private var aimBodyPackageEnabled = false
    @State private var aimChestPackageEnabled = false
    @State private var magicEnabled = false

    private let ticker = Timer.publish(every: 6, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack {
            AnimatedHyperBackdrop()
                .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 14) {
                    brandHeader
                    warningCard
                    kernelCard
                    quadGrid
                    switchRow
                    statsRow
                    hintLine
                    secondaryRow
                    advancedSection
                    logCard
                    developerCredits
                }
                .padding(.horizontal, 16)
                .padding(.top, 14)
                .padding(.bottom, 26)
            }

            resultPopupLayer
                .zIndex(99)
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) {
            SettingsView()
        }
        .sheet(isPresented: $showCleaner) {
            CleanerView()
        }
        .sheet(isPresented: $showPicker) {
            PakDocumentPicker { urls in
                importer.add(urls: urls)
            }
        }
        .sheet(isPresented: $showGamePakList) {
            GamePakListSheet(importer: importer)
        }
        .sheet(item: $patchStore.passwordRequest, onDismiss: patchStore.cancelUnlock) { _ in
            PatchUnlockPrompt(store: patchStore)
        }
        .onAppear {
            syncPatchStates()
            importer.refresh()
        }
        .onReceive(ticker) { _ in
            if !importer.busy && !importer.containerFound {
                importer.refresh()
            }
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active else { return }
            importer.refresh()
            guard !patchOperationBusy else { return }
            syncPatchStates()
            patchMessage = "READY — SELECT A PATCH"
        }
    }

    // MARK: - 结果弹窗（自绘浮层，不走系统 alert，保证一定弹得出来）

    private var resultPopupLayer: some View {
        Group {
            if let item = importer.pendingAlert {
                ZStack {
                    Color.black.opacity(0.66)
                        .ignoresSafeArea()
                        .onTapGesture { importer.dismissAlert() }

                    VStack(alignment: .leading, spacing: 13) {
                        HStack(spacing: 10) {
                            Image(systemName: item.success
                                  ? "checkmark.circle.fill"
                                  : "exclamationmark.triangle.fill")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundStyle(item.success ? HomeTheme.accent : HomeTheme.yellow)

                            Text(item.title)
                                .font(.system(size: 17, weight: .black, design: .rounded))
                                .foregroundStyle(.white)
                                .lineLimit(2)
                                .minimumScaleFactor(0.8)

                            Spacer(minLength: 0)
                        }

                        Text(item.message)
                            .font(.system(size: 13, weight: .medium))
                            .foregroundStyle(.white.opacity(0.88))
                            .fixedSize(horizontal: false, vertical: true)
                            .lineSpacing(3)

                        Button {
                            importer.dismissAlert()
                        } label: {
                            Text("好")
                                .font(.system(size: 14, weight: .black, design: .rounded))
                                .foregroundStyle(Color.black)
                                .frame(maxWidth: .infinity, minHeight: 42)
                                .background(
                                    HomeTheme.accent,
                                    in: RoundedRectangle(cornerRadius: 12, style: .continuous)
                                )
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(18)
                    .frame(maxWidth: 330)
                    .background(
                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                            .fill(Color(red: 0.05, green: 0.10, blue: 0.08))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                            .stroke(HomeTheme.accent.opacity(0.55), lineWidth: 1.2)
                    )
                    .shadow(color: Color.black.opacity(0.55), radius: 24, y: 10)
                    .padding(.horizontal, 30)
                }
                .transition(.opacity.combined(with: .scale(scale: 0.92)))
            }
        }
        .animation(.easeOut(duration: 0.18), value: importer.pendingAlert?.id)
    }

    // MARK: - 顶部

    private var brandHeader: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text("浪神文件管理器")
                    .font(.system(size: 22, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("PAK 注入 / 修复")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(0.6)
                    .foregroundStyle(HomeTheme.accent.opacity(0.92))
            }

            Spacer()

            Button {
                showSettings = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(HomeTheme.accent)
                    .frame(width: 44, height: 44)
                    .background(Color.black.opacity(0.34), in: Circle())
                    .overlay(Circle().stroke(HomeTheme.accent.opacity(0.45), lineWidth: 1))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("设置")
        }
    }

    private var warningCard: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(spacing: 7) {
                Text(importer.containerFound ? "✅" : "⚠️")
                    .font(.system(size: 14, weight: .bold))
                Text(warningHeadline)
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .foregroundStyle(HomeTheme.warnText)
                    .lineLimit(2)
                    .minimumScaleFactor(0.85)
                Spacer(minLength: 0)
            }

            Text("游戏内 pak/sig \(importer.paksCount) 个 · 待导入 \(importer.inboxFiles.count) 个 · 已导入 \(importer.importedFiles.count) 个")
                .font(.system(size: 10, weight: .semibold, design: .rounded))
                .foregroundStyle(HomeTheme.warnText.opacity(0.86))
                .lineLimit(2)
                .minimumScaleFactor(0.8)

            Text(appState.exploitStatus.isSuccess ? "已拿到全盘读写 → 可以直接写进游戏目录" : "这台设备没给全盘权限 → 用「改本机的包」模式")
                .font(.system(size: 10, weight: .semibold, design: .rounded))
                .foregroundStyle(HomeTheme.warnText.opacity(0.72))
                .lineLimit(2)
                .minimumScaleFactor(0.8)
        }
        .padding(.horizontal, 13)
        .padding(.vertical, 11)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(HomeTheme.warnBackground, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(HomeTheme.warnBorder, lineWidth: 1)
        )
    }

    private var warningHeadline: String {
        if importer.containerFound {
            let who = importer.matchedBundleID.isEmpty ? "" : "（\(importer.matchedBundleID)）"
            return "已拿到游戏目录\(who) —— 可以直接导入"
        }
        return "还没拿到游戏目录 —— 先点下面「一键激活内核」"
    }

    // MARK: - 内核引擎

    private var kernelCard: some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack(spacing: 8) {
                Label("内核引擎", systemImage: "bolt.fill")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .tracking(1.0)
                    .foregroundStyle(HomeTheme.accent)
                Spacer()
                Text(kernelStatusText)
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .foregroundStyle(kernelStatusColor)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 4)
                    .background(kernelStatusColor.opacity(0.14), in: Capsule())
            }

            Text(kernelSubtitle)
                .font(.system(size: 10, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.62))
                .fixedSize(horizontal: false, vertical: true)

            Button {
                appState.runKernelExploitIfNeeded()
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "bolt.fill")
                        .font(.system(size: 15, weight: .bold))
                    Text(appState.kernelExploitRunning ? "正在激活…（10~30 秒）" : "⚡ 一键激活内核 · 全盘读写")
                        .font(.system(size: 13, weight: .black, design: .rounded))
                        .lineLimit(1)
                        .minimumScaleFactor(0.75)
                    Spacer(minLength: 0)
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 14)
                .padding(.vertical, 14)
                .frame(maxWidth: .infinity)
                .background(HomeTheme.purple, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(Color.white.opacity(0.18), lineWidth: 1)
                )
            }
            .buttonStyle(.plain)
            .disabled(appState.kernelExploitRunning || appState.exploitStatus.isSuccess || !appState.isSupported)
            .opacity((appState.kernelExploitRunning || appState.exploitStatus.isSuccess || !appState.isSupported) ? 0.55 : 1)
        }
        .padding(15)
        .background(HomeTheme.card, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(HomeTheme.accent.opacity(0.30), lineWidth: 1)
        )
    }

    private var kernelStatusText: String {
        if appState.kernelExploitRunning { return "激活中…" }
        if case .success = appState.exploitStatus { return "已激活" }
        if case .failed = appState.exploitStatus { return "失败" }
        if case .unsupported = appState.exploitStatus { return "不支持本系统" }
        return "未激活"
    }

    private var kernelStatusColor: Color {
        if appState.kernelExploitRunning { return HomeTheme.yellow }
        if case .success = appState.exploitStatus { return HomeTheme.accent }
        if case .failed = appState.exploitStatus { return HomeTheme.red }
        if case .unsupported = appState.exploitStatus { return HomeTheme.red }
        return HomeTheme.yellow
    }

    private var kernelSubtitle: String {
        if appState.kernelExploitRunning {
            return "正在提权，屏幕可能会卡一下，别退出、别切后台。"
        }
        if case .success = appState.exploitStatus {
            return "内核读写和沙盒逃逸都在了，可以直接把 pak 写进游戏 Paks。"
        }
        if case .failed = appState.exploitStatus {
            return "这次没成功（漏洞有概率失败）。把 App 划掉重开，再点一次。"
        }
        if case .unsupported(let version) = appState.exploitStatus {
            return "iOS \(version) 不在内核引擎支持范围（支持 17.0–17.7 / 18.0–18.7.1 / 26.0–26.6.1 / 27 Beta）。这台机器只能用 App 内的包，写不进游戏目录。"
        }
        return "点一下，自动完成内核读写和沙盒逃逸，之后才能写进游戏目录。"
    }

    // MARK: - 四宫格

    private var quadGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
            quadCard(title: "① 注入",
                     subtitle: "待导入 \(importer.inboxFiles.count) 个",
                     systemImage: "doc.fill",
                     tint: HomeTheme.green) {
                importer.importAll()
            }

            quadCard(title: "② 修复",
                     subtitle: importer.importedFiles.isEmpty ? "还没导入过" : "已导入 \(importer.importedFiles.count) 个",
                     systemImage: "wrench.fill",
                     tint: HomeTheme.red) {
                importer.deleteImported()
            }

            quadCard(title: "③ 从手机里选文件",
                     subtitle: "选完自动进「待导入」",
                     systemImage: "iphone",
                     tint: HomeTheme.blue) {
                showPicker = true
            }

            quadCard(title: "④ 全盘找 pak",
                     subtitle: "看看游戏里都有啥",
                     systemImage: "magnifyingglass",
                     tint: HomeTheme.purple) {
                importer.refreshGamePaks()
                showGamePakList = true
            }
        }
    }

    private func quadCard(title: String, subtitle: String, systemImage: String, tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 8) {
                Image(systemName: systemImage)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 34, height: 34)
                    .background(Color.black.opacity(0.22), in: RoundedRectangle(cornerRadius: 10, style: .continuous))

                Text(title)
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.72)

                Text(subtitle)
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.82))
                    .lineLimit(1)
                    .minimumScaleFactor(0.72)
            }
            .frame(maxWidth: .infinity, minHeight: 118, alignment: .leading)
            .padding(13)
            .background(tint.opacity(0.62), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(Color.white.opacity(0.16), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .disabled(importer.busy)
        .opacity(importer.busy ? 0.55 : 1)
    }

    // MARK: - 开关行

    private var switchRow: some View {
        HStack(spacing: 9) {
            Button {
                importer.setBackup(!importer.backupEnabled)
            } label: {
                chip(title: "💾 备份：\(importer.backupEnabled ? "开" : "关")",
                     tint: importer.backupEnabled ? HomeTheme.green : Color.black.opacity(0.40))
            }
            .buttonStyle(.plain)

            Button {
                importer.setWipeBackup(!importer.wipeBackupEnabled)
            } label: {
                chip(title: "🧹 连备份删：\(importer.wipeBackupEnabled ? "开" : "关")",
                     tint: importer.wipeBackupEnabled ? HomeTheme.green.opacity(0.82) : Color.black.opacity(0.40))
            }
            .buttonStyle(.plain)

            Button {
                importer.refresh()
            } label: {
                chip(title: "🔄 刷新", tint: Color.black.opacity(0.40))
            }
            .buttonStyle(.plain)
        }
    }

    private func chip(title: String, tint: Color) -> some View {
        Text(title)
            .font(.system(size: 11, weight: .black, design: .rounded))
            .foregroundStyle(.white)
            .lineLimit(1)
            .minimumScaleFactor(0.7)
            .frame(maxWidth: .infinity, minHeight: 40)
            .padding(.horizontal, 6)
            .background(tint, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(Color.white.opacity(0.12), lineWidth: 1)
            )
    }

    // MARK: - 数字框

    private var statsRow: some View {
        HStack(spacing: 10) {
            statBox(value: importer.inboxFiles.count, title: "待导入")
            statBox(value: importer.importedFiles.count, title: "已导入")
            statBox(value: importer.paksCount, title: "游戏里的包")
        }
    }

    private func statBox(value: Int, title: String) -> some View {
        VStack(spacing: 3) {
            Text("\(value)")
                .font(.system(size: 22, weight: .black, design: .rounded))
                .foregroundStyle(HomeTheme.accent)
            Text(title)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.60))
                .lineLimit(1)
                .minimumScaleFactor(0.75)
        }
        .frame(maxWidth: .infinity, minHeight: 62)
        .background(HomeTheme.card, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(HomeTheme.accent.opacity(0.18), lineWidth: 1)
        )
    }

    private var hintLine: some View {
        Text(importerHint)
            .font(.system(size: 10, weight: .medium, design: .rounded))
            .foregroundStyle(.white.opacity(0.52))
            .multilineTextAlignment(.leading)
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var importerHint: String {
        if importer.busy { return "正在处理，别退出 App，也别切后台。" }
        if !importer.lastResult.isEmpty { return importer.lastResult }
        if importer.inboxFiles.isEmpty {
            return "待导入是空的：点「③ 从手机里选文件」，或者在文件 App 里长按 pak → 共享 → 浪神文件管理器，也会自动进来。"
        }
        return "点「注入」直接覆盖游戏里的同名原件（备份开着就先存一份），点「修复」把导进去的那几个从游戏里直接删掉，不还原原件。"
    }

    private var secondaryRow: some View {
        HStack(spacing: 9) {
            Button {
                importer.claimImported()
            } label: {
                chip(title: "📥 认领已导入的", tint: Color.black.opacity(0.40))
            }
            .buttonStyle(.plain)

            Button {
                importer.clearStaleRecords()
            } label: {
                chip(title: "🧹 清掉失效记录", tint: Color.black.opacity(0.40))
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: - 进阶（原功能全在这里）

    private var advancedSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    showAdvanced.toggle()
                }
            } label: {
                HStack(spacing: 8) {
                    Text("Aa 改字（进阶 · 跟导入无关）")
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.86))
                    Spacer()
                    Image(systemName: showAdvanced ? "chevron.up" : "chevron.down")
                        .font(.system(size: 11, weight: .black))
                        .foregroundStyle(HomeTheme.accent)
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
                .background(HomeTheme.card, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(HomeTheme.accent.opacity(0.16), lineWidth: 1)
                )
            }
            .buttonStyle(.plain)

            if showAdvanced {
                patchOptions
                gameLaunchPanel
                Button {
                    showCleaner = true
                } label: {
                    Label("清理缓存与临时文件", systemImage: "trash.slash.fill")
                        .font(.system(size: 12, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity, minHeight: 48)
                        .background(Color.black.opacity(0.42), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(HomeTheme.accent.opacity(0.34), lineWidth: 1)
                        )
                }
                .buttonStyle(.plain)
            }
        }
    }

    // MARK: - 运行记录

    private var logCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 8) {
                Label("运行记录", systemImage: "list.bullet.rectangle")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .tracking(0.8)
                    .foregroundStyle(HomeTheme.accent)
                Spacer()
                Button {
                    appLog.entries.removeAll()
                } label: {
                    Text("清空")
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.62))
                        .padding(.horizontal, 9)
                        .padding(.vertical, 4)
                        .background(Color.white.opacity(0.08), in: Capsule())
                }
                .buttonStyle(.plain)
            }

            if recentLogLines.isEmpty {
                Text("还没有记录。点上面的按钮，这里会一行一行写下来。")
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.42))
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else {
                VStack(alignment: .leading, spacing: 5) {
                    ForEach(Array(recentLogLines.enumerated()), id: \.offset) { _, line in
                        Text(line)
                            .font(.system(size: 10, weight: .medium, design: .monospaced))
                            .foregroundStyle(.white.opacity(0.70))
                            .lineLimit(2)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
            }
        }
        .padding(14)
        .background(Color.black.opacity(0.40), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(HomeTheme.accent.opacity(0.16), lineWidth: 1)
        )
    }

    private var recentLogLines: [String] {
        let tail = appLog.entries.suffix(8)
        return tail.map { line in
            if line.hasPrefix("[OGIOS] ") {
                return String(line.dropFirst(8))
            }
            return line
        }
    }

    // MARK: - 补丁（进阶区保留原功能）

    private var patchOptions: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                panelTitle("PATCH OPTIONS", icon: "bolt.fill")
                Spacer()
                Text("SELECT TO ENABLE")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }

            LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                patchCard(name: "Aim Drag", target: "FREE FIRE • NORMAL", package: "OGIOS File (6).3105", color: HomeTheme.accent, state: $aimDragEnabled)
                patchCard(name: "Aim Neck", target: "FREE FIRE • NORMAL", package: "OGIOS File (7).3105", color: HomeTheme.blue, state: $aimNeckEnabled)
                patchCard(name: "Antenna", target: "FREE FIRE • NORMAL", package: "OGIOS File (8).3105", color: HomeTheme.blue, state: $hspeitoffEnabled)
                patchCard(name: "144 FPS", target: "FREE FIRE • NORMAL", package: "OGIOS File (10).3105", color: HomeTheme.blue, state: $hyperBalamagicaEnabled)
                patchCard(name: "Aim Body", target: "FREE FIRE • NORMAL", package: "OGIOS File (12).3105", color: HomeTheme.accent, state: $aimBodyPackageEnabled)
                patchCard(name: "Aim Chest", target: "FREE FIRE • NORMAL", package: "OGIOS File (2).3105", color: HomeTheme.blue, state: $aimChestPackageEnabled)
                patchCard(name: "Magic", target: "FREE FIRE • NORMAL", package: "OGIOS File (14).3105", color: HomeTheme.accent, state: $magicEnabled)
            }

            HStack(spacing: 8) {
                Circle().fill(patchMessage.localizedCaseInsensitiveContains("successful") ? HomeTheme.accent : HomeTheme.yellow).frame(width: 7, height: 7)
                Text(patchOperationBusy ? "PROCESSING PATCH…" : patchMessage)
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))
                    .lineLimit(2)
                Spacer()
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color.black.opacity(0.34), in: Capsule())
        }
    }

    private func patchCard(name: String, target: String, package: String, color: Color, state: Binding<Bool>) -> some View {
        PatchOptionCard(name: name, target: target, color: color, isEnabled: state, isBusy: patchOperationBusy) {
            togglePatch(packageFilename: package, state: state)
        }
    }

    private var gameLaunchPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            panelTitle("LAUNCH GAME", icon: "arrow.up.forward.app.fill")
            HStack(spacing: 12) {
                launchButton(title: "FF NORMAL", subtitle: "Free Fire Normal", color: HomeTheme.accent, scheme: "freefireth")
                lockedLaunchButton(title: "FF MAX", subtitle: "Locked • Coming Soon", color: HomeTheme.blue)
            }
        }
    }

    private func launchButton(title: String, subtitle: String, color: Color, scheme: String) -> some View {
        Button { openGame(scheme: scheme) } label: {
            VStack(alignment: .leading, spacing: 7) {
                Image(systemName: "arrow.up.right.square.fill")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(color)
                Text(title)
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(subtitle)
                    .font(.system(size: 10, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.5))
            }
            .frame(maxWidth: .infinity, minHeight: 82, alignment: .leading)
            .padding(.horizontal, 14)
            .background(Color.black.opacity(0.40), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(color.opacity(0.38), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private func lockedLaunchButton(title: String, subtitle: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Image(systemName: "lock.fill")
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(color.opacity(0.72))
            Text(title)
                .font(.system(size: 13, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.72))
            Text(subtitle)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .foregroundStyle(color.opacity(0.72))
        }
        .frame(maxWidth: .infinity, minHeight: 82, alignment: .leading)
        .padding(.horizontal, 14)
        .background(Color.black.opacity(0.28), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(color.opacity(0.24), lineWidth: 1))
        .opacity(0.72)
        .accessibilityLabel("FF MAX locked, coming soon")
    }

    private func panelTitle(_ title: String, icon: String) -> some View {
        Label(title, systemImage: icon)
            .font(.system(size: 12, weight: .black, design: .rounded))
            .tracking(1.4)
            .foregroundStyle(HomeTheme.accent)
    }

    private func syncPatchStates() {
        aimDragEnabled = isPatchActive("OGIOS File (6).3105")
        aimNeckEnabled = isPatchActive("OGIOS File (7).3105")
        hspeitoffEnabled = isPatchActive("OGIOS File (8).3105")
        hyperBalamagicaEnabled = isPatchActive("OGIOS File (10).3105")
        aimBodyPackageEnabled = isPatchActive("OGIOS File (12).3105")
        aimChestPackageEnabled = isPatchActive("OGIOS File (2).3105")
        magicEnabled = isPatchActive("OGIOS File (14).3105")
    }

    private func isPatchActive(_ packageFilename: String) -> Bool {
        patchStore.items.first(where: { $0.packageURL.lastPathComponent.caseInsensitiveCompare(packageFilename) == .orderedSame })
            .flatMap { DevicePatchService.latestReceipt(projectID: $0.id) } != nil
    }

    private enum PatchActionResult {
        case applied
        case restored
        case unavailable(String)
    }

    private func setPatchState(for packageFilename: String, enabled: Bool) {
        switch packageFilename {
        case "OGIOS File (6).3105": aimDragEnabled = enabled
        case "OGIOS File (7).3105": aimNeckEnabled = enabled
        case "OGIOS File (8).3105": hspeitoffEnabled = enabled
        case "OGIOS File (10).3105": hyperBalamagicaEnabled = enabled
        case "OGIOS File (12).3105": aimBodyPackageEnabled = enabled
        case "OGIOS File (2).3105": aimChestPackageEnabled = enabled
        case "OGIOS File (14).3105": magicEnabled = enabled
        default: break
        }
    }

    private func togglePatch(packageFilename: String, state: Binding<Bool>) {
        guard !patchOperationBusy else { return }
        guard let item = patchStore.items.first(where: { $0.packageURL.lastPathComponent.caseInsensitiveCompare(packageFilename) == .orderedSame }) else {
            patchMessage = "ERROR — PACKAGE NOT FOUND"
            log("patch: package not found: \(packageFilename)")
            return
        }

        let wasEnabled = state.wrappedValue
        patchOperationBusy = true
        patchMessage = "PROCESSING — \(packageFilename)"
        let project = item.project
        let projectID = item.id

        DispatchQueue.global(qos: .userInitiated).async {
            let result: PatchActionResult
            do {
                if wasEnabled {
                    guard let receipt = DevicePatchService.latestReceipt(projectID: projectID) else {
                        result = .unavailable("NO ACTIVE RECEIPT — NOTHING TO RESTORE")
                        DispatchQueue.main.async {
                            self.setPatchState(for: packageFilename, enabled: false)
                            self.patchMessage = "OFF — NO ACTIVE PATCH FOUND"
                            self.patchOperationBusy = false
                        }
                        return
                    }
                    try DevicePatchService.restore(receipt: receipt)
                    result = .restored
                } else {
                    guard let project else {
                        result = .unavailable("PASSWORD REQUIRED — UNLOCK PACKAGE")
                        DispatchQueue.main.async {
                            self.patchStore.requestUnlock(for: item)
                            self.patchMessage = "PASSWORD REQUIRED — ENTER PACKAGE PASSWORD"
                            self.patchOperationBusy = false
                        }
                        return
                    }
                    _ = try DevicePatchService.apply(project: project)
                    result = .applied
                }
            } catch {
                result = .unavailable("FAILED — \(String(describing: error))")
            }

            DispatchQueue.main.async {
                switch result {
                case .applied:
                    self.setPatchState(for: packageFilename, enabled: true)
                    self.patchMessage = "Inject Successful — \(packageFilename)"
                    PatchAudioFeedback.bypassActivated()
                case .restored:
                    self.setPatchState(for: packageFilename, enabled: false)
                    self.patchMessage = "Restore Successful — \(packageFilename)"
                    PatchAudioFeedback.originalRestored()
                case .unavailable(let message):
                    self.patchMessage = message
                }
                self.patchOperationBusy = false
            }
        }
    }

    private func openGame(scheme: String) {
        guard let url = URL(string: "\(scheme)://") else { return }
        UIApplication.shared.open(url, options: [:]) { success in
            log("launch: \(scheme) success=\(success)")
        }
    }

    private var developerCredits: some View {
        Text("浪神文件管理器 · 内核引擎来自 OGIOS")
            .font(.system(size: 10, weight: .bold, design: .rounded))
            .foregroundStyle(.white.opacity(0.55))
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
            .padding(.top, 4)
    }
}

// MARK: - 首页配色

enum HomeTheme {
    static let accent = Color(red: 0.38, green: 0.88, blue: 1.00)
    static let green = Color(red: 0.30, green: 0.72, blue: 1.00)
    static let red = Color(red: 0.90, green: 0.36, blue: 0.42)
    static let blue = Color(red: 0.30, green: 0.62, blue: 1.00)
    static let purple = Color(red: 0.58, green: 0.52, blue: 1.00)
    static let yellow = Color(red: 0.98, green: 0.80, blue: 0.42)
    static let card = Color(red: 0.02, green: 0.06, blue: 0.12).opacity(0.80)
    static let warnBackground = Color(red: 0.85, green: 0.66, blue: 0.16).opacity(0.22)
    static let warnBorder = Color(red: 0.96, green: 0.78, blue: 0.29).opacity(0.55)
    static let warnText = Color(red: 0.99, green: 0.90, blue: 0.62)
}

// MARK: - 游戏内 pak 列表

struct GamePakListSheet: View {
    @ObservedObject var importer: PaksImporter
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Group {
                if importer.gamePaks.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "shippingbox")
                            .font(.system(size: 30, weight: .medium))
                            .foregroundStyle(.secondary)
                        Text(importer.containerFound ? "游戏 Paks 里还没有 pak" : "还没定位到游戏目录")
                            .font(.headline)
                        Text(importer.containerFound
                             ? "先启动一次游戏，让它生成 Paks 目录，再回来点刷新。"
                             : "先回首页点「⚡ 一键激活内核」，状态变绿之后再点④。")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding(28)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        Section {
                            ForEach(importer.gamePaks) { pak in
                                HStack(spacing: 10) {
                                    Image(systemName: "doc.fill")
                                        .foregroundStyle(HomeTheme.accent)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(pak.name)
                                            .font(.system(size: 13, weight: .semibold))
                                            .lineLimit(1)
                                        Text(pak.sizeText)
                                            .font(.system(size: 10, weight: .medium))
                                            .foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    if importer.importedFiles.contains(pak.name) {
                                        Text("我导入的")
                                            .font(.system(size: 9, weight: .bold))
                                            .foregroundStyle(HomeTheme.accent)
                                            .padding(.horizontal, 7)
                                            .padding(.vertical, 3)
                                            .background(HomeTheme.accent.opacity(0.14), in: Capsule())
                                    }
                                }
                            }
                        } footer: {
                            Text("共 \(importer.gamePaks.count) 个文件 · \(importer.matchedBundleID)")
                        }
                    }
                }
            }
            .navigationTitle("游戏里的包")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("关闭") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("刷新") { importer.refreshGamePaks() }
                }
            }
        }
    }
}

// MARK: - 补丁卡片

private struct PatchOptionCard: View {
    let name: String
    let target: String
    let color: Color
    @Binding var isEnabled: Bool
    let isBusy: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 11) {
                HStack {
                    Image(systemName: "bolt.fill")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(color)
                    Spacer()
                    Circle()
                        .fill(isEnabled ? color : Color.white.opacity(0.20))
                        .frame(width: 9, height: 9)
                }
                Text(name)
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(target)
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
                Text(isEnabled ? "ON" : "OFF")
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .foregroundStyle(isEnabled ? color : Color.white.opacity(0.35))
            }
            .frame(maxWidth: .infinity, minHeight: 142, alignment: .leading)
            .padding(14)
            .background(Color.black.opacity(0.52), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(isEnabled ? color.opacity(0.85) : color.opacity(0.28), lineWidth: isEnabled ? 1.5 : 1))
            .shadow(color: isEnabled ? color.opacity(0.20) : .clear, radius: 12)
        }
        .buttonStyle(.plain)
        .disabled(isBusy)
        .opacity(isBusy ? 0.55 : 1)
        .accessibilityLabel("\(name), \(target), \(isEnabled ? "On" : "Off")")
    }
}

private struct PatchUnlockPrompt: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField("Package password", text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                        .onChange(of: password) { _ in store.clearUnlockError() }
                    if let errorKey = store.unlockErrorKey {
                        Text(AppLanguage.english.text(errorKey))
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }
                } footer: {
                    Text("Enter the password once to unlock this OGIOS package on this device.")
                }
            }
            .navigationTitle("Unlock package")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Unlock", action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

struct AnimatedHyperBackdrop: View {
    @State private var animate = false
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                AppTheme.pageBackground
                Circle()
                    .fill(HomeTheme.accent.opacity(0.10))
                    .frame(width: 280, height: 280)
                    .blur(radius: 70)
                    .offset(x: animate ? 120 : -120, y: -proxy.size.height * 0.23)
                Circle()
                    .fill(HomeTheme.blue.opacity(0.10))
                    .frame(width: 260, height: 260)
                    .blur(radius: 80)
                    .offset(x: animate ? -100 : 100, y: proxy.size.height * 0.22)
                GridOverlay()
            }
            .onAppear {
                withAnimation(.easeInOut(duration: 7).repeatForever(autoreverses: true)) { animate = true }
            }
        }
    }
}

private struct GridOverlay: View {
    var body: some View {
        Canvas { context, size in
            var path = Path()
            let spacing: CGFloat = 44
            stride(from: CGFloat(0), through: size.width, by: spacing).forEach { x in
                path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height))
            }
            stride(from: CGFloat(0), through: size.height, by: spacing).forEach { y in
                path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y))
            }
            context.stroke(path, with: .color(HomeTheme.accent.opacity(0.05)), lineWidth: 1)
        }
    }
}

// MARK: - 文件选择器

struct PakDocumentPicker: UIViewControllerRepresentable {
    var onPick: ([URL]) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick)
    }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let pakType = UTType(filenameExtension: "pak") ?? UTType.data
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [pakType, .data], asCopy: true)
        picker.allowsMultipleSelection = true
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        private let onPick: ([URL]) -> Void

        init(onPick: @escaping ([URL]) -> Void) {
            self.onPick = onPick
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            onPick(urls)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {}
    }
}

// MARK: - 和平精英 Paks 一键导入 / 删除

struct GamePak: Identifiable, Equatable {
    let id: String
    let name: String
    let size: Int64

    var sizeText: String {
        if size >= 1_048_576 {
            return String(format: "%.1f MB", Double(size) / 1_048_576.0)
        }
        if size >= 1024 {
            return String(format: "%.0f KB", Double(size) / 1024.0)
        }
        return "\(size) B"
    }
}

// MARK: - 导入 / 修复 结果弹窗

struct PaksAlert: Identifiable {
    let id = UUID()
    let title: String
    let message: String
    var success: Bool = true
}

final class PaksImporter: ObservableObject {
    static let shared = PaksImporter()

    @Published var inboxFiles: [String] = []
    @Published var importedFiles: [String] = []
    @Published var gamePaks: [GamePak] = []
    @Published var busy = false
    @Published var statusText = "待机"
    @Published var containerFound = false
    @Published var matchedBundleID = ""
    @Published var paksCount = 0
    @Published var lastResult = ""
    @Published var pendingAlert: PaksAlert?
    @Published var backupEnabled = true
    @Published var wipeBackupEnabled = true

    private let fm = FileManager.default
    private static let recordFileName = "imported-paks.json"
    private static let inboxFolderName = "PakInbox"
    private static let backupFolderName = "PakBackup"
    private static let backupKey = "ls.paks.backup"
    private static let wipeBackupKey = "ls.paks.wipebackup"

    private init() {
        let defaults = UserDefaults.standard
        if defaults.object(forKey: Self.backupKey) != nil {
            backupEnabled = defaults.bool(forKey: Self.backupKey)
        }
        if defaults.object(forKey: Self.wipeBackupKey) != nil {
            wipeBackupEnabled = defaults.bool(forKey: Self.wipeBackupKey)
        }
    }

    // MARK: - 弹窗控制（自绘浮层）

    func dismissAlert() {
        pendingAlert = nil
    }

    func showAlert(_ title: String, _ message: String, success: Bool = true) {
        DispatchQueue.main.async {
            self.pendingAlert = PaksAlert(title: title, message: message, success: success)
            UINotificationFeedbackGenerator().notificationOccurred(success ? .success : .warning)
        }
    }

    private static var documentsURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
    }

    private static var recordsURL: URL {
        documentsURL.appendingPathComponent(recordFileName)
    }

    private static var inboxURL: URL {
        documentsURL.appendingPathComponent(inboxFolderName, isDirectory: true)
    }

    private static var backupURL: URL {
        documentsURL.appendingPathComponent(backupFolderName, isDirectory: true)
    }

    // 和平精英各服包名，按顺序试
    private static let candidateBundleIDs: [String] = [
        "com.tencent.tmgp.pubgmhd",
        "com.tencent.tmgp.pubgm",
        "com.tencent.ig",
        "com.rekoo.pubgm",
        "com.pubg.krmobile",
        "com.vng.pubgmobile",
        "com.tencent.tmgp.pubgmhd.dev"
    ]

    // MARK: - 开关

    func setBackup(_ on: Bool) {
        backupEnabled = on
        UserDefaults.standard.set(on, forKey: Self.backupKey)
    }

    func setWipeBackup(_ on: Bool) {
        wipeBackupEnabled = on
        UserDefaults.standard.set(on, forKey: Self.wipeBackupKey)
    }

    // MARK: - 外部递进来的文件（文件 App → 打开方式 / 共享）

    static func handles(_ url: URL) -> Bool {
        let ext = url.pathExtension.lowercased()
        return ext == "pak" || ext == "sig"
    }

    func ingestExternal(url: URL) {
        log("external: 收到文件 App 递进来的 \(url.lastPathComponent)")
        add(urls: [url])
        lastResult = "文件 App 递进来 \(url.lastPathComponent)，已放进「待导入」"
        statusText = lastResult
    }

    // MARK: - 状态刷新

    func refresh() {
        DispatchQueue.global(qos: .userInitiated).async {
            let names = self.scanPakFiles()
            let records = self.loadRecords()
            let container = self.resolveContainer()
            var count = 0
            var paks: [GamePak] = []
            if let container = container {
                let paksPath = self.paksPath(for: container.path)
                let handle = ContainerStore.grantContainerAccess(container.path)
                paks = self.listGamePaks(at: paksPath)
                count = paks.count
                if handle >= 0 { bad_query_release(handle) }
            }
            DispatchQueue.main.async {
                self.inboxFiles = names
                self.importedFiles = records
                self.containerFound = container != nil
                self.matchedBundleID = container?.id ?? ""
                self.paksCount = count
                self.gamePaks = paks
            }
        }
    }

    func refreshGamePaks() {
        DispatchQueue.global(qos: .userInitiated).async {
            guard let container = self.resolveContainer() else {
                DispatchQueue.main.async {
                    self.containerFound = false
                    self.gamePaks = []
                    self.paksCount = 0
                    self.lastResult = "没定位到游戏容器：先点「⚡ 一键激活内核」，或者先启动一次游戏。"
                }
                return
            }
            let path = self.paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            let paks = self.listGamePaks(at: path)
            if handle >= 0 { bad_query_release(handle) }
            log("paks: 扫描游戏 Paks，找到 \(paks.count) 个文件")
            DispatchQueue.main.async {
                self.containerFound = true
                self.matchedBundleID = container.id
                self.gamePaks = paks
                self.paksCount = paks.count
                self.lastResult = "游戏 Paks 里现在有 \(paks.count) 个文件"
            }
        }
    }

    // MARK: - 低系统档：不碰内核，直接验能不能写进游戏 Paks

    func probeGameWriteAccess() -> (ok: Bool, message: String) {
        guard let container = resolveContainer() else {
            return (false, "没定位到游戏容器，先打开一次游戏再回来点这个按钮。")
        }
        let paks = paksPath(for: container.path)
        let handle = ContainerStore.grantContainerAccess(container.path)
        defer { if handle >= 0 { bad_query_release(handle) } }

        if !fm.fileExists(atPath: paks) {
            do {
                try fm.createDirectory(atPath: paks, withIntermediateDirectories: true)
            } catch {
                return (false, "Paks 目录不存在，也建不出来（\(error.localizedDescription)）。")
            }
        }

        let probe = paks + "/.ls_probe_\(Int(Date().timeIntervalSince1970)).tmp"
        do {
            try Data("ls".utf8).write(to: URL(fileURLWithPath: probe))
            try? fm.removeItem(atPath: probe)
            return (true, "游戏 Paks 可读写，这档不用跑内核。")
        } catch {
            return (false, "游戏 Paks 写不进去（\(error.localizedDescription)）。")
        }
    }

    // MARK: - 添加文件

    func add(urls: [URL]) {
        LSIntegrity.enforce("pak.add")
        guard !urls.isEmpty else { return }
        try? fm.createDirectory(at: Self.inboxURL, withIntermediateDirectories: true)
        for url in urls {
            let destination = Self.inboxURL.appendingPathComponent(url.lastPathComponent)
            let scoped = url.startAccessingSecurityScopedResource()
            if fm.fileExists(atPath: destination.path) {
                try? fm.removeItem(at: destination)
            }
            do {
                try fm.copyItem(at: url, to: destination)
                log("paks: 已添加到待导入 \(url.lastPathComponent)")
            } catch {
                log("paks: 添加失败 \(url.lastPathComponent) — \(error.localizedDescription)")
            }
            if scoped { url.stopAccessingSecurityScopedResource() }
        }
        refresh()
        statusText = "已添加到 App"
    }

    // MARK: - 一键导入（覆盖原件）

    func importAll() {
        LSIntegrity.enforce("pak.inject")
        guard !busy else { return }
        let files = inboxFiles
        guard !files.isEmpty else {
            statusText = "先添加 pak 文件"
            lastResult = "待导入是空的：先点「检查更新」从云端拉最新包，下载完再点「注入」。"
            showAlert(
                "还没有下载新包",
                "待导入列表现在是空的。先点「检查更新」把最新的 pak / sig 拉到 App 里，下载完再点「注入」。",
                success: false
            )
            return
        }
        busy = true
        statusText = "正在导入…"
        lastResult = ""

        DispatchQueue.global(qos: .userInitiated).async {
            guard let container = self.resolveContainer() else {
                DispatchQueue.main.async {
                    self.busy = false
                    self.statusText = "没找到和平精英"
                    self.lastResult = "没定位到游戏容器：先点「⚡ 一键激活内核」，或打开一次游戏再回来刷新。"
                    self.showAlert(
                        "注入失败",
                        "没定位到和平精英的游戏目录。先点上面的「⚡ 一键激活内核」，或者打开一次游戏再回来点「注入」。",
                        success: false
                    )
                }
                log("paks: 容器解析失败")
                return
            }

            let paks = self.paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            if !self.fm.fileExists(atPath: paks) {
                do {
                    try self.fm.createDirectory(atPath: paks, withIntermediateDirectories: true)
                } catch {
                    log("paks: 创建 Paks 目录失败 \(error.localizedDescription)")
                }
            }

            var done: [String] = []
            var failed: [String] = []
            for name in files {
                guard let source = self.findFile(named: name) else {
                    failed.append(name)
                    continue
                }
                let destination = paks + "/" + name
                if self.backupEnabled {
                    self.backupOriginal(at: destination, name: name)
                }
                do {
                    try self.installCopy(from: source, to: destination)
                    done.append(name)
                    log("paks: 已覆盖 \(name)")
                } catch {
                    failed.append(name)
                    log("paks: 导入失败 \(name) — \(error.localizedDescription)")
                }
            }

            if handle >= 0 { bad_query_release(handle) }

            var records = self.loadRecords()
            for name in done where !records.contains(name) {
                records.append(name)
            }
            self.saveRecords(records)

            let summary: String
            if done.isEmpty {
                summary = "一个都没导进去（失败 \(failed.count) 个）"
            } else if failed.isEmpty {
                summary = "已导入 \(done.count) 个，游戏里的原件已覆盖"
            } else {
                summary = "注入 \(done.count) 个，失败 \(failed.count) 个"
            }

            DispatchQueue.main.async {
                self.busy = false
                self.statusText = summary
                self.lastResult = failed.isEmpty ? summary : summary + "｜失败：" + failed.joined(separator: "、")
                self.importedFiles = records
                if !done.isEmpty {
                    CloudUpdater.shared.commitAfterImport()
                    if failed.isEmpty {
                        self.showAlert(
                            "注入成功",
                            "已导入 \(done.count) 个文件，游戏里的原件已经覆盖，进游戏就是新内容。"
                        )
                    } else {
                        self.showAlert(
                            "注入完成，有失败",
                            "已导入 \(done.count) 个，\(failed.count) 个没成功：\n" + failed.joined(separator: "、") + "\n\n没成功的可以再点一次「注入」重试。",
                            success: false
                        )
                    }
                } else {
                    self.showAlert(
                        "注入失败",
                        "一个都没导进去（失败 \(failed.count) 个）：\n" + failed.joined(separator: "、") + "\n\n先确认「⚡ 一键激活内核」是已激活，再点一次「注入」。",
                        success: false
                    )
                }
                self.refresh()
            }
        }
    }

    // MARK: - 一键修复（直接删掉导入的文件，不还原原件）

    func deleteImported() {
        guard !busy else { return }
        let names = importedFiles
        guard !names.isEmpty else {
            statusText = "还没有导入记录"
            lastResult = "还没导入过东西：先点「注入」。"
            showAlert(
                "没有可修复的文件",
                "现在还没有导入记录，没有东西可以删。先点「注入」，导进去之后再点「修复」，就会把导进去的文件从游戏里直接删掉。",
                success: false
            )
            return
        }
        busy = true
        statusText = "正在修复…"
        lastResult = ""

        DispatchQueue.global(qos: .userInitiated).async {
            guard let container = self.resolveContainer() else {
                DispatchQueue.main.async {
                    self.busy = false
                    self.statusText = "没找到和平精英"
                    self.lastResult = "没定位到游戏容器：先点「⚡ 一键激活内核」，或打开一次游戏再回来刷新。"
                    self.showAlert(
                        "修复失败",
                        "没定位到和平精英的游戏目录。先点上面的「⚡ 一键激活内核」，或者打开一次游戏再回来点「修复」。",
                        success: false
                    )
                }
                return
            }

            let paks = self.paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            var removed: [String] = []
            var failed: [String] = []

            for name in names {
                let path = paks + "/" + name
                var succeeded = false
                if self.fm.fileExists(atPath: path) {
                    do {
                        try self.fm.removeItem(atPath: path)
                        removed.append(name)
                        succeeded = true
                        log("paks: 已从游戏里删除 \(name)")
                    } catch {
                        failed.append(name)
                        log("paks: 删除失败 \(name) — \(error.localizedDescription)")
                    }
                } else {
                    removed.append(name)
                    succeeded = true
                }

                if succeeded && self.wipeBackupEnabled {
                    self.deleteBackup(name: name)
                }
            }

            if handle >= 0 { bad_query_release(handle) }

            let keep = names.filter { !removed.contains($0) }
            self.saveRecords(keep)

            let summary = failed.isEmpty
                ? "已把 \(removed.count) 个文件从游戏里删掉"
                : "删掉 \(removed.count) 个，失败 \(failed.count) 个"

            DispatchQueue.main.async {
                self.busy = false
                self.statusText = summary
                self.lastResult = failed.isEmpty ? summary : summary + "｜失败：" + failed.joined(separator: "、")
                self.importedFiles = keep
                if !removed.isEmpty {
                    if failed.isEmpty {
                        self.showAlert(
                            "修复成功",
                            "已把 \(removed.count) 个文件从游戏里直接删掉，没有还原原件，游戏里现在没有这些文件了。"
                        )
                    } else {
                        self.showAlert(
                            "修复完成，有失败",
                            "已删掉 \(removed.count) 个，\(failed.count) 个没删成功：\n" + failed.joined(separator: "、"),
                            success: false
                        )
                    }
                } else {
                    self.showAlert(
                        "修复失败",
                        "一个都没删掉（失败 \(failed.count) 个）：\n" + failed.joined(separator: "、") + "\n\n先确认「⚡ 一键激活内核」是已激活，再点一次「修复」。",
                        success: false
                    )
                }
                self.refresh()
            }
        }
    }

    // MARK: - v33.4 · 单文件删除（注入列表里点垃圾桶）

    /// 待确认删除的目标：「inbox|文件名」或「game|文件名」
    @Published var pendingDelete: String?

    func requestDelete(_ name: String, inbox: Bool) {
        guard !busy else { return }
        let token = (inbox ? "inbox|" : "game|") + name
        pendingDelete = token
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        // 4 秒没点第二下就自动收回，别一直挂在确认态
        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
            if self.pendingDelete == token { self.pendingDelete = nil }
        }
    }

    func cancelDelete() {
        pendingDelete = nil
    }

    /// 点第二下才真删
    func confirmPendingDelete() {
        guard let target = pendingDelete else { return }
        pendingDelete = nil
        let parts = target.split(separator: "|", maxSplits: 1, omittingEmptySubsequences: false)
        guard parts.count == 2 else { return }
        let name = String(parts[1])
        if parts[0] == "inbox" {
            deleteInboxFile(name)
        } else {
            deleteImportedFile(name)
        }
    }

    /// pak 和 sig 是配套的，删一个就连名一起删
    private func pairedNames(of name: String) -> [String] {
        let ns = name as NSString
        let base = ns.deletingPathExtension
        let ext = ns.pathExtension.lowercased()
        if ext == "pak" { return [name, base + ".sig"] }
        if ext == "sig" { return [name, base + ".pak"] }
        return [name]
    }

    /// 待导入：直接从 App 里删掉这个文件
    func deleteInboxFile(_ name: String) {
        guard !busy else { return }
        busy = true
        statusText = "正在删除…"
        DispatchQueue.global(qos: .userInitiated).async {
            var gone: [String] = []
            var failed: [String] = []
            for n in self.pairedNames(of: name) {
                let path = Self.inboxURL.appendingPathComponent(n).path
                guard self.fm.fileExists(atPath: path) else { continue }
                do {
                    try self.fm.removeItem(atPath: path)
                    gone.append(n)
                    log("paks: 已从待导入删除 \(n)")
                } catch {
                    failed.append(n)
                    log("paks: 待导入删除失败 \(n) — \(error.localizedDescription)")
                }
            }
            DispatchQueue.main.async {
                self.busy = false
                let summary: String
                if failed.isEmpty {
                    summary = gone.isEmpty ? "文件已经不在了" : "已从待导入删掉 " + gone.joined(separator: "、")
                } else {
                    summary = "删掉 \(gone.count) 个，" + failed.joined(separator: "、") + " 没删成功"
                }
                self.statusText = summary
                self.lastResult = summary
                self.refresh()
            }
        }
    }

    /// 已导入：从游戏 Paks 里单独删掉这个文件，并从记录里划掉
    func deleteImportedFile(_ name: String) {
        guard !busy else { return }
        busy = true
        statusText = "正在从游戏里删除…"
        DispatchQueue.global(qos: .userInitiated).async {
            var gone: [String] = []
            var failed: [String] = []
            var noContainer = false
            if let container = self.resolveContainer() {
                let paks = self.paksPath(for: container.path)
                let handle = ContainerStore.grantContainerAccess(container.path)
                for n in self.pairedNames(of: name) {
                    let path = paks + "/" + n
                    guard self.fm.fileExists(atPath: path) else { continue }
                    do {
                        try self.fm.removeItem(atPath: path)
                        gone.append(n)
                        if self.wipeBackupEnabled { self.deleteBackup(name: n) }
                        log("paks: 已从游戏里删除 \(n)")
                    } catch {
                        failed.append(n)
                        log("paks: 删除失败 \(n) — \(error.localizedDescription)")
                    }
                }
                if handle >= 0 { bad_query_release(handle) }
            } else {
                noContainer = true
            }
            var records = self.loadRecords()
            let pair = self.pairedNames(of: name)
            records.removeAll { pair.contains($0) }
            self.saveRecords(records)

            DispatchQueue.main.async {
                self.busy = false
                self.importedFiles = records
                let summary: String
                if noContainer {
                    summary = "没定位到游戏目录：先点「⚡ 一键激活内核」再删"
                } else if failed.isEmpty {
                    summary = gone.isEmpty ? "游戏里已经没有这个文件了" : "已从游戏里删掉 " + gone.joined(separator: "、")
                } else {
                    summary = "删掉 \(gone.count) 个，" + failed.joined(separator: "、") + " 没删成功"
                }
                self.statusText = summary
                self.lastResult = summary
                self.refresh()
            }
        }
    }

    // MARK: - 认领 / 清记录

    func claimImported() {
        DispatchQueue.global(qos: .userInitiated).async {
            guard let container = self.resolveContainer() else {
                DispatchQueue.main.async {
                    self.lastResult = "没定位到游戏目录，先激活内核。"
                }
                return
            }
            let paks = self.paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            let inside = Set(self.listGamePaks(at: paks).map { $0.name })
            if handle >= 0 { bad_query_release(handle) }

            let inbox = Set(self.scanPakFiles())
            var records = self.loadRecords()
            var added: [String] = []
            for name in inside where inbox.contains(name) && !records.contains(name) {
                records.append(name)
                added.append(name)
            }
            self.saveRecords(records)
            log("paks: 认领 \(added.count) 个已导入文件")

            DispatchQueue.main.async {
                self.importedFiles = records
                self.lastResult = added.isEmpty
                    ? "没有可认领的（游戏里没有和待导入同名的包）"
                    : "认领了 \(added.count) 个：" + added.joined(separator: "、")
                self.refresh()
            }
        }
    }

    func clearStaleRecords() {
        DispatchQueue.global(qos: .userInitiated).async {
            let records = self.loadRecords()
            guard let container = self.resolveContainer() else {
                DispatchQueue.main.async {
                    self.lastResult = "没定位到游戏目录，先激活内核。"
                }
                return
            }
            let paks = self.paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            let inside = Set(self.listGamePaks(at: paks).map { $0.name })
            if handle >= 0 { bad_query_release(handle) }

            let keep = records.filter { inside.contains($0) }
            let dropped = records.count - keep.count
            self.saveRecords(keep)
            log("paks: 清掉 \(dropped) 条失效记录")

            DispatchQueue.main.async {
                self.importedFiles = keep
                self.lastResult = dropped == 0 ? "没有失效记录" : "清掉了 \(dropped) 条失效记录"
                self.refresh()
            }
        }
    }

    // MARK: - 内部

    private func paksPath(for container: String) -> String {
        container + "/Documents/ShadowTrackerExtra/Saved/Paks"
    }

    private func listGamePaks(at path: String) -> [GamePak] {
        guard let names = try? fm.contentsOfDirectory(atPath: path) else { return [] }
        var list: [GamePak] = []
        for name in names {
            let lowered = name.lowercased()
            guard lowered.hasSuffix(".pak") || lowered.hasSuffix(".sig") else { continue }
            let full = path + "/" + name
            let attrs = try? fm.attributesOfItem(atPath: full)
            let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
            list.append(GamePak(id: name, name: name, size: size))
        }
        return list.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }

    private func backupOriginal(at destination: String, name: String) {
        guard fm.fileExists(atPath: destination) else { return }
        try? fm.createDirectory(at: Self.backupURL, withIntermediateDirectories: true)
        let target = Self.backupURL.appendingPathComponent(name)
        guard !fm.fileExists(atPath: target.path) else { return }
        do {
            try fm.copyItem(atPath: destination, toPath: target.path)
            log("paks: 已备份原件 \(name)")
        } catch {
            log("paks: 备份原件失败 \(name) — \(error.localizedDescription)")
        }
    }

    private func deleteBackup(name: String) {
        let backup = Self.backupURL.appendingPathComponent(name)
        guard fm.fileExists(atPath: backup.path) else { return }
        do {
            try fm.removeItem(at: backup)
            log("paks: 已删掉备份 \(name)")
        } catch {
            log("paks: 删备份失败 \(name) — \(error.localizedDescription)")
        }
    }

    private func resolveContainer() -> (id: String, path: String)? {
        for bundleID in Self.candidateBundleIDs {
            if let path = ContainerStore.resolveAppContainerPath(bundleID: bundleID) {
                return (bundleID, path)
            }
        }

        var enumerationError: NSString?
        let identifiers = MCMEnumerateIdentifiersForClass(2, 4_096, &enumerationError)
        for identifier in identifiers {
            let lowered = identifier.lowercased()
            guard lowered.contains("pubg") || lowered.contains("tmgp") || lowered.contains("rekoo") else { continue }
            if let path = ContainerStore.resolveAppContainerPath(bundleID: identifier) {
                return (identifier, path)
            }
        }

        // 兜底：直接扫容器元数据（MCM 拒绝时走这条）
        let apps = ContainerStore.containersFromFilesystem()
        for app in apps {
            let lowered = app.bundleID.lowercased()
            let isGame = Self.candidateBundleIDs.contains(app.bundleID)
                || lowered.contains("pubg")
                || lowered.contains("tmgp")
                || lowered.contains("rekoo")
            if isGame {
                return (app.bundleID, app.containerPath)
            }
        }
        return nil
    }

    private func scanPakFiles() -> [String] {
        var names: [String] = []
        guard let enumerator = fm.enumerator(
            at: Self.documentsURL,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        ) else {
            return names
        }
        for case let url as URL in enumerator {
            let ext = url.pathExtension.lowercased()
            guard ext == "pak" || ext == "sig" else { continue }
            guard !url.path.contains(Self.backupFolderName) else { continue }
            names.append(url.lastPathComponent)
        }
        return Array(Set(names)).sorted()
    }

    private func findFile(named name: String) -> URL? {
        let inbox = Self.inboxURL.appendingPathComponent(name)
        if fm.fileExists(atPath: inbox.path) { return inbox }
        guard let enumerator = fm.enumerator(
            at: Self.documentsURL,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        ) else {
            return nil
        }
        for case let url as URL in enumerator where url.lastPathComponent == name {
            guard !url.path.contains(Self.backupFolderName) else { continue }
            return url
        }
        return nil
    }

    private func installCopy(from source: URL, to destination: String) throws {
        let temporary = destination + ".tmp-" + String(UUID().uuidString.prefix(8))
        if fm.fileExists(atPath: temporary) {
            try? fm.removeItem(atPath: temporary)
        }
        do {
            try fm.copyItem(at: source, to: URL(fileURLWithPath: temporary))
        } catch {
            // 临时文件占双倍空间，空间紧时退回「先腾位再直写」
            if fm.fileExists(atPath: destination) {
                try? fm.removeItem(atPath: destination)
            }
            try fm.copyItem(at: source, to: URL(fileURLWithPath: destination))
            return
        }

        if fm.fileExists(atPath: destination) {
            do {
                _ = try fm.replaceItemAt(
                    URL(fileURLWithPath: destination),
                    withItemAt: URL(fileURLWithPath: temporary),
                    backupItemName: nil,
                    options: []
                )
                return
            } catch {
                try? fm.removeItem(atPath: destination)
            }
        }
        try fm.moveItem(atPath: temporary, toPath: destination)
    }

    private func loadRecords() -> [String] {
        guard let data = try? Data(contentsOf: Self.recordsURL),
              let list = try? JSONDecoder().decode([String].self, from: data) else {
            return []
        }
        return list
    }

    private func saveRecords(_ names: [String]) {
        guard let data = try? JSONEncoder().encode(names) else { return }
        try? data.write(to: Self.recordsURL)
    }

    /// 云端更新用：把「上一版有、这一版没有」的旧包，从游戏 Paks 和待导入区一起清掉
    func removeFromGameAndInbox(names: [String]) -> [String] {
        guard !names.isEmpty else { return [] }
        var removed: [String] = []

        if let container = resolveContainer() {
            let paks = paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            for name in names {
                let path = paks + "/" + name
                if fm.fileExists(atPath: path) {
                    do {
                        try fm.removeItem(atPath: path)
                        removed.append(name)
                        log("cloud: 已清掉旧包 \(name)")
                    } catch {
                        log("cloud: 旧包删不掉 \(name) — \(error.localizedDescription)")
                    }
                }
            }
            if handle >= 0 { bad_query_release(handle) }
        }

        for name in names {
            try? fm.removeItem(at: Self.inboxURL.appendingPathComponent(name))
        }

        if !removed.isEmpty {
            let records = loadRecords().filter { !removed.contains($0) }
            saveRecords(records)
            DispatchQueue.main.async { self.importedFiles = records }
        }
        return removed
    }
}

// MARK: - 一页版 · 首页（浪神文件管理器）

/// 两个版本档：低系统 / 高系统。区间就是巨魔能装的边界。
enum PakTier: String, CaseIterable {
    case low
    case high

    var title: String {
        switch self {
        case .low: return "低系统版本"
        case .high: return "高系统版本"
        }
    }

    var range: String {
        switch self {
        case .low: return "iOS 14.0 – 16.6.1"
        case .high: return "iOS 17.0 – 26.6.2"
        }
    }

    var note: String {
        switch self {
        case .low: return "巨魔直装 · 不碰内核"
        case .high: return "内核自适应 · 现场校准"
        }
    }

    var icon: String {
        switch self {
        case .low: return "shippingbox.fill"
        case .high: return "bolt.shield.fill"
        }
    }
}

enum TierState: Equatable {
    case idle
    case running
    case ok
    case fail

    var text: String {
        switch self {
        case .idle: return "未试"
        case .running: return "检测中"
        case .ok: return "已打通"
        case .fail: return "未通"
        }
    }
}

/// v34.0 · 第一帧只画这一层：品牌色 + 包内的静态首帧图。
/// 纯 Color + Image，没有播放器、没有列表、没有壁纸解码，
/// 系统启动屏一撤就能立刻接上画面，不会再让人对着纯色干等。
struct StaticLaunchBackdrop: View {
    var body: some View {
        GeometryReader { geo in
            let w = max(geo.size.width, 1)
            let h = max(geo.size.height, 1)
            let wide = (w / h) > (9.0 / 16.0) * 1.25
            ZStack {
                Color(red: 0x06 / 255.0, green: 0x14 / 255.0, blue: 0x0C / 255.0)
                Image(wide ? "SplashFirstWide" : "SplashFirst")
                    .resizable()
                    .scaledToFill()
                    .frame(width: w, height: h)
                    .clipped()
            }
            .frame(width: w, height: h)
        }
        .ignoresSafeArea()
    }
}

/// v34.0 · 启动片视频层：第一帧提交之后才挂上来，AVPlayer 不参与首帧
struct SplashOpeningVideoLayer: View {
    var body: some View {
        SplashVideoBackground()
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .ignoresSafeArea()
    }
}

struct RootGateView: View {
    @EnvironmentObject private var license: LicenseManager

    /// v34.0 · 启动顺序重排，铁律：第一帧绝不等任何重活
    ///   第 1 帧       → 只有 StaticLaunchBackdrop（纯色 + 静态首帧图），毫秒级上屏
    ///   +0.02 秒      → 读本机钥匙串，决定进首页还是进卡密页
    ///   +0.12 秒      → 才挂视频层（AVPlayer 不参与首帧）
    ///   +0.90 秒      → 才允许构建首页（首页那棵树很重，绝不能挡在启动前面）
    @State private var splashDone = false
    /// 本次启动已经进过首页：之后状态再怎么抖（切后台、开防封、网络断），
    /// 只要本地卡密还在、还没到期，就不许把卡密页盖回来。
    @State private var enteredHome = false
    /// 视频层是否已经挂载（首帧之后才为 true）
    @State private var showVideo = false
    /// 首页是否已经允许构建（视频稳住之后才为 true）
    @State private var homeAllowed = false
    /// 卡密页是否已经允许挂载（首帧之后才为 true）
    @State private var gateAllowed = false

    /// 该显示首页了吗（必须等视频先稳住，首页构建不能挡住启动第一眼）
    private var showHome: Bool {
        guard license.state == .unlocked else { return false }
        return (splashDone || enteredHome) && homeAllowed
    }

    /// 该显示卡密页了吗（只有真没卡密 / 真到期才显示）
    private var showGate: Bool {
        switch license.state {
        case .expired:
            return true
        case .locked:
            // 已经进过首页、本地卡密还在 → 状态抖一下也不弹
            if enteredHome && license.hasSavedCode { return false }
            return true
        default:
            return false
        }
    }

    var body: some View {
        ZStack {
            // 永远垫在最底：启动图，切换过程中不会露出黑底
            StaticLaunchBackdrop()
                .zIndex(0)

            if showGate {
                if gateAllowed {
                    // 要输卡密时也照样播启动片当背景（不再纯黑底），输入框立刻就能点
                    SplashLicenseGateView(
                        skipVideo: false,
                        onVideoEnd: {}
                    )
                    .transition(.opacity)
                    .zIndex(2)
                }
            } else if showHome {
                // v34.0 · 只有真该进首页了才构建这棵树，不再提前预热
                SimpleHomeView()
                    .transition(.opacity)
                    .zIndex(3)
            } else if showVideo {
                // 开机过场：启动片盖在静态图上面，起播快慢都不影响画面
                SplashOpeningVideoLayer()
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
        .animation(.easeInOut(duration: 0.32), value: license.state)
        .onAppear {
            LaunchClock.mark("first frame (root gate appear)")
            enterSoon()
        }
        .onChange(of: license.state) { newState in
            switch newState {
            case .unlocked:
                enteredHome = true
            case .expired:
                enteredHome = false
            case .locked:
                // 只有「卡密真的没了」才退回验证页
                if !license.hasSavedCode { enteredHome = false }
            case .checking:
                break
            }
        }
    }

    /// v34.0 · 启动时序：第一帧已经提交之后才按顺序往下走，
    /// 卡密判定 / 视频层 / 首页构建全部延后，一个都不许挡在第一帧前面。
    /// 过场最多 0.9 秒，卡多久都不影响进入。
    private func enterSoon() {
        // 1) 读本机卡密：只读钥匙串、不联网，毫秒级
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.02) {
            // v33.4 · 二进制被改过就在这里死，不再往下走
            LSIntegrity.enforce("gate")
            license.bootstrapLocal()
            if license.state == .unlocked { enteredHome = true }
            LaunchClock.mark("license decided (\(license.state))")
        }

        // 2) 挂视频层（AVPlayer 不参与首帧）
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
            withAnimation(.easeInOut(duration: 0.24)) { showVideo = true }
            gateAllowed = true
        }

        // 3) 过场结束，放首页进来
        guard !splashDone else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
            homeAllowed = true
            withAnimation(.easeInOut(duration: 0.26)) {
                splashDone = true
            }
        }
    }
}

// ============================================================
// v1.5.1 · 云端发布 · 用户端「更新完直接点导入」
// 全部代码放在这个文件末尾，不新增工程文件（避免 pbxproj 漏注册）
// ============================================================

struct SimpleHomeView: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var license: LicenseManager
    @ObservedObject private var importer = PaksImporter.shared
    // v30.0 · 网络环境检查 + 测速
    @StateObject private var net = NetworkProbe()

    @State private var selectedTier: PakTier = AppInfo.versionTuple.major >= 17 ? .high : .low
    @State private var lowState: TierState = .idle
    @State private var highState: TierState = .idle
    @State private var lowProbing = false

    // v20.0 · 防封这一块的状态
    @State private var guardOn: Bool = (UserDefaults.standard.object(forKey: "ls.guard.on") as? Bool) ?? false
    @State private var guardLevel: LSGuardLevel = .sandbox
    @State private var gameModeOn = false
    @State private var guardLines: [String] = []
    @State private var guardBusy = false
    @State private var guardBootstrapped = false

    // v23.0 · 运行记录直接跑在卡片里（不弹窗），点展开看全部
    @State private var guardExpanded = false
    @State private var guardRunToken = 0
    @State private var toolboxExpanded = false
    @State private var renewCode = ""
    @State private var renewBusy = false
    // v33.0 · 代理中心入口
    @State private var showAgentCenter = false
    @State private var guardRecords: [LSGuardRecord] = []
    @State private var guardRealLines: [String] = []
    @State private var guardTotal = 0
    @State private var guardRunCount: Int = (UserDefaults.standard.object(forKey: "ls.guard.runs") as? Int) ?? 0

    private let accent = HomeTheme.accent
    private let danger = Color(red: 0.90, green: 0.31, blue: 0.31)
    private let ticker = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        GeometryReader { geo in
            // v32.0 · 手机 / 平板 / 横屏一套规则：宽度跟着屏幕走，永远居中不拉伸
            let wide = geo.size.width >= 700
            let contentMax: CGFloat = wide ? min(780, geo.size.width - 96) : .infinity
            let sidePad: CGFloat = wide ? 28 : (geo.size.width < 375 ? 14 : 18)
            ZStack {
                HomeBackdrop()

                ScrollView(showsIndicators: false) {
                    // v34.0 · 改懒加载：屏幕外的卡片不参与首次构建，
                    // 首页第一眼的构建量直接砍掉一大半，进页面不再卡一下。
                    LazyVStack(spacing: wide ? 16 : 14) {
                        header
                        statusRow
                        expiryBar
                        antiBanCard
                        tierRow
                        // v33.1 · 「立即更新」已下线：统一走云资源库（直链直发 + 分段并发，更快，还能挑文件）
                        resourceRow
                        actionRow
                        networkCard
                        gameRow
                        quickRow
                        listCard
                        toolboxCard
                        renewCard
                        // v33.1 · 代理中心挪到最下面（整页最后一张卡）
                        agentRow
                        resultLine
                    }
                    .frame(maxWidth: contentMax)
                    .padding(.horizontal, sidePad)
                    .padding(.top, wide ? 34 : 26)
                    .padding(.bottom, 40)
                    .frame(maxWidth: .infinity)
                }

                // v30.0 · 结果弹窗改成自绘浮层：
                // 根视图上已经挂了一个系统 alert（更新提示），SwiftUI 一条分支只认最外层那个，
                // 首页自己的系统 alert 会被吞掉 → 注入 / 修复的结果永远不弹。这里彻底不走系统弹窗。
                resultPopupOverlay
            }
        }
        .preferredColorScheme(.dark)
        .onAppear {
            LaunchClock.mark("home appear (tree built)")
            importer.refresh()
            syncStates()
            CloudUpdater.shared.autoCheck()
            ResourceLibrary.shared.refresh(silent: true)
            LaunchClock.mark("home appear done")
        }
        .sheet(isPresented: $showAgentCenter) {
            AgentCenterView()
        }
        .onReceive(ticker) { _ in syncStates() }
    }

    // MARK: 顶部（长按标题 → 填发布地址）

    private var header: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text("浪神")
                    .font(.system(size: 28, weight: .black, design: .rounded))
                    .foregroundStyle(
                        LinearGradient(colors: [LSGuardTheme.ice, LSGuardTheme.neon],
                                       startPoint: .topLeading,
                                       endPoint: .bottomTrailing)
                    )
                    .shadow(color: LSGuardTheme.neon.opacity(0.55), radius: 14)
                    .onLongPressGesture(minimumDuration: 1.2) {
                        promptCloudAddress()
                    }
                Spacer(minLength: 0)
                Text(guardLevel == .crossApp ? "跨 App" : "沙盒")
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .foregroundStyle(LSGuardTheme.neon)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .overlay(
                        LSChamferShape(cut: 5)
                            .stroke(LSGuardTheme.neon.opacity(0.60), lineWidth: 1)
                    )
                Text("v33.4")
                    .font(.system(size: 9, weight: .black, design: .monospaced))
                    .foregroundStyle(LSGuardTheme.ice.opacity(0.85))
                    .padding(.horizontal, 7)
                    .padding(.vertical, 4)
                    .overlay(
                        LSChamferShape(cut: 5)
                            .stroke(LSGuardTheme.ice.opacity(0.32), lineWidth: 1)
                    )
            }
            HStack(spacing: 8) {
                Rectangle()
                    .fill(
                        LinearGradient(colors: [LSGuardTheme.neon.opacity(0.9), LSGuardTheme.neon.opacity(0)],
                                       startPoint: .leading,
                                       endPoint: .trailing)
                    )
                    .frame(height: 1)
                Text("iOS \(AppInfo.osVersion)")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(LSGuardTheme.neon.opacity(0.72))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func promptCloudAddress() {
        let alert = UIAlertController(
            title: "发布地址",
            message: "填你自己的发布服务地址，末尾不要带斜杠。留空 = 用内置地址。",
            preferredStyle: .alert
        )
        alert.addTextField { tf in
            tf.placeholder = "https://你的域名"
            tf.text = CloudConfig.isCustom ? CloudConfig.base : ""
            tf.keyboardType = .URL
            tf.autocapitalizationType = .none
            tf.autocorrectionType = .no
            tf.clearButtonMode = .whileEditing
        }
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.addAction(UIAlertAction(title: "保存", style: .default) { _ in
            CloudConfig.setBase(alert.textFields?.first?.text ?? "")
            CloudUpdater.shared.reset()
            CloudUpdater.shared.check(manual: true)
        })
        presentOnTop(alert)
    }

    private func presentOnTop(_ vc: UIViewController) {
        guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let root = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController else { return }
        var top = root
        while let presented = top.presentedViewController { top = presented }
        top.present(vc, animated: true)
    }

    // MARK: 状态

    private var statusRow: some View {
        HStack(spacing: 10) {
            tag(selectedTier == .low ? "当前档：低系统" : "当前档：高系统",
                color: accent)
            tag(importer.containerFound ? "游戏目录已找到" : "游戏目录未找到",
                color: importer.containerFound ? accent : Color.white.opacity(0.5))
            Spacer(minLength: 0)
        }
    }

    private func tag(_ text: String, color: Color) -> some View {
        HStack(spacing: 6) {
            Circle().fill(color).frame(width: 7, height: 7)
            Text(text)
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .foregroundStyle(color)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 6))
        .overlay(LSChamferShape(cut: 6).stroke(color.opacity(0.28), lineWidth: 1))
    }

    // MARK: 到期时间（v23.0 · 一眼能看到还剩几天）

    private var expiryBar: some View {
        let days = license.remainingDays
        let expired = license.state == .expired || ((days ?? 0) < 0)
        let tone = expired ? danger : LSGuardTheme.neon
        let forever = license.isPermanent
        return HStack(spacing: 10) {
            Image(systemName: forever ? "infinity" : (expired ? "lock.fill" : "calendar"))
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(tone)
                .frame(width: 20)
            VStack(alignment: .leading, spacing: 1) {
                Text(expired ? "卡密已到期" : "到期时间")
                    .font(.system(size: 9.5, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.42))
                Text(license.expiryLabel)
                    .font(.system(size: 13, weight: .black, design: .monospaced))
                    .foregroundStyle(.white)
            }
            Spacer(minLength: 6)
            Text(daysText(days, expired: expired, forever: forever))
                .font(.system(size: 10, weight: .black, design: .rounded))
                .foregroundStyle(tone)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(tone.opacity(0.13), in: LSChamferShape(cut: 5))
                .overlay(LSChamferShape(cut: 5).stroke(tone.opacity(0.34), lineWidth: 1))
        }
        .padding(.horizontal, 13)
        .padding(.vertical, 10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 12))
        .overlay(LSChamferShape(cut: 12).stroke(tone.opacity(0.30), lineWidth: 1.1))
    }

    private func daysText(_ days: Int?, expired: Bool, forever: Bool) -> String {
        if forever { return "长期" }
        guard let days else { return "—" }
        if expired || days < 0 { return "已过期 " + String(abs(days)) + " 天" }
        if days == 0 { return "今天到期" }
        return "剩 " + String(days) + " 天"
    }

    // MARK: 两个系统版本按钮（首屏主角）

    private var tierRow: some View {
        HStack(spacing: 12) {
            tierButton(.low, state: lowState)
            tierButton(.high, state: highState)
        }
    }

    private func tierButton(_ tier: PakTier, state: TierState) -> some View {
        let on = selectedTier == tier
        let tone = stateColor(state, fallback: on ? accent : Color.white.opacity(0.45))

        return Button {
            select(tier)
        } label: {
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 6) {
                    Image(systemName: tier.icon)
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(tone)
                    Spacer(minLength: 0)
                    HStack(spacing: 5) {
                        Circle().fill(tone).frame(width: 6, height: 6)
                        Text(state.text)
                            .font(.system(size: 10, weight: .bold, design: .rounded))
                            .foregroundStyle(tone)
                    }
                }
                Text(tier.title)
                    .font(.system(size: 18, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(tier.range)
                    .font(.system(size: 13, weight: .heavy, design: .rounded))
                    .foregroundStyle(tone)
                Text(tier.note)
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }
            .frame(maxWidth: .infinity, minHeight: 104, alignment: .leading)
            .padding(13)
            .background(
                (on ? tone.opacity(0.16) : LSGuardTheme.panel),
                in: LSChamferShape(cut: 16)
            )
            .overlay(
                LSChamferShape(cut: 16)
                    .stroke(tone.opacity(on ? 0.95 : 0.34), lineWidth: on ? 2 : 1.2)
            )
            .shadow(color: on ? tone.opacity(0.30) : Color.clear, radius: 16)
        }
        .buttonStyle(.plain)
        .disabled(state == .running)
    }

    private func stateColor(_ state: TierState, fallback: Color) -> Color {
        switch state {
        case .idle: return fallback
        case .running: return HomeTheme.yellow
        case .ok: return accent
        case .fail: return danger
        }
    }

    // MARK: 选档 + 按这档跑

    private func select(_ tier: PakTier) {
        selectedTier = tier
        switch tier {
        case .low:
            runLowTier()
        case .high:
            runHighTier()
        }
    }

    /// 低系统档：14.0–16.6.1 有巨魔环境，本身就带写权限，不碰内核，只验能不能真写进游戏 Paks。
    private func runLowTier() {
        guard !lowProbing else { return }
        lowProbing = true
        lowState = .running
        importer.lastResult = "低系统档：正在验游戏 Paks 能不能写…"

        DispatchQueue.global(qos: .userInitiated).async {
            let result = PaksImporter.shared.probeGameWriteAccess()
            DispatchQueue.main.async {
                lowProbing = false
                lowState = result.ok ? .ok : .fail
                importer.lastResult = "低系统档：" + result.message
                importer.refresh()
            }
        }
    }

    /// 高系统档：17.0–26.6.2 走内核链，偏移按本机现场校准。
    private func runHighTier() {
        if appState.kernelExploitRunning { return }
        highState = .running
        appState.runKernelExploitIfNeeded()
    }

    private func syncStates() {
        if appState.kernelExploitRunning {
            if highState != .running { highState = .running }
            return
        }
        if appState.exploitStatus.isSuccess {
            if highState != .ok {
                highState = .ok
                if selectedTier == .high {
                    importer.lastResult = "高系统档已打通：内核通，游戏目录可读写。"
                }
            }
        } else if appState.exploitStatus.isFailed {
            if highState == .running {
                highState = .fail
                if selectedTier == .high {
                    importer.lastResult = "高系统档没打通：内核没进去，点一下再看日志，或重启 App 再试。"
                }
            }
        }
    }

    // MARK: 云端卡片（v28.0 · 独立视图，进度变化不再带着整个首页重绘）

    private var cloudCard: some View {
        CloudCardView()
    }

    // v33.0 · 云资源库：后台传文件 → 直链 → 一键下载 → 直接注入
    private var resourceRow: some View {
        ResourceLibraryView()
    }

    // v33.0 · 代理中心：代理商在 App 里直接发卡
    private var agentRow: some View {
        Button {
            showAgentCenter = true
        } label: {
            HStack(spacing: 9) {
                Image(systemName: "person.2.badge.gearshape.fill")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(LSGuardTheme.neon)
                Text("代理中心")
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Spacer(minLength: 0)
                Text("发卡 · 看额度")
                    .font(.system(size: 10.5, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.42))
                Image(systemName: "chevron.right")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(.white.opacity(0.32))
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .frame(maxWidth: .infinity)
            .background(LSGuardTheme.panel, in: LSChamferShape(cut: 14))
            .overlay(LSChamferShape(cut: 14).stroke(LSGuardTheme.neon.opacity(0.3), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    // MARK: 注入 / 修复

    private var actionRow: some View {
        HStack(spacing: 12) {
            bigButton(title: "注入",
                      subtitle: "把已下载的包写进游戏",
                      icon: "bolt.fill",
                      tint: LSGuardTheme.neon) {
                importer.importAll()
            }
            bigButton(title: "修复",
                      subtitle: "清掉写进去的包，恢复原样",
                      icon: "wrench.and.screwdriver.fill",
                      tint: LSGuardTheme.ice) {
                importer.deleteImported()
            }
        }
    }

    private func bigButton(title: String,
                           subtitle: String,
                           icon: String,
                           tint: Color,
                           action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(tint)
                    .shadow(color: tint.opacity(0.7), radius: 10)
                Text(title)
                    .font(.system(size: 20, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(subtitle)
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.55))
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, minHeight: 118, alignment: .leading)
            .padding(16)
            .background(
                LinearGradient(colors: [tint.opacity(0.20), LSGuardTheme.panelDeep],
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing),
                in: LSChamferShape(cut: 16)
            )
            .overlay(
                LSChamferShape(cut: 16)
                    .stroke(tint.opacity(0.62), lineWidth: 1.3)
            )
        }
        .buttonStyle(.plain)
        .disabled(importer.busy)
        .opacity(importer.busy ? 0.5 : 1)
    }

    // MARK: 次要按钮

    private var quickRow: some View {
        HStack(spacing: 10) {
            chipButton("检查更新", icon: "icloud.and.arrow.down") {
                CloudUpdater.shared.check(manual: true)
            }
            chipButton("刷新", icon: "arrow.clockwise") { importer.refresh() }
        }
    }

    private func chipButton(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: icon).font(.system(size: 11, weight: .bold))
                Text(title).font(.system(size: 12, weight: .bold, design: .rounded))
            }
            .foregroundStyle(.white.opacity(0.92))
            .frame(maxWidth: .infinity, minHeight: 40)
            .background(LSGuardTheme.panel, in: LSChamferShape(cut: 10))
            .overlay(LSChamferShape(cut: 10).stroke(LSGuardTheme.neon.opacity(0.26), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    // MARK: 文件清单

    private var listCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("待导入 \(importer.inboxFiles.count) · 已导入 \(importer.importedFiles.count)")
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.75))
                Spacer()
                if importer.busy {
                    Text("处理中…")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(HomeTheme.yellow)
                }
            }

            if importer.inboxFiles.isEmpty && importer.importedFiles.isEmpty {
                Text("还没有包。点「检查更新」从云端拉最新包，下载完点「注入」。")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(.white.opacity(0.45))
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else {
                ForEach(importer.inboxFiles, id: \.self) { name in
                    row(name: name, badge: "待注入", color: HomeTheme.yellow, inbox: true)
                }
                ForEach(importer.importedFiles, id: \.self) { name in
                    row(name: name, badge: "已注入", color: accent, inbox: false)
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 14))
        .overlay(LSChamferShape(cut: 14).stroke(LSGuardTheme.neon.opacity(0.22), lineWidth: 1))
    }

    private func row(name: String, badge: String, color: Color, inbox: Bool) -> some View {
        let token = (inbox ? "inbox|" : "game|") + name
        let confirming = importer.pendingDelete == token
        return HStack(spacing: 8) {
            Image(systemName: "doc.fill")
                .font(.system(size: 11))
                .foregroundStyle(color.opacity(0.9))
            Text(name)
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(.white.opacity(0.9))
                .lineLimit(1)
            Spacer(minLength: 6)
            Text(badge)
                .font(.system(size: 9, weight: .bold, design: .rounded))
                .foregroundStyle(color)
                .padding(.horizontal, 6)
                .padding(.vertical, 2)
                .background(color.opacity(0.16), in: Capsule())
            Button {
                if confirming {
                    importer.confirmPendingDelete()
                } else {
                    importer.requestDelete(name, inbox: inbox)
                }
            } label: {
                if confirming {
                    Text("确认删除")
                        .font(.system(size: 10, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color(red: 0.95, green: 0.32, blue: 0.34),
                                    in: Capsule())
                } else {
                    Image(systemName: "trash")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Color(red: 1.0, green: 0.45, blue: 0.45).opacity(0.9))
                        .padding(.horizontal, 5)
                        .padding(.vertical, 4)
                }
            }
            .buttonStyle(.plain)
            .disabled(importer.busy)
            .opacity(importer.busy ? 0.4 : 1)
        }
    }

    // MARK: 结果

    private var resultLine: some View {
        Text(importer.lastResult.isEmpty ? "就绪" : importer.lastResult)
            .font(.system(size: 11, weight: .medium))
            .foregroundStyle(.white.opacity(0.55))
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    // MARK: - v30.0 · 注入 / 修复 结果弹窗（自绘浮层，保证一定弹得出来）

    private var resultPopupOverlay: some View {
        Group {
            if let item = importer.pendingAlert {
                resultPopupCard(item)
            }
        }
        .animation(.easeOut(duration: 0.16), value: importer.pendingAlert?.id)
    }

    private func resultPopupCard(_ item: PaksAlert) -> some View {
        let tone = item.success ? LSGuardTheme.neon : HomeTheme.yellow
        return ZStack {
                    Color.black.opacity(0.66)
                        .ignoresSafeArea()
                        .onTapGesture { importer.dismissAlert() }

                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 9) {
                            Image(systemName: item.success
                                  ? "checkmark.seal.fill"
                                  : "exclamationmark.triangle.fill")
                                .font(.system(size: 20, weight: .black))
                                .foregroundStyle(tone)

                            Text(item.title)
                                .font(.system(size: 17, weight: .black, design: .rounded))
                                .foregroundStyle(.white)
                                .lineLimit(2)
                                .minimumScaleFactor(0.8)

                            Spacer(minLength: 0)
                        }

                        Text(item.message)
                            .font(.system(size: 13, weight: .medium))
                            .foregroundStyle(.white.opacity(0.88))
                            .fixedSize(horizontal: false, vertical: true)
                            .lineSpacing(3)

                        Button {
                            importer.dismissAlert()
                        } label: {
                            Text("好")
                                .font(.system(size: 15, weight: .black, design: .rounded))
                                .foregroundStyle(.black)
                                .frame(maxWidth: .infinity, minHeight: 44)
                                .background(tone, in: LSChamferShape(cut: 10))
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(18)
                    .frame(maxWidth: 400)
                    .background(LSGuardTheme.panelDeep, in: LSChamferShape(cut: 18))
                    .overlay(
                        LSChamferShape(cut: 18).stroke(tone.opacity(0.62), lineWidth: 1.3)
                    )
                    .shadow(color: Color.black.opacity(0.55), radius: 22, y: 10)
                    .padding(.horizontal, 26)
                }
                .transition(.opacity)
                .zIndex(80)
    }

    // MARK: - v30.0 · 网络环境检查 + 测速

    private var netTint: Color {
        switch net.gradeTone {
        case 2: return danger
        case 1: return HomeTheme.yellow
        default: return LSGuardTheme.neon
        }
    }

    private var networkCard: some View {
        let tint = netTint
        return VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Image(systemName: "antenna.radiowaves.left.and.right")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(tint)

                Text("网络环境")
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white)

                Spacer(minLength: 0)

                Text(net.badgeText)
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(tint)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(tint.opacity(0.16), in: Capsule())
            }

            Text(net.line)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.white.opacity(0.62))
                .fixedSize(horizontal: false, vertical: true)

            if net.hasRun {
                VStack(spacing: 6) {
                    netRow("通路", net.routeText, net.routeOK)
                    netRow("代理 / VPN", net.proxyText, !net.proxyWarn)
                    netRow("DNS 解析", net.dnsText, net.dnsOK)
                    netRow("延迟 / 丢包", net.latencyText, net.latencyOK)
                    netRow("发布服务器", net.serverText, net.serverOK)
                    netRow("下载速度", net.speedText, net.speedOK)
                }
            }

            Button {
                net.run()
            } label: {
                HStack(spacing: 7) {
                    Image(systemName: net.running ? "hourglass" : "bolt.horizontal.circle.fill")
                        .font(.system(size: 12, weight: .bold))
                    Text(net.running ? "正在检查…" : "检查 + 测速")
                        .font(.system(size: 13, weight: .black, design: .rounded))
                    Spacer(minLength: 0)
                    Text(net.running ? "…" : "约 8 秒")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .opacity(0.7)
                }
                .foregroundStyle(.black)
                .padding(.horizontal, 12)
                .frame(maxWidth: .infinity, minHeight: 40)
                .background(tint, in: LSChamferShape(cut: 10))
            }
            .buttonStyle(.plain)
            .disabled(net.running)
            .opacity(net.running ? 0.6 : 1)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 14))
        .overlay(LSChamferShape(cut: 14).stroke(tint.opacity(0.35), lineWidth: 1.1))
    }

    private func netRow(_ key: String, _ value: String, _ good: Bool) -> some View {
        HStack(spacing: 8) {
            Text(key)
                .font(.system(size: 10.5, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.42))
                .frame(width: 76, alignment: .leading)
            Text(value)
                .font(.system(size: 11, weight: .semibold, design: .rounded))
                .foregroundStyle(good ? LSGuardTheme.ice : HomeTheme.yellow)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
    }

    // MARK: - v20.0 · 防封模式（跟工具箱同一块，都在这一页里）

    private var antiBanCard: some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack(spacing: 8) {
                Text("🛡").font(.system(size: 16))
                Text("防封模式")
                    .font(.system(size: 15, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Spacer(minLength: 0)
                HStack(spacing: 6) {
                    Circle()
                        .fill(guardBusy ? HomeTheme.yellow : LSGuardTheme.neon)
                        .frame(width: 6, height: 6)
                    Text(guardBusy ? "运行中" : (guardOn ? "已开启" : "未开启"))
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .foregroundStyle(guardBusy ? HomeTheme.yellow : LSGuardTheme.neon)
                }
                .padding(.horizontal, 9)
                .padding(.vertical, 5)
                .background(LSGuardTheme.neon.opacity(0.12), in: LSChamferShape(cut: 5))
                .overlay(LSChamferShape(cut: 5)
                    .stroke(LSGuardTheme.neon.opacity(0.55), lineWidth: 1))
            }

            HStack(spacing: 8) {
                guardTag(guardLevel.title,
                         color: guardLevel == .crossApp ? LSGuardTheme.neon : LSGuardTheme.dim)
                guardTag("累计启动 " + String(guardRunCount) + " 次",
                         color: guardRunCount > 0 ? LSGuardTheme.ice : LSGuardTheme.dim)
                Spacer(minLength: 0)
            }

            Text(guardLevel.detail)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.white.opacity(0.66))
                .fixedSize(horizontal: false, vertical: true)

            Button {
                fireGuard()
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: guardBusy ? "hourglass" : "shield.lefthalf.filled")
                        .font(.system(size: 13, weight: .black))
                    Text(guardBusy ? "正在跑…" : "开启防封")
                        .font(.system(size: 14, weight: .black, design: .rounded))
                    Spacer(minLength: 0)
                    Text(guardTotal > 0 ? String(guardRecords.count) + "/" + String(guardTotal) : (guardBusy ? "…" : "就绪"))
                        .font(.system(size: 10, weight: .black, design: .monospaced))
                        .opacity(0.72)
                }
                .foregroundStyle(.black)
                .padding(.horizontal, 14)
                .frame(maxWidth: .infinity, minHeight: 46)
                .background(
                    LinearGradient(colors: [LSGuardTheme.neon, LSGuardTheme.ice],
                                   startPoint: .leading,
                                   endPoint: .trailing),
                    in: LSChamferShape(cut: 10)
                )
            }
            .buttonStyle(.plain)
            .disabled(guardBusy)
            .opacity(guardBusy ? 0.55 : 1)

            Rectangle()
                .fill(LSGuardTheme.neon.opacity(0.18))
                .frame(height: 1)
                .padding(.vertical, 1)

            guardRecordsBlock
        }
        .padding(15)
        .background(
            LinearGradient(colors: [LSGuardTheme.neon.opacity(guardOn ? 0.16 : 0.08),
                                    LSGuardTheme.panelDeep],
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing),
            in: LSChamferShape(cut: 14)
        )
        .overlay(LSChamferShape(cut: 14)
            .stroke(LSGuardTheme.neon.opacity(guardOn ? 0.85 : 0.40), lineWidth: 1.3))
        .shadow(color: LSGuardTheme.neon.opacity(guardOn ? 0.28 : 0), radius: 18)
        .onAppear { refreshGuardLevel() }
    }

    /// 运行记录：默认只露最近 3 条，点右边的展开图标才铺开全部
    private var guardRecordsBlock: some View {
        VStack(alignment: .leading, spacing: 8) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) { guardExpanded.toggle() }
            } label: {
                HStack(spacing: 7) {
                    Image(systemName: "list.bullet.rectangle")
                        .font(.system(size: 11, weight: .bold))
                    Text("运行记录")
                        .font(.system(size: 12, weight: .black, design: .rounded))
                    if guardTotal > 0 {
                        Text(String(guardRecords.count) + "/" + String(guardTotal))
                            .font(.system(size: 10, weight: .black, design: .monospaced))
                            .foregroundStyle(LSGuardTheme.neon.opacity(0.9))
                    }
                    Spacer(minLength: 0)
                    Text(guardRecords.isEmpty ? "未运行" : (guardExpanded ? "收起" : "展开"))
                        .font(.system(size: 10.5, weight: .bold, design: .rounded))
                    Image(systemName: guardExpanded ? "chevron.up.circle.fill" : "chevron.down.circle.fill")
                        .font(.system(size: 16, weight: .bold))
                }
                .foregroundStyle(LSGuardTheme.neon.opacity(0.92))
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if guardRecords.isEmpty {
                Text("点上面的「开启防封」，机制会一条一条跑在这里。")
                    .font(.system(size: 10.5, weight: .medium))
                    .foregroundStyle(.white.opacity(0.42))
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else {
                if guardBusy {
                    GeometryReader { g in
                        ZStack(alignment: .leading) {
                            Capsule().fill(Color.white.opacity(0.1))
                            Capsule().fill(LSGuardTheme.neon)
                                .frame(width: max(6, g.size.width * CGFloat(Double(guardRecords.count) / Double(max(guardTotal, 1)))))
                        }
                    }
                    .frame(height: 4)
                }

                if guardExpanded {
                    ScrollViewReader { proxy in
                        ScrollView(showsIndicators: false) {
                            VStack(alignment: .leading, spacing: 8) {
                                ForEach(guardRecords) { rec in
                                    guardRecordRow(rec).id(rec.id)
                                }
                                if !guardBusy {
                                    guardCleanupBlock
                                }
                            }
                            .padding(.vertical, 1)
                        }
                        .frame(height: 236)
                        .onChange(of: guardRecords.count) { _ in
                            if let last = guardRecords.last {
                                withAnimation(.easeOut(duration: 0.18)) {
                                    proxy.scrollTo(last.id, anchor: .bottom)
                                }
                            }
                        }
                    }
                } else {
                    ForEach(guardRecords.suffix(3)) { rec in
                        guardRecordRow(rec)
                    }
                }
            }
        }
    }

    private func guardRecordRow(_ rec: LSGuardRecord) -> some View {
        HStack(alignment: .top, spacing: 7) {
            Text(rec.icon)
                .font(.system(size: 10))
                .frame(width: 14, alignment: .center)
            Text(rec.text)
                .font(.system(size: 11, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.90))
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 4)
            if rec.cost > 0 {
                Text(String(rec.cost) + " ms")
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .foregroundStyle(LSGuardTheme.neon.opacity(0.55))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var guardCleanupBlock: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text("顺手清掉的")
                .font(.system(size: 9.5, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.32))
                .padding(.top, 4)
            ForEach(Array(guardRealLines.suffix(6).enumerated()), id: \.offset) { _, line in
                Text(line)
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.52))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private func guardTag(_ text: String, color: Color) -> some View {
        HStack(spacing: 5) {
            Circle().fill(color).frame(width: 6, height: 6)
            Text(text)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .foregroundStyle(color)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(color.opacity(0.12), in: LSChamferShape(cut: 5))
        .overlay(LSChamferShape(cut: 5).stroke(color.opacity(0.24), lineWidth: 1))
    }

    private var toolboxCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) { toolboxExpanded.toggle() }
            } label: {
                HStack(spacing: 8) {
                    Text("🧰").font(.system(size: 15))
                    Text("防封工具箱")
                        .font(.system(size: 14, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text(String(LSGuardTool.available(guardLevel).count) + " 项")
                        .font(.system(size: 9.5, weight: .black, design: .monospaced))
                        .foregroundStyle(LSGuardTheme.neon.opacity(0.85))
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(LSGuardTheme.neon.opacity(0.12), in: Capsule())
                    Spacer(minLength: 0)
                    Text(toolboxExpanded ? "收起" : "展开")
                        .font(.system(size: 10.5, weight: .bold, design: .rounded))
                    Image(systemName: toolboxExpanded ? "chevron.up.circle.fill" : "chevron.down.circle.fill")
                        .font(.system(size: 16, weight: .bold))
                }
                .foregroundStyle(LSGuardTheme.neon.opacity(0.92))
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if toolboxExpanded {
                ForEach(LSGuardTool.available(guardLevel)) { item in
                    Button {
                        runGuardTool(item)
                    } label: {
                        HStack(spacing: 10) {
                            Text(item.icon).font(.system(size: 15))
                                .frame(width: 24, height: 24)
                                .background(LSGuardTheme.neon.opacity(0.10), in: LSChamferShape(cut: 6))
                            VStack(alignment: .leading, spacing: 2) {
                                Text(item.title)
                                    .font(.system(size: 12.5, weight: .bold, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.94))
                                Text(item.sub)
                                    .font(.system(size: 10, weight: .medium))
                                    .foregroundStyle(.white.opacity(0.45))
                            }
                            Spacer(minLength: 0)
                            Image(systemName: "chevron.right")
                                .font(.system(size: 10, weight: .bold))
                                .foregroundStyle(LSGuardTheme.neon.opacity(0.75))
                        }
                        .padding(.vertical, 7)
                        .padding(.horizontal, 9)
                        .background(Color.white.opacity(0.03), in: LSChamferShape(cut: 9))
                        .overlay(LSChamferShape(cut: 9).stroke(LSGuardTheme.neon.opacity(0.16), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                    .disabled(guardBusy)
                    .opacity(guardBusy ? 0.55 : 1)
                }

                if !guardLines.isEmpty {
                    Rectangle()
                        .fill(LSGuardTheme.neon.opacity(0.18))
                        .frame(height: 1)
                        .padding(.vertical, 2)
                    ForEach(Array(guardLines.suffix(8).enumerated()), id: \.offset) { _, line in
                        Text(line)
                            .font(.system(size: 10.5, weight: .medium, design: .monospaced))
                            .foregroundStyle(line.hasPrefix("✓") ? LSGuardTheme.neon.opacity(0.9) : Color.white.opacity(0.6))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            } else {
                Text(guardBusy ? "执行中…" : "点「展开」看工具箱里的全部功能")
                    .font(.system(size: 10.5, weight: .medium))
                    .foregroundStyle(.white.opacity(0.40))
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(14)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 12))
        .overlay(LSChamferShape(cut: 12).stroke(LSGuardTheme.neon.opacity(0.42), lineWidth: 1.2))
    }

    // MARK: 进入游戏（v23.0 · 直接跳本地和平精英）

    private var gameRow: some View {
        Button {
            openGame()
        } label: {
            HStack(spacing: 9) {
                Image(systemName: "gamecontroller.fill")
                    .font(.system(size: 15, weight: .black))
                Text("进入游戏")
                    .font(.system(size: 15, weight: .black, design: .rounded))
                Spacer(minLength: 0)
                Text(importer.matchedBundleID.isEmpty ? "和平精英" : "和平精英 · 已定位")
                    .font(.system(size: 10.5, weight: .bold, design: .rounded))
                    .opacity(0.72)
                Image(systemName: "arrow.up.forward.app.fill")
                    .font(.system(size: 12, weight: .black))
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 16)
            .frame(maxWidth: .infinity, minHeight: 50)
            .background(
                LinearGradient(colors: [LSGuardTheme.ice.opacity(0.30),
                                        LSGuardTheme.neon.opacity(0.20),
                                        LSGuardTheme.panelDeep],
                               startPoint: .leading,
                               endPoint: .trailing),
                in: LSChamferShape(cut: 12)
            )
            .overlay(LSChamferShape(cut: 12).stroke(LSGuardTheme.ice.opacity(0.55), lineWidth: 1.2))
        }
        .buttonStyle(.plain)
    }

    private func openGame() {
        if GameLauncher.openInstalledGame() {
            importer.lastResult = "正在打开和平精英…"
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        } else {
            importer.showAlert(
                "没找到游戏",
                "没打开成功：先在桌面点一次和平精英，再回来点这个按钮。\n如果还是不行，确认装的是国服（com.tencent.tmgp.pubgmhd）或对应服的版本。",
                success: false
            )
        }
    }

    // MARK: 续费（v23.0 · 输卡密就能续）

    private var renewCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Text("🔑").font(.system(size: 14))
                Text("浪神卡密")
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Spacer(minLength: 0)
                Text(license.isPermanent ? "永久有效" : "到期 " + license.expirationText)
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(LSGuardTheme.neon.opacity(0.85))
            }

            HStack(spacing: 9) {
                TextField("输入续费卡密", text: $renewCode)
                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                    .foregroundStyle(.white)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .padding(.horizontal, 11)
                    .frame(maxWidth: .infinity, minHeight: 44)
                    .background(Color.white.opacity(0.05), in: LSChamferShape(cut: 9))
                    .overlay(LSChamferShape(cut: 9).stroke(LSGuardTheme.neon.opacity(0.24), lineWidth: 1))

                Button {
                    renew()
                } label: {
                    Text(renewBusy ? "验证中…" : "立即续费")
                        .font(.system(size: 12.5, weight: .black, design: .rounded))
                        .foregroundStyle(.black)
                        .padding(.horizontal, 16)
                        .frame(minHeight: 44)
                        .background(
                            LinearGradient(colors: [LSGuardTheme.neon, LSGuardTheme.ice],
                                           startPoint: .leading,
                                           endPoint: .trailing),
                            in: LSChamferShape(cut: 9)
                        )
                }
                .buttonStyle(.plain)
                .disabled(renewBusy)
                .opacity(renewBusy ? 0.6 : 1)
            }

            Text("续费卡密验证通过后到期时间会自动往后延，卡密也换成新的这一张。")
                .font(.system(size: 9.5, weight: .medium))
                .foregroundStyle(.white.opacity(0.38))
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(13)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 12))
        .overlay(LSChamferShape(cut: 12).stroke(LSGuardTheme.neon.opacity(0.28), lineWidth: 1.1))
    }

    private func renew() {
        let code = renewCode.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !code.isEmpty else {
            importer.showAlert("先输入卡密", "把续费卡密填进去，再点「立即续费」。", success: false)
            return
        }
        guard !renewBusy else { return }
        renewBusy = true
        Task {
            let result = await license.renew(code: code)
            renewBusy = false
            if result.ok {
                renewCode = ""
                importer.showAlert("续费成功",
                                   result.msg + "\n现在到期时间：" + (license.isPermanent ? "永久有效" : license.expirationText))
            } else {
                importer.showAlert("续费失败", result.msg, success: false)
            }
        }
    }

    private func refreshGuardLevel() {
        guardLevel = LSGuard.level()
        guard !guardBootstrapped else { return }
        guardBootstrapped = true
    }

    /// 点一下：真跑一遍防封（该清的照样清），机制记录直接在这张卡里一条条跑出来
    private func fireGuard() {
        guard !guardBusy else { return }
        guardBusy = true
        guardOn = true
        UserDefaults.standard.set(true, forKey: "ls.guard.on")
        guardRunCount += 1
        UserDefaults.standard.set(guardRunCount, forKey: "ls.guard.runs")
        guardRunToken += 1
        let token = guardRunToken

        withAnimation(.easeInOut(duration: 0.2)) { guardExpanded = false }
        guardRecords = []
        guardRealLines = []
        guardTotal = 0

        let level = guardLevel
        let round = guardRunCount

        DispatchQueue.global(qos: .userInitiated).async {
            var report = LSGuardReport()
            LSGuard.antiBanPass(&report)
            let real = report.lines

            DispatchQueue.main.async {
                guard token == guardRunToken else { return }
                guardRealLines = real
                let items = LSGuardMechanism.build(level: level, round: round)
                guardTotal = items.count
                guardRecords = []
                for (i, item) in items.enumerated() {
                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(i) * 0.12) {
                        guard token == guardRunToken else { return }
                        guardRecords.append(item)
                        if i == items.count - 1 {
                            guardBusy = false
                            guardLines = real
                            PaksImporter.shared.lastResult = "防封已开启 · 本轮 " + String(items.count) + " 项全部就绪"
                        }
                    }
                }
            }
        }
    }

    private func runGuardTool(_ item: LSGuardTool) {
        guard !guardBusy else { return }
        guardBusy = true
        let mode = gameModeOn
        DispatchQueue.global(qos: .userInitiated).async {
            var r = LSGuardReport()
            let next = LSGuard.run(item.id, mode, &r)
            DispatchQueue.main.async {
                guardBusy = false
                if let next = next { gameModeOn = next }
                guardLines = r.lines
                PaksImporter.shared.lastResult = item.title + " · " + r.summary
            }
        }
    }
}

// ============================================================
// MARK: - v28.0 · 云更新卡片（独立视图）
// 拆出来的原因：这张卡下载时要一秒变好几次进度。
// 以前它挂在首页身上，每变一次整个首页（大壁纸 + 全部卡片）都要重算，
// 下载 20 多 M 的包时整屏看着就像卡死了。现在只有这张卡自己重绘。
// ============================================================

struct CloudCardView: View {
    @ObservedObject private var cloud = CloudUpdater.shared

    private var tint: Color {
        switch cloud.phase {
        case .available, .downloading: return HomeTheme.yellow
        case .ready, .upToDate: return HomeTheme.accent
        case .failed: return Color(red: 0.90, green: 0.31, blue: 0.31)
        default: return Color.white.opacity(0.5)
        }
    }

    private var icon: String {
        switch cloud.phase {
        case .available: return "arrow.down.circle.fill"
        case .downloading: return "arrow.down.circle"
        case .ready: return "checkmark.circle.fill"
        case .upToDate: return "checkmark.seal.fill"
        case .failed: return "exclamationmark.triangle.fill"
        default: return "icloud"
        }
    }

    private var title: String {
        switch cloud.phase {
        case .available: return "发现新版本 " + (cloud.remote?.version ?? "")
        case .downloading: return "正在下载新包"
        case .ready: return "新包已就绪 " + (cloud.pending?.version ?? "")
        case .upToDate: return cloud.installedVersion.isEmpty ? "云端已就绪" : "云端已是最新 " + cloud.installedVersion
        case .checking: return "正在检查更新"
        case .failed: return "云端连不上"
        default: return "云端"
        }
    }

    var body: some View {
        let tint = self.tint
        return VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(tint)
                Text(title)
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                Spacer(minLength: 0)
                Text(cloud.phase.text)
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(tint)
                    .padding(.horizontal, 7)
                    .padding(.vertical, 3)
                    .background(tint.opacity(0.16), in: Capsule())
            }

            if cloud.phase == .downloading {
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.white.opacity(0.1))
                        Capsule().fill(tint)
                            .frame(width: max(6, geo.size.width * CGFloat(max(0, min(1, cloud.progress)))))
                    }
                }
                .frame(height: 6)

                Text(String(format: "%.0f%%", max(0, min(1, cloud.progress)) * 100)
                     + " · 下载期间可以继续用，别退到后台")
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.42))
            }

            Text(cloud.line)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.white.opacity(0.6))
                .fixedSize(horizontal: false, vertical: true)

            if !cloud.notesText.isEmpty && (cloud.phase == .available || cloud.phase == .ready) {
                Text(cloud.notesText)
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.8))
                    .fixedSize(horizontal: false, vertical: true)
            }

            if cloud.phase == .available {
                Button {
                    cloud.update()
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "arrow.down.circle.fill")
                            .font(.system(size: 12, weight: .bold))
                        Text("立即更新")
                            .font(.system(size: 13, weight: .black, design: .rounded))
                    }
                    .foregroundStyle(.black)
                    .frame(maxWidth: .infinity, minHeight: 38)
                    .background(tint, in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 14))
        .overlay(
            LSChamferShape(cut: 14)
                .stroke(tint.opacity(0.42), lineWidth: 1.1)
        )
    }
}

// ============================================================
// MARK: - 云端发布配置
// ============================================================

enum CloudConfig {
    /// ★★★ 编给客户之前，只改这一行：你自己的发布服务地址（末尾不要斜杠）
    /// 例：static let defaultBase = "https://pkg.你的域名.com"
    /// 注意：后台 index.php 必须放在站点根目录，清单地址就是 站点/api/manifest.json
    static let defaultBase = "https://ek.x8iu.com"

    private static let overrideKey = "ls.cloud.base"

    static var base: String {
        let v = UserDefaults.standard.string(forKey: overrideKey) ?? ""
        return v.isEmpty ? defaultBase : v
    }

    static var isCustom: Bool {
        !(UserDefaults.standard.string(forKey: overrideKey) ?? "").isEmpty
    }

    static func setBase(_ value: String) {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        UserDefaults.standard.set(trimmed, forKey: overrideKey)
    }

    /// 地址里还留着模板占位符，就等于没配
    static var configured: Bool {
        let b = base
        guard b.hasPrefix("http://") || b.hasPrefix("https://") else { return false }
        return !b.contains("your-domain")
    }

    static func url(_ path: String) -> URL? {
        if path.hasPrefix("http://") || path.hasPrefix("https://") {
            return URL(string: path)
        }
        var b = base
        while b.hasSuffix("/") { b.removeLast() }
        var p = path
        while p.hasPrefix("/") { p.removeFirst() }
        return URL(string: b + "/" + p)
    }

    /// 清单地址
    static var manifestURL: URL? { url("api/manifest.json") }

    /// 包文件地址：相对路径按「清单所在目录」解析，站点放哪一层都不会错
    static func fileURL(_ path: String) -> URL? {
        if path.hasPrefix("http://") || path.hasPrefix("https://") {
            return URL(string: path)
        }
        guard let m = manifestURL else { return nil }
        let dir = m.deletingLastPathComponent()
        var p = path
        while p.hasPrefix("/") { p.removeFirst() }
        return URL(string: p, relativeTo: dir)
    }
}

// ============================================================
// MARK: - 云端数据结构
// ============================================================

struct CloudFileItem: Codable, Identifiable, Equatable {
    var name: String
    var size: Int64?
    var sha256: String?
    var url: String?

    var id: String { name }
}

struct CloudManifest: Codable, Equatable {
    var version: String
    var notes: String?
    var published: String?
    var files: [CloudFileItem]
    var remove: [String]?
    var ipa: String?
    var appVersion: String?
}

enum CloudPhase: Equatable {
    case idle
    case checking
    case upToDate
    case available
    case downloading
    case ready
    case failed

    var text: String {
        switch self {
        case .idle: return "未检查"
        case .checking: return "检查中"
        case .upToDate: return "已最新"
        case .available: return "有新版"
        case .downloading: return "下载中"
        case .ready: return "待导入"
        case .failed: return "连不上"
        }
    }
}

// ============================================================
// MARK: - 云端更新器
// ============================================================

final class CloudUpdater: ObservableObject {
    static let shared = CloudUpdater()

    @Published var phase: CloudPhase = .idle
    @Published var remote: CloudManifest?
    @Published var pending: CloudManifest?
    @Published var progress: Double = 0
    @Published var line: String = "点「检查更新」拉最新包"

    private let fm = FileManager.default
    private let versionKey = "ls.cloud.version"
    private let filesKey = "ls.cloud.files"
    private let pendingKey = "ls.cloud.pending"

    private var working = false
    private var lastCheck = Date.distantPast
    private var progressTimer: Timer?
    private var currentTask: URLSessionDownloadTask?

    var notesText: String {
        (phase == .ready ? pending?.notes : remote?.notes) ?? ""
    }

    var installedVersion: String {
        UserDefaults.standard.string(forKey: versionKey) ?? ""
    }

    private static var docs: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
    }

    static var stageURL: URL { docs.appendingPathComponent("CloudStage", isDirectory: true) }
    static var inboxURL: URL { docs.appendingPathComponent("PakInbox", isDirectory: true) }

    private init() {
        if let data = UserDefaults.standard.data(forKey: pendingKey),
           let m = try? JSONDecoder().decode(CloudManifest.self, from: data),
           m.version != installedVersion {
            pending = m
            phase = .ready
            line = "上次已下载 " + m.version + "，点「注入」写进游戏"
        }
    }

    func reset() {
        progressTimer?.invalidate()
        progressTimer = nil
        currentTask = nil
        working = false
        remote = nil
        phase = .idle
        progress = 0
        line = "点「检查更新」拉最新包"
    }

    // MARK: - 检查更新

    func autoCheck() {
        guard CloudConfig.configured else {
            line = "还没填发布地址：长按标题填一次"
            return
        }
        guard Date().timeIntervalSince(lastCheck) > 20 else { return }
        check(manual: false)
    }

    func check(manual: Bool) {
        guard !working else {
            if manual { PaksImporter.shared.showAlert("正在忙", "这会儿正在下载，等它跑完再检查。", success: false) }
            return
        }
        guard CloudConfig.configured else {
            phase = .failed
            line = "还没填发布地址：长按标题「浪神文件管理器」填一次"
            if manual {
                PaksImporter.shared.showAlert("还没配置发布地址",
                                              "长按标题「浪神文件管理器」一秒，把发布地址填进去一次就行。",
                                              success: false)
            }
            return
        }
        guard let url = CloudConfig.url("api/manifest.json") else {
            phase = .failed
            line = "发布地址格式不对"
            return
        }

        working = true
        lastCheck = Date()
        if phase != .ready { phase = .checking }
        line = "正在检查更新…"

        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.timeoutInterval = 15
        request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")

        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            guard let self = self else { return }
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0

            if let error = error {
                DispatchQueue.main.async {
                    self.working = false
                    if self.phase != .ready { self.phase = .failed }
                    self.line = "连不上发布服务：" + error.localizedDescription
                    if manual && self.phase != .ready {
                        PaksImporter.shared.showAlert("检查更新失败",
                                                      "连不上发布地址。\n检查网络，或者长按标题确认地址有没有填错。",
                                                      success: false)
                    }
                }
                return
            }

            guard let data = data, let manifest = try? JSONDecoder().decode(CloudManifest.self, from: data) else {
                DispatchQueue.main.async {
                    self.working = false
                    if self.phase != .ready { self.phase = .idle }
                    // v27.0 · 404 = 文件传上去了但后台从没点过「发布」，别让人以为是网络挂了
                    self.line = status == 404
                        ? "云端还没发布过包：后台上传文件后要点「发布」"
                        : "发布端的清单读不出来，回后台重新点一次「发布」"
                    if manual {
                        PaksImporter.shared.showAlert(
                            status == 404 ? "云端还没发布" : "清单读不出来",
                            status == 404
                            ? "文件是传上去了，但后台还没点「发布」。\n去后台「发布」页，填个版本号、勾上文件、点发布，App 这边就有了。"
                            : "能连上服务器，但清单内容读不出来。回后台重新点一次「发布」就好。",
                            success: false)
                    }
                }
                return
            }

            DispatchQueue.main.async {
                self.working = false
                self.remote = manifest

                if let p = self.pending, p.version == manifest.version {
                    self.phase = .ready
                    self.line = "新包已就绪 " + p.version + "，点「注入」写进游戏"
                    return
                }

                if self.installedVersion == manifest.version {
                    self.phase = .upToDate
                    self.progress = 1
                    self.line = "云端已是最新 " + manifest.version
                    if manual {
                        PaksImporter.shared.showAlert("已是最新", "现在装的就是最新版 " + manifest.version + "，不用更新。")
                    }
                    return
                }

                self.phase = .available
                self.line = "发现新版本 " + manifest.version + " · " + String(manifest.files.count) + " 个文件"
            }
        }.resume()
    }

    // MARK: - 下载

    func update() {
        guard let manifest = remote else { return }
        guard !working else { return }
        guard !manifest.files.isEmpty else {
            PaksImporter.shared.showAlert("这版没有文件", "发布端这一版没带任何 pak/sig，先回去补齐再发。", success: false)
            return
        }

        working = true
        phase = .downloading
        progress = 0
        line = "正在下载 " + manifest.version + "…"

        try? fm.createDirectory(at: Self.stageURL, withIntermediateDirectories: true)
        if let old = try? fm.contentsOfDirectory(at: Self.stageURL, includingPropertiesForKeys: nil) {
            for u in old { try? fm.removeItem(at: u) }
        }

        let total = max(1, manifest.files.reduce(Int64(0)) { $0 + ($1.size ?? 0) })
        // v28.0 · 兜底：10 分钟还没跑完就判定断了，界面不会永远停在「下载中」
        DispatchQueue.main.asyncAfter(deadline: .now() + 600) { [weak self] in
            guard let self = self, self.working, self.phase == .downloading else { return }
            self.progressTimer?.invalidate()
            self.progressTimer = nil
            self.currentTask?.cancel()
            self.currentTask = nil
            self.working = false
            self.phase = .available
            self.line = "下载超时了，等网络稳一点再点一次「立即更新」"
        }

        downloadNext(manifest.files,
                     index: 0,
                     manifest: manifest,
                     doneBytes: 0,
                     totalBytes: total,
                     failures: [])
    }

    private func downloadNext(_ files: [CloudFileItem],
                              index: Int,
                              manifest: CloudManifest,
                              doneBytes: Int64,
                              totalBytes: Int64,
                              failures: [String]) {
        if index >= files.count {
            finishDownload(manifest, failures: failures)
            return
        }

        let item = files[index]
        guard let url = CloudConfig.fileURL(item.url ?? ("files/" + item.name)) else {
            downloadNext(files, index: index + 1, manifest: manifest,
                         doneBytes: doneBytes, totalBytes: totalBytes,
                         failures: failures + [item.name])
            return
        }

        // v28.0 · 单个文件 120 秒还没下来就判失败，不会永远挂着
        var req = URLRequest(url: url)
        req.timeoutInterval = 120
        req.cachePolicy = .reloadIgnoringLocalCacheData

        let task = URLSession.shared.downloadTask(with: req) { [weak self] tmp, _, error in
            guard let self = self else { return }
            var nextDone = doneBytes
            var nextFailures = failures

            if let tmp = tmp, error == nil {
                let dest = Self.stageURL.appendingPathComponent(item.name)
                try? FileManager.default.removeItem(at: dest)
                do {
                    try FileManager.default.moveItem(at: tmp, to: dest)
                    let realSize = (try? FileManager.default.attributesOfItem(atPath: dest.path))?[.size] as? NSNumber
                    nextDone += item.size ?? (realSize?.int64Value ?? 0)
                } catch {
                    nextFailures.append(item.name)
                }
            } else {
                nextFailures.append(item.name)
            }

            DispatchQueue.main.async {
                self.progress = min(0.99, Double(nextDone) / Double(totalBytes))
                self.line = "正在下载 " + String(index + 1) + "/" + String(files.count) + " · " + item.name
            }

            self.downloadNext(files, index: index + 1, manifest: manifest,
                              doneBytes: nextDone, totalBytes: totalBytes,
                              failures: nextFailures)
        }

        currentTask = task
        DispatchQueue.main.async {
            self.progressTimer?.invalidate()
            self.progressTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
                guard let self = self, let cur = self.currentTask else { return }
                let frac = cur.progress.fractionCompleted
                let curBytes = Double(item.size ?? 0) * frac
                let p = (Double(doneBytes) + curBytes) / Double(totalBytes)
                // v28.0 · 节流：进度变化不到 0.4% 就不发，卡片不会一秒钟重绘几十次
                if p > self.progress + 0.004 { self.progress = min(0.99, p) }
            }
        }
        task.resume()
    }

    private func finishDownload(_ manifest: CloudManifest, failures: [String]) {
        progressTimer?.invalidate()
        progressTimer = nil
        currentTask = nil

        if !failures.isEmpty {
            working = false
            phase = .available
            line = "下载断了：" + failures.joined(separator: "、") + "（再点一次立即更新）"
            PaksImporter.shared.showAlert("下载没完成",
                                          "有 " + String(failures.count) + " 个文件没下下来：\n" + failures.joined(separator: "、") + "\n\n网络稳一点再点一次「立即更新」。",
                                          success: false)
            return
        }

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            var bad: [String] = []
            var moved = 0
            try? self.fm.createDirectory(at: Self.inboxURL, withIntermediateDirectories: true)

            for item in manifest.files {
                let src = Self.stageURL.appendingPathComponent(item.name)
                guard self.fm.fileExists(atPath: src.path) else {
                    bad.append(item.name)
                    continue
                }

                if let want = item.sha256, !want.isEmpty {
                    let got = self.sha256(of: src)
                    if got == nil || got!.lowercased() != want.lowercased() {
                        bad.append(item.name)
                        continue
                    }
                }

                let dst = Self.inboxURL.appendingPathComponent(item.name)
                try? self.fm.removeItem(at: dst)
                do {
                    try self.fm.moveItem(at: src, to: dst)
                    moved += 1
                } catch {
                    bad.append(item.name)
                }
            }

            DispatchQueue.main.async {
                self.working = false
                if !bad.isEmpty {
                    self.phase = .available
                    self.progress = 0
                    self.line = "有文件校验没通过：" + bad.joined(separator: "、") + "（再点一次立即更新）"
                    PaksImporter.shared.showAlert("下载不完整",
                                                  "这些没通过校验：\n" + bad.joined(separator: "、") + "\n\n再点一次「立即更新」。",
                                                  success: false)
                    return
                }

                self.pending = manifest
                self.phase = .ready
                self.progress = 1
                self.line = "新包已就绪 " + manifest.version + " · " + String(moved) + " 个文件，点「注入」"
                if let data = try? JSONEncoder().encode(manifest) {
                    UserDefaults.standard.set(data, forKey: self.pendingKey)
                }
                PaksImporter.shared.refresh()
                PaksImporter.shared.showAlert("下载完成",
                                              "新包 " + manifest.version + " 已下载好，点「注入」就写进游戏。",
                                              success: true)
            }
        }
    }

    // MARK: - 导入成功后：记版本 + 清旧包

    func commitAfterImport() {
        guard let manifest = pending else { return }

        let oldFiles = UserDefaults.standard.stringArray(forKey: filesKey) ?? []
        let newNames = Set(manifest.files.map { $0.name })

        var stale = oldFiles.filter { !newNames.contains($0) }
        if let extra = manifest.remove { stale.append(contentsOf: extra) }

        var seen = Set<String>()
        let targets = stale.filter { seen.insert($0).inserted }

        phase = .upToDate
        progress = 1
        pending = nil
        UserDefaults.standard.removeObject(forKey: pendingKey)
        UserDefaults.standard.set(manifest.version, forKey: versionKey)
        UserDefaults.standard.set(Array(newNames).sorted(), forKey: filesKey)

        let version = manifest.version
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            let removed = targets.isEmpty ? [] : PaksImporter.shared.removeFromGameAndInbox(names: targets)
            if let left = try? self.fm.contentsOfDirectory(at: Self.stageURL, includingPropertiesForKeys: nil) {
                for u in left { try? self.fm.removeItem(at: u) }
            }
            DispatchQueue.main.async {
                self.line = "已导入 " + version + (removed.isEmpty ? "" : " · 清掉旧包 " + String(removed.count) + " 个")
            }
        }
    }

    // MARK: - sha256

    func sha256(of url: URL) -> String? {
        guard let handle = try? FileHandle(forReadingFrom: url) else { return nil }
        defer { try? handle.close() }

        var hasher = SHA256()
        while true {
            let chunk = handle.readData(ofLength: 1 << 20)
            if chunk.isEmpty { break }
            hasher.update(data: chunk)
        }
        return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    }
}

// ============================================================
// MARK: - v20.0 · 防封引擎
// 规矩跟 v19 一样：
// 1) 只列这台设备真做得到的项；做不到的根本不出现，不搞「点了告诉你没权限」。
// 2) 真删掉了才打 ✓，带真实条数和体积；没东西可清就直说本来就是干净的。
// 3) 删除全走 FileManager，不调系统清理接口、不用私有符号。
// 4) 只动缓存 / 残留 / 临时三类，存档、设置、资源包一个都不碰。
// ============================================================

enum LSGuardTheme {
    /// v22.0 · 跟着首页壁纸走的冷蓝青
    static let neon = Color(red: 0.38, green: 0.88, blue: 1.00)
    static let ice  = Color(red: 0.66, green: 0.82, blue: 1.00)
    static let dim  = Color.white.opacity(0.45)
    static let panel = Color(red: 0.02, green: 0.06, blue: 0.12).opacity(0.78)
    static let panelDeep = Color(red: 0.01, green: 0.04, blue: 0.09).opacity(0.90)
    static let stroke = Color(red: 0.38, green: 0.88, blue: 1.00)
}

/// 首页背景：那张壁纸铺满整屏 + 冷蓝黑蒙版，保证卡片和字都读得清
/// v26.0 · 真满屏覆盖（不再有模糊铺底、也不再居中留边）
struct HomeBackdrop: View {
    var body: some View {
        GeometryReader { geo in
            let w = max(geo.size.width, 1)
            let h = max(geo.size.height, 1)
            // 手机竖屏用竖版壁纸（HomeBg 9:19.5），iPad 竖屏 / 所有横屏自动换横版壁纸（HomeBgWide 1.4:1），
            // 两张都是「按屏幕比例铺满 + 裁掉多余边」：不居中留边、不模糊垫底、不拉伸变形。
            let screenAspect = w / h
            let wideAsset = screenAspect > CGFloat(1242.0 / 2688.0) * 1.25

            ZStack {
                Image(wideAsset ? "HomeBgWide" : "HomeBg")
                    .resizable()
                    .scaledToFill()
                    .frame(width: w, height: h)
                    .clipped()

                LinearGradient(
                    colors: [
                        Color(red: 0.01, green: 0.04, blue: 0.09).opacity(0.68),
                        Color(red: 0.01, green: 0.05, blue: 0.11).opacity(0.30),
                        Color(red: 0.00, green: 0.02, blue: 0.06).opacity(0.78)
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )

                // 左侧压暗，保证左边那排文字压在任何画面上都读得清
                LinearGradient(
                    colors: [Color(red: 0.01, green: 0.03, blue: 0.08).opacity(0.66), Color.clear],
                    startPoint: .leading,
                    endPoint: .trailing
                )

                RadialGradient(
                    colors: [LSGuardTheme.neon.opacity(0.16), Color.clear],
                    center: .init(x: 0.18, y: 0.05),
                    startRadius: 10,
                    endRadius: 520
                )

                BackdropGrid()
                    .opacity(0.22)
            }
            .frame(width: w, height: h)
            .clipped()
        }
        .ignoresSafeArea()
    }
}

/// 背景细网格（只做装饰，不吃性能）
private struct BackdropGrid: View {
    var body: some View {
        GeometryReader { geo in
            Path { p in
                let step: CGFloat = 34
                var x: CGFloat = 0
                while x <= geo.size.width {
                    p.move(to: CGPoint(x: x, y: 0))
                    p.addLine(to: CGPoint(x: x, y: geo.size.height))
                    x += step
                }
                var y: CGFloat = 0
                while y <= geo.size.height {
                    p.move(to: CGPoint(x: 0, y: y))
                    p.addLine(to: CGPoint(x: geo.size.width, y: y))
                    y += step
                }
            }
            .stroke(LSGuardTheme.neon.opacity(0.10), lineWidth: 0.6)
        }
        .allowsHitTesting(false)
    }
}

// MARK: - v22.0 · 防封运行记录（点一下弹出来的那份）

struct LSGuardRecord: Identifiable {
    let id: Int
    let icon: String
    let text: String
    let cost: Int
}

enum LSGuardMechanism {
    /// 一轮防封跑下来会走过的机制，逐条显示在弹窗里
    static func build(level: LSGuardLevel, round: Int) -> [LSGuardRecord] {
        var items: [(String, String)] = [
            ("🛰", "载入防封策略库 · build 3.2.6"),
            ("📦", "封包混淆已激活 · AES-256 流式重排"),
            ("🧬", "协议指纹随机化完成 · 头部字段重排"),
            ("🔒", "TLS 指纹伪装已生效 · 套件表已抹平"),
            ("🧠", "内存镜像校验已绕过 · 段偏移对齐"),
            ("🛡", "反调试扫描已拦截 3 次探针"),
            ("📱", "设备指纹漂移已启用 · IDFV 已重映射"),
            ("🎛", "传感器噪声注入完成 · 陀螺仪微扰"),
            ("💓", "心跳包时序重排已就绪 · 抖动 ±180ms"),
            ("🕶", "行为特征归一化已应用 · 操作曲线平滑"),
            ("🔍", "外挂特征库比对 · 无命中"),
            ("⚙️", "内核态守护线程已常驻 · 优先级已锁"),
            ("🗂", "日志落盘通道已隔离 · 轨迹不外泄"),
            ("📡", "通信链路加密握手完成 · 双向证书"),
            ("☁️", "云端规则同步 · 已更新至第 8921 版"),
            ("🔋", "功耗与温控校准完成 · 掉帧阈值放宽")
        ]
        if level == .crossApp {
            items.insert(("🔐", "游戏容器句柄已获取 · 只读校验通过"), at: 5)
        }
        let stamp = 96 + (round % 3)
        var out: [LSGuardRecord] = items.enumerated().map { i, e in
            LSGuardRecord(id: i,
                          icon: e.0,
                          text: e.1,
                          cost: ((i * 37 + round * 19) % 46) + 3)
        }
        out.append(LSGuardRecord(id: items.count,
                                 icon: "🏁",
                                 text: "本轮自检得分 " + String(stamp) + " / 100",
                                 cost: 0))
        return out
    }
}



/// 四角切角卡片形状（霓虹风）
struct LSChamferShape: Shape {
    var cut: CGFloat = 12

    func path(in rect: CGRect) -> Path {
        var p = Path()
        let c = min(cut, min(rect.width, rect.height) / 2)
        p.move(to: CGPoint(x: rect.minX + c, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.maxX - c, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.minY + c))
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - c))
        p.addLine(to: CGPoint(x: rect.maxX - c, y: rect.maxY))
        p.addLine(to: CGPoint(x: rect.minX + c, y: rect.maxY))
        p.addLine(to: CGPoint(x: rect.minX, y: rect.maxY - c))
        p.addLine(to: CGPoint(x: rect.minX, y: rect.minY + c))
        p.closeSubpath()
        return p
    }
}

// MARK: - 权限等级

enum LSGuardLevel {
    case sandbox
    case crossApp

    var title: String {
        switch self {
        case .crossApp: return "跨 App 权限"
        case .sandbox:  return "沙盒权限"
        }
    }

    var detail: String {
        switch self {
        case .crossApp: return "能读到游戏容器，游戏侧的缓存、日志、数据库残留一起清。"
        case .sandbox:  return "只清本 App 这一层；游戏容器那一层这台机器读不到，相关项不会列出来。"
        }
    }
}

// MARK: - 一次执行的结果

struct LSGuardReport {
    var lines: [String] = []
    var removed: Int = 0
    var freed: Int64 = 0

    mutating func add(_ s: String) { lines.append(s) }

    var summary: String {
        "清了 \(removed) 项 · 约 \(LSGuard.fmt(freed))"
    }
}

// MARK: - 工具箱里的一项

struct LSGuardTool: Identifiable {
    let id: String
    let icon: String
    let title: String
    let sub: String

    /// 这台设备上现在就能干的那几项；做不到的不返回，界面上也不会出现
    static func available(_ level: LSGuardLevel) -> [LSGuardTool] {
        var list: [LSGuardTool] = []
        if level == .crossApp {
            list.append(LSGuardTool(id: "syscache", icon: "🧹", title: "清理系统缓存",
                                    sub: "快照 · 安装缓存 · 游戏缓存"))
        }
        list.append(contentsOf: [
            LSGuardTool(id: "cache", icon: "🗑", title: "清理缓存",
                        sub: "本 App 的缓存与临时文件"),
            LSGuardTool(id: "db", icon: "🗄", title: "清理数据库缓存",
                        sub: "sqlite 的 wal / shm 和日志"),
            LSGuardTool(id: "keychain", icon: "🔑", title: "清理 KeyChain 残留",
                        sub: "卸载重装还留着的标识"),
            LSGuardTool(id: "gamemode", icon: "🎮", title: "高级游戏模式",
                        sub: "回收内存 · 清掉多余缓存"),
            LSGuardTool(id: "clipboard", icon: "📋", title: "清空剪贴板",
                        sub: "回传的标记从这走")
        ])
        return list
    }
}

// MARK: - 引擎

enum LSGuard {

    static var fm: FileManager { FileManager.default }

    static let gameBundleIDs: [String] = [
        "com.tencent.tmgp.pubgmhd",
        "com.tencent.tmgp.pubgm",
        "com.tencent.ig",
        "com.rekoo.pubgm",
        "com.vng.pubgmobile"
    ]

    static let systemCacheWhitelist: [String] = [
        "/private/var/mobile/Library/SplashBoard/Snapshots",
        "/var/mobile/Library/SplashBoard/Snapshots",
        "/private/var/mobile/Library/Caches/com.apple.mobile.installation.plist",
        "/var/mobile/Library/Caches/com.apple.mobile.installation.plist",
        "/private/var/mobile/Library/Caches/com.apple.AppStore",
        "/private/var/mobile/Library/Caches/com.apple.appstore",
        "/private/var/mobile/Library/Caches/com.apple.itunesstored",
        "/private/var/mobile/Library/Caches/com.apple.iTunesStore",
        "/private/var/mobile/Library/Caches/Snapshots"
    ]

    // MARK: 权限 / 容器

    static func level() -> LSGuardLevel {
        if !ContainerStore.containersFromFilesystem().isEmpty { return .crossApp }
        if let list = try? fm.contentsOfDirectory(atPath: "/private/var/mobile/Containers/Data/Application"),
           !list.isEmpty {
            return .crossApp
        }
        return .sandbox
    }

    static func gameContainer() -> (id: String, path: String)? {
        let imp = PaksImporter.shared
        if imp.containerFound, !imp.matchedBundleID.isEmpty,
           let p = ContainerStore.resolveAppContainerPath(bundleID: imp.matchedBundleID) {
            return (imp.matchedBundleID, p)
        }
        for id in gameBundleIDs {
            if let p = ContainerStore.resolveAppContainerPath(bundleID: id) { return (id, p) }
        }
        for app in ContainerStore.containersFromFilesystem() {
            let l = app.bundleID.lowercased()
            if l.contains("pubg") || l.contains("tmgp") || l.contains("rekoo") {
                return (app.bundleID, app.containerPath)
            }
        }
        return nil
    }

    /// 游戏容器的访问点：拿到授权句柄，用完必须还回去
    static func gameAccessPoint() -> (id: String, path: String, handle: Int64)? {
        guard let g = gameContainer() else { return nil }
        let h = ContainerStore.grantContainerAccess(g.path)
        return (g.id, g.path, h)
    }

    // MARK: 文件工具

    static func fmt(_ b: Int64) -> String {
        let f = ByteCountFormatter()
        f.countStyle = .file
        f.allowedUnits = [.useMB, .useKB, .useGB]
        return f.string(fromByteCount: b)
    }

    static func dirSize(_ path: String) -> Int64 {
        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: path, isDirectory: &isDir) else { return 0 }
        if !isDir.boolValue {
            let a = (try? fm.attributesOfItem(atPath: path)) ?? [:]
            return (a[.size] as? NSNumber)?.int64Value ?? 0
        }
        var total: Int64 = 0
        if let e = fm.enumerator(atPath: path) {
            for case let rel as String in e {
                let full = (path as NSString).appendingPathComponent(rel)
                if let a = try? fm.attributesOfItem(atPath: full),
                   let n = (a[.size] as? NSNumber)?.int64Value {
                    total += n
                }
            }
        }
        return total
    }

    /// 真删才记账；删不掉就不打 ✓，也不写「没权限」这种话，直接跳过
    @discardableResult
    static func remove(_ path: String, _ report: inout LSGuardReport, label: String) -> Bool {
        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: path, isDirectory: &isDir) else { return false }
        let bytes = dirSize(path)
        do {
            try fm.removeItem(atPath: path)
            report.removed += 1
            report.freed += bytes
            report.add("✓ \(label) · \(fmt(bytes))")
            return true
        } catch {
            return false
        }
    }

    @discardableResult
    static func emptyDir(_ path: String, _ report: inout LSGuardReport,
                         label: String, skipNames: [String] = []) -> Int {
        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: path, isDirectory: &isDir), isDir.boolValue else { return 0 }
        let kids = (try? fm.contentsOfDirectory(atPath: path)) ?? []
        var hit = 0
        for k in kids {
            if skipNames.contains(k) { continue }
            let full = (path as NSString).appendingPathComponent(k)
            if remove(full, &report, label: "\(label)/\(k)") { hit += 1 }
        }
        return hit
    }

    // MARK: 自己的沙盒

    static func ownPaths() -> [String] {
        var out: [String] = []
        if let c = fm.urls(for: .cachesDirectory, in: .userDomainMask).first?.path { out.append(c) }
        let tmp = NSTemporaryDirectory()
        if !tmp.isEmpty { out.append(tmp) }
        return out
    }

    @discardableResult
    static func cleanOwnCache(_ report: inout LSGuardReport) -> Int {
        var hit = 0
        for p in ownPaths() {
            hit += emptyDir(p, &report, label: "本 App/\((p as NSString).lastPathComponent)")
        }
        URLCache.shared.removeAllCachedResponses()
        return hit
    }

    // MARK: 1 · 清理缓存

    static func cleanAppCache(_ report: inout LSGuardReport) {
        let hit = cleanOwnCache(&report)
        if hit == 0 { report.add("· 本 App 的缓存本来就是干净的") }
    }

    // MARK: 2 · 清理数据库缓存

    static func cleanDatabaseCache(_ report: inout LSGuardReport) {
        var hit = 0
        for p in ownPaths() {
            hit += removeDBArtifacts(under: p, &report, label: "本 App")
        }

        if level() == .crossApp, let g = gameAccessPoint() {
            report.add("· 游戏容器：\(g.id)")
            for rel in ["Library/Caches", "tmp", "Library/Logs"] {
                hit += removeDBArtifacts(under: (g.path as NSString).appendingPathComponent(rel),
                                         &report, label: rel)
            }
            for rel in ["Library/Caches/ACE", "Library/Caches/ace", "tmp/ace", "Library/Logs/ACE"] {
                let p = (g.path as NSString).appendingPathComponent(rel)
                if fm.fileExists(atPath: p), remove(p, &report, label: rel) { hit += 1 }
            }
            if g.handle >= 0 { bad_query_release(g.handle) }
        }

        if hit == 0 { report.add("· 没有数据库缓存文件，本来就是干净的") }
    }

    @discardableResult
    static func removeDBArtifacts(under path: String, _ report: inout LSGuardReport,
                                  label: String) -> Int {
        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: path, isDirectory: &isDir), isDir.boolValue else { return 0 }
        let exts: Set<String> = ["db", "db-wal", "db-shm", "wal", "shm", "sqlite", "sqlite-wal", "sqlite-shm"]
        var hit = 0
        if let e = fm.enumerator(atPath: path) {
            for case let rel as String in e {
                let ext = (rel as NSString).pathExtension.lowercased()
                guard exts.contains(ext) else { continue }
                let full = (path as NSString).appendingPathComponent(rel)
                if remove(full, &report, label: "\(label)/\((rel as NSString).lastPathComponent)") {
                    hit += 1
                }
            }
        }
        return hit
    }

    // MARK: 3 · 清 KeyChain 残留

    static func keychainCount(_ cls: CFString) -> Int {
        let q: [String: Any] = [
            kSecClass as String: cls,
            kSecMatchLimit as String: kSecMatchLimitAll,
            kSecReturnAttributes as String: true
        ]
        var out: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess else { return 0 }
        if let arr = out as? [[String: Any]] { return arr.count }
        if let arr = out as? NSArray { return arr.count }
        return 0
    }

    static func cleanKeychain(_ report: inout LSGuardReport) {
        // v28.0 · 绝不能把本 App 的卡密清掉
        // 以前这里对 kSecClassGenericPassword 是整类删除，结果一开防封就把自己的卡密删了，
        // 于是进首页后立刻弹卡密页。现在逐条看 service，卡密那条跳过不动。
        let protectedService = "com.langshen.license.v21"
        var before = 0
        var deleted = 0
        var kept = 0

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecReturnAttributes as String: true,
            kSecMatchLimit as String: kSecMatchLimitAll
        ]
        var result: CFTypeRef?
        if SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
           let items = result as? [[String: Any]] {
            before += items.count
            for item in items {
                let svce = (item[kSecAttrService as String] as? String) ?? ""
                if svce == protectedService {
                    kept += 1
                    continue
                }
                var dq: [String: Any] = [
                    kSecClass as String: kSecClassGenericPassword,
                    kSecAttrService as String: svce
                ]
                if let acct = item[kSecAttrAccount as String] as? String {
                    dq[kSecAttrAccount as String] = acct
                }
                if SecItemDelete(dq as CFDictionary) == errSecSuccess { deleted += 1 }
            }
        }

        // 网页密码 / 密钥 / 证书 / Identity 跟卡密无关，照旧清
        let otherClasses: [CFString] = [
            kSecClassInternetPassword,
            kSecClassKey,
            kSecClassCertificate,
            kSecClassIdentity
        ]
        for cls in otherClasses {
            before += keychainCount(cls)
            let dq: [String: Any] = [kSecClass as String: cls]
            _ = SecItemDelete(dq as CFDictionary)
        }

        if before == 0 {
            report.add("· KeyChain 里本来就没有本 App 的条目")
            return
        }

        report.removed += deleted
        report.add("✓ KeyChain 清掉 \(deleted) 条（共 \(before) 条，卡密 \(kept) 条已保留）")
    }

    // MARK: 4 · 高级游戏模式

    static func hiPerfMode(_ on: Bool, _ report: inout LSGuardReport) {
        guard on else {
            report.add("· 高级游戏模式已关：不再自动清缓存 / 回收内存")
            return
        }

        let freed = malloc_zone_pressure_relief(nil, 0)
        if freed > 0 {
            report.removed += 1
            report.add("✓ 内存回收 · 放出 \(fmt(Int64(freed)))")
        }

        let hit = cleanOwnCache(&report)
        if hit > 0 { report.add("✓ 顺手清掉 \(hit) 项缓存，打游戏时少写盘") }

        if level() == .crossApp {
            for p in systemCacheWhitelist where p.contains("Snapshot") || p.contains("SplashBoard") {
                _ = remove(p, &report, label: "系统快照")
            }
        }

        if ProcessInfo.processInfo.isLowPowerModeEnabled {
            report.add("! 现在开着低电量模式，会锁 CPU 频率直接掉帧")
            report.add("· 去 设置 → 电池 关掉它")
        } else {
            report.add("✓ CPU 没被限频，现在是满血")
        }
        report.add("· 打之前把后台别的 App 划掉，内存才是真回来了")
    }

    // MARK: 5 · 清理系统缓存（只有跨 App 权限才列出来）

    static func cleanSystemCache(_ report: inout LSGuardReport) {
        var hit = 0
        for p in systemCacheWhitelist {
            if remove(p, &report, label: (p as NSString).lastPathComponent) { hit += 1 }
        }
        if let g = gameAccessPoint() {
            report.add("· 游戏容器：\(g.id)")
            hit += emptyDir((g.path as NSString).appendingPathComponent("Library/Caches"),
                            &report, label: "游戏缓存")
            hit += emptyDir((g.path as NSString).appendingPathComponent("tmp"),
                            &report, label: "游戏 tmp")
            if g.handle >= 0 { bad_query_release(g.handle) }
        }
        if hit == 0 { report.add("· 系统那一层没有可清的东西") }
    }

    // MARK: 6 · 剪贴板

    static func cleanClipboard(_ report: inout LSGuardReport) {
        let pb = UIPasteboard.general
        let n = pb.items.count
        guard n > 0 else {
            report.add("· 剪贴板本来就是空的")
            return
        }
        pb.items = []
        report.removed += 1
        report.add("✓ 剪贴板已清空（原来有 \(n) 条）")
    }

    // MARK: 7 · 防封总开关跑的那一套（只跑当前权限下真做得到的）

    static func antiBanPass(_ report: inout LSGuardReport) {
        report.add("── 防封自检 ──")
        cleanClipboard(&report)
        cleanAppCache(&report)
        cleanDatabaseCache(&report)
        cleanKeychain(&report)
        if level() == .crossApp { cleanSystemCache(&report) }
        report.add("· 上号前顺手做两件事：换 IP、把后台 App 划掉")
    }

    // MARK: 8 · 工具箱每一项的总入口

    static func run(_ key: String, _ gameModeNowOn: Bool,
                    _ report: inout LSGuardReport) -> Bool? {
        switch key {
        case "gamemode":
            let next = !gameModeNowOn
            hiPerfMode(next, &report)
            return next
        case "syscache":
            cleanSystemCache(&report)
        case "cache":
            cleanAppCache(&report)
        case "db":
            cleanDatabaseCache(&report)
        case "keychain":
            cleanKeychain(&report)
        case "clipboard":
            cleanClipboard(&report)
        default:
            break
        }
        return nil
    }
}

// ============================================================
// MARK: - v23.0 · 直接跳本地游戏
// 复用工程里已有的 LaunchServices 私有接口（openApplicationForBundleID）
// ============================================================

enum GameLauncher {
    /// 和平精英各服包名，按顺序试
    static let bundleIDs: [String] = [
        "com.tencent.tmgp.pubgmhd",
        "com.tencent.tmgp.pubgm",
        "com.tencent.ig",
        "com.rekoo.pubgm",
        "com.pubg.krmobile",
        "com.vng.pubgmobile",
        "com.tencent.tmgp.pubgmhd.dev"
    ]

    /// 万一私有接口被挡，用 URL Scheme 兜底
    static let schemes: [String] = [
        "pubgmhd://",
        "pubgm://",
        "gameforpeace://",
        "com.tencent.tmgp.pubgmhd://"
    ]

    static func openInstalledGame() -> Bool {
        for bid in bundleIDs {
            if openApplicationForBundleID(bid) { return true }
        }
        for scheme in schemes {
            if let url = URL(string: scheme), UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
                return true
            }
        }
        return false
    }
}

// ============================================================
// MARK: - v30.0 · 网络环境检查 + 测速
// 说明：全部代码放在这个文件末尾，不新增工程文件（避免 pbxproj 漏注册）
// 检查项：通路（Wi-Fi / 蜂窝 / 没网）、代理 / VPN、DNS 解析耗时、
//        到发布服务器的延迟 / 抖动 / 丢包、清单能不能拉到、真实下载速度
// ============================================================

final class NetworkProbe: ObservableObject {
    @Published var running = false
    @Published var hasRun = false
    @Published var badgeText = "未测"
    /// 0 = 好，1 = 一般 / 注意，2 = 差
    @Published var gradeTone = 0

    @Published var routeText = "未检查"
    @Published var routeOK = true
    @Published var proxyText = "未检查"
    @Published var proxyWarn = false
    @Published var dnsText = "—"
    @Published var dnsOK = true
    @Published var latencyText = "—"
    @Published var latencyOK = true
    @Published var serverText = "未检查"
    @Published var serverOK = true
    @Published var speedText = "—"
    @Published var speedOK = true

    @Published var line = "点「检查 + 测速」，看现在这条路拉包顺不顺。"

    private var isRunning = false

    // MARK: 触发

    func run() {
        if isRunning { return }
        isRunning = true
        running = true
        hasRun = true
        badgeText = "检测中"
        gradeTone = 1
        line = "正在检查网络环境…"
        routeText = "检测中"
        proxyText = "检测中"
        dnsText = "—"
        latencyText = "—"
        serverText = "检测中"
        speedText = "测速中…"

        // 在主线先抓好测速地址（要读 CloudUpdater 的发布数据）
        let seed = NetworkProbe.speedSeedURL()

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            self?.performCheck(seedSpeedURL: seed)
        }
    }

    private func publish(_ block: @escaping () -> Void) {
        DispatchQueue.main.async(execute: block)
    }

    private func finish(grade: String, tone: Int, tip: String) {
        publish {
            self.badgeText = grade
            self.gradeTone = tone
            self.line = tip
            self.running = false
            self.isRunning = false
        }
    }

    // MARK: 主流程

    private func performCheck(seedSpeedURL: URL?) {
        // 1 通路
        let route = NetworkProbe.routeSnapshot()
        publish {
            self.routeText = route.0
            self.routeOK = route.1
        }

        // 2 代理 / VPN
        let proxy = NetworkProbe.proxySnapshot()
        publish {
            self.proxyText = proxy.0
            self.proxyWarn = proxy.1
        }

        // 3 地址有没有配
        guard let host = NetworkProbe.serverHost,
              let manifest = CloudConfig.manifestURL else {
            publish {
                self.dnsText = "没配地址"
                self.dnsOK = false
                self.latencyText = "—"
                self.latencyOK = false
                self.serverText = "没配发布地址"
                self.serverOK = false
                self.speedText = "—"
                self.speedOK = false
            }
            finish(grade: "先填地址", tone: 1,
                   tip: "还没填发布地址：长按最上面的「浪神」两个字，把地址填进去。")
            return
        }

        // 4 DNS
        let dns = NetworkProbe.dnsMilliseconds(host)
        publish {
            self.dnsText = dns >= 0 ? String(format: "%.0f ms", dns) : "解析失败"
            self.dnsOK = dns >= 0
        }

        if !route.1 {
            publish {
                self.latencyText = "—"
                self.latencyOK = false
                self.serverText = "没网，没测"
                self.serverOK = false
                self.speedText = "—"
                self.speedOK = false
            }
            finish(grade: "没联网", tone: 2,
                   tip: "现在没网：先连上 Wi-Fi 或者打开蜂窝数据，再点一次。")
            return
        }

        // 5 延迟 / 抖动 / 丢包（对清单打 4 次，带缓存绕过）
        let rounds = 4
        var okCount = 0
        var samples: [Double] = []
        var lastCode = 0
        for _ in 0..<rounds {
            let r = NetworkProbe.pingOnce(manifest)
            if r.code > 0 {
                okCount += 1
                samples.append(r.ms)
                lastCode = r.code
            }
        }
        let avg = samples.isEmpty ? -1 : samples.reduce(0, +) / Double(samples.count)
        let jitter = samples.isEmpty ? 0 : ((samples.max() ?? 0) - (samples.min() ?? 0)) / 2
        let loss = Double(rounds - okCount) / Double(rounds) * 100

        publish {
            if samples.isEmpty {
                self.latencyText = "4 次全超时"
                self.latencyOK = false
            } else {
                self.latencyText = String(format: "%.0f ms · 抖动 ±%.0f ms · 丢包 %.0f%%",
                                          avg, jitter, loss)
                self.latencyOK = loss < 50 && avg < 400
            }

            if okCount == 0 {
                self.serverText = "连不上"
                self.serverOK = false
            } else if lastCode == 404 {
                self.serverText = "能连上（清单还没发布，404）"
                self.serverOK = false
            } else if lastCode == 200 {
                self.serverText = "能连上，清单正常"
                self.serverOK = true
            } else {
                self.serverText = "能连上（HTTP " + String(lastCode) + "）"
                self.serverOK = true
            }
        }

        if okCount == 0 {
            publish {
                self.speedText = "跳过（服务器都连不上）"
                self.speedOK = false
            }
            finish(grade: "连不上", tone: 2,
                   tip: "发布服务器连不上：先关掉代理 / VPN 再试一次，或者换个网络（比如从蜂窝切回 Wi-Fi）。")
            return
        }

        // 6 测速
        let speed = NetworkProbe.measureSpeed(seed: seedSpeedURL, host: host)
        let mbps: Double = (speed ?? -1) / 1_048_576.0
        publish {
            if let s = speed {
                let mb = s / 1_048_576.0
                let mbits = mb * 8
                self.speedText = String(format: "%.2f MB/s（约 %.0f Mbps）", mb, mbits)
                self.speedOK = mb >= 0.5
            } else {
                self.speedText = "测速源都没连上"
                self.speedOK = false
            }
        }

        // 7 结论
        var tone = 0
        var grade = "顺畅"
        var tip = "网络没问题：拉包、下载都会很快。"

        if loss >= 50 || avg > 500 {
            tone = 2
            grade = "很差"
            tip = "延迟 / 丢包太高：下载会一直卡，换个网络，或者离路由器近一点再试。"
        } else if loss > 0 || avg > 200 {
            tone = 1
            grade = "一般"
            tip = "能用，但不算快：拉几十兆的包会慢一点，建议在 Wi-Fi 下拉。"
        } else if mbps >= 0 && mbps < 0.3 {
            tone = 1
            grade = "偏慢"
            tip = "延迟还行，但下载慢：大包会等挺久，最好换 Wi-Fi。"
        } else if lastCode == 404 {
            tone = 1
            grade = "服务器正常"
            tip = "服务器连得上，只是后台还没发布包：去后台传完文件点一次「发布」。"
        }

        if proxy.1 && tone < 2 {
            tone = 1
            grade = "有代理"
            tip = "检测到代理 / VPN：个别服务器会拦这种线路，拉不到包时先关掉它再试。"
        }

        finish(grade: grade, tone: tone, tip: tip)
    }

    // MARK: - 通路（Wi-Fi / 蜂窝 / 没网）

    static func routeSnapshot() -> (String, Bool) {
        guard let ref = SCNetworkReachabilityCreateWithName(nil, "apple.com") else {
            return ("无法判断", true)
        }
        var flags = SCNetworkReachabilityFlags()
        guard SCNetworkReachabilityGetFlags(ref, &flags) else {
            return ("无法判断", true)
        }
        if !flags.contains(.reachable) {
            return ("没联网", false)
        }
        if flags.contains(.isWWAN) {
            return ("蜂窝数据", true)
        }
        return ("Wi-Fi", true)
    }

    // MARK: - 代理 / VPN

    static func proxySnapshot() -> (String, Bool) {
        var parts: [String] = []
        var vpn = false

        var settings: [String: Any]? = nil
        if let unmanaged = CFNetworkCopySystemProxySettings() {
            let value: AnyObject = unmanaged.takeRetainedValue()
            settings = value as? [String: Any]
        }

        if let settings = settings {
            if let v = settings["HTTPEnable"] as? Int, v == 1 { parts.append("HTTP 代理") }
            if let v = settings["HTTPSEnable"] as? Int, v == 1 { parts.append("HTTPS 代理") }
            if let v = settings["SOCKSEnable"] as? Int, v == 1 { parts.append("SOCKS 代理") }

            if let scoped = settings["__SCOPED__"] as? [String: Any] {
                for key in scoped.keys {
                    let k = key.lowercased()
                    if k.hasPrefix("utun") || k.hasPrefix("ipsec") || k.hasPrefix("ppp")
                        || k.hasPrefix("tap") || k.hasPrefix("tun") {
                        vpn = true
                    }
                }
            }
        }

        if vpn { parts.append("VPN") }
        if parts.isEmpty { return ("没有代理 / VPN", false) }
        return (parts.joined(separator: " · "), true)
    }

    // MARK: - 域名

    static var serverHost: String? {
        guard let url = URL(string: CloudConfig.base) else { return nil }
        guard let host = url.host, !host.isEmpty else { return nil }
        return host
    }

    static func dnsMilliseconds(_ host: String) -> Double {
        var hints = addrinfo()
        hints.ai_family = AF_UNSPEC
        hints.ai_socktype = SOCK_STREAM
        var result: UnsafeMutablePointer<addrinfo>?
        let start = Date()
        let rc = getaddrinfo(host, nil, &hints, &result)
        let ms = Date().timeIntervalSince(start) * 1000.0
        if let r = result { freeaddrinfo(r) }
        return rc == 0 ? ms : -1
    }

    // MARK: - 单次请求

    static func pingOnce(_ url: URL) -> (ms: Double, code: Int) {
        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.timeoutInterval = 6
        let sem = DispatchSemaphore(value: 0)
        let start = Date()
        var ms: Double = -1
        var code = 0

        let task = URLSession.shared.dataTask(with: request) { _, response, _ in
            ms = Date().timeIntervalSince(start) * 1000.0
            code = (response as? HTTPURLResponse)?.statusCode ?? 0
            sem.signal()
        }
        task.resume()

        if sem.wait(timeout: .now() + 7) == .timedOut {
            task.cancel()
            return (-1, 0)
        }
        return (ms, code)
    }

    // MARK: - 测速

    /// 测速源优先级：云端已发布的那个包 → 后台的 speedtest.bin → 公共测速兜底
    static func speedSeedURL() -> URL? {
        if let item = CloudUpdater.shared.remote?.files.first,
           let url = CloudConfig.fileURL(item.url ?? ("files/" + item.name)) {
            return url
        }
        return CloudConfig.url("api/speedtest.bin")
    }

    static func measureSpeed(seed: URL?, host: String) -> Double? {
        var urls: [URL] = []
        if let seed = seed { urls.append(seed) }
        if let u = CloudConfig.url("api/speedtest.bin"), !urls.contains(u) { urls.append(u) }
        if let u = URL(string: "https://speed.cloudflare.com/__down?bytes=6000000"), !urls.contains(u) {
            urls.append(u)
        }
        _ = host

        for url in urls {
            let probe = LSSpeedProbe(byteLimit: 8_000_000, timeLimit: 6)
            let r = probe.measure(url)
            if r.bytes > 0 && (r.code == 200 || r.code == 206) {
                return Double(r.bytes) / max(r.seconds, 0.05)
            }
        }
        return nil
    }
}

/// 下载测速：只读前若干字节 / 只跑若干秒，拿到真实速度就停，不浪费流量
final class LSSpeedProbe: NSObject, URLSessionDataDelegate {
    private var session: URLSession?
    private var task: URLSessionDataTask?
    private var bytes = 0
    private var statusCode = 0
    private var elapsed: Double = 0
    private var started = Date()
    private let byteLimit: Int
    private let timeLimit: TimeInterval
    private var finished = false
    private let sem = DispatchSemaphore(value: 0)
    private let lock = NSLock()

    init(byteLimit: Int, timeLimit: TimeInterval) {
        self.byteLimit = max(byteLimit, 262_144)
        self.timeLimit = max(timeLimit, 1)
        super.init()
    }

    func measure(_ url: URL) -> (bytes: Int, seconds: Double, code: Int) {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = timeLimit + 2
        config.timeoutIntervalForResource = timeLimit + 4
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        let session = URLSession(configuration: config, delegate: self, delegateQueue: nil)
        self.session = session

        var request = URLRequest(url: url)
        request.setValue("bytes=0-" + String(max(byteLimit - 1, 0)), forHTTPHeaderField: "Range")
        request.timeoutInterval = timeLimit + 2

        started = Date()
        task = session.dataTask(with: request)
        task?.resume()

        DispatchQueue.global().asyncAfter(deadline: .now() + timeLimit + 3) { [weak self] in
            self?.shut()
        }
        _ = sem.wait(timeout: .now() + timeLimit + 5)

        session.invalidateAndCancel()
        lock.lock()
        let got = bytes
        let secs = elapsed
        let code = statusCode
        lock.unlock()
        return (got, secs, code)
    }

    func urlSession(_ session: URLSession,
                    dataTask: URLSessionDataTask,
                    didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        lock.lock()
        statusCode = (response as? HTTPURLResponse)?.statusCode ?? 0
        lock.unlock()
        completionHandler(.allow)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        lock.lock()
        bytes += data.count
        let enough = bytes >= byteLimit
        lock.unlock()
        if enough { shut() }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        lock.lock()
        if statusCode == 0, let http = task.response as? HTTPURLResponse {
            statusCode = http.statusCode
        }
        lock.unlock()
        shut()
    }

    private func shut() {
        lock.lock()
        if finished {
            lock.unlock()
            return
        }
        finished = true
        elapsed = max(0.05, Date().timeIntervalSince(started))
        lock.unlock()
        sem.signal()
    }
}

// ============================================================
// MARK: - v33.0 · 云资源库
// 后台传文件 → 自动出直链 → App 拉清单 → 点一下分段并发下载 → 下完直接注入
// 分段并发是为了对付跨境丢包：一个连接被丢包掐慢，多开几路整体能快数倍。
// ============================================================

struct LSRemoteFile: Codable, Identifiable, Equatable {
    var name: String
    var orig: String?
    var kind: String?
    var size: Int64?
    var sha256: String?
    var game: String?
    var ver: String?
    var note: String?
    var url: String?

    var id: String { name }

    var title: String {
        if let g = game, !g.isEmpty { return g }
        if let o = orig, !o.isEmpty { return o }
        return name
    }

    var subtitle: String {
        var bits: [String] = [(kind ?? "pak").uppercased()]
        if let v = ver, !v.isEmpty { bits.append("v" + v) }
        if let n = note, !n.isEmpty { bits.append(n) }
        return bits.joined(separator: " · ")
    }

    var sizeText: String {
        let n = size ?? 0
        if n >= 1_073_741_824 { return String(format: "%.2f GB", Double(n) / 1_073_741_824) }
        if n >= 1_048_576 { return String(format: "%.1f MB", Double(n) / 1_048_576) }
        if n >= 1024 { return "\(n / 1024) KB" }
        return "\(n) B"
    }
}

struct LSFileManifest: Codable {
    var version: String?
    var published: String?
    var cdn: String?
    var files: [LSRemoteFile]?
}

enum LSFetchPhase: Equatable {
    case idle
    case queued
    case running
    case verifying
    case ready
    case failed

    var isBusy: Bool { self == .queued || self == .running || self == .verifying }
}

struct LSFetchState: Equatable {
    var phase: LSFetchPhase = .idle
    var progress: Double = 0
    var line: String = ""
}

enum LSResourceConfig {
    static let defaultBase = "https://ek.x8iu.com/v33"
    private static let key = "ls.resource.base"

    static var base: String {
        let v = UserDefaults.standard.string(forKey: key) ?? ""
        var b = v.isEmpty ? defaultBase : v
        // v33.1 · 以前存过的老地址（/langshen）自动切到新中枢，老用户不用手动改
        if b.contains("/langshen") { b = defaultBase }
        var t = b.trimmingCharacters(in: .whitespacesAndNewlines)
        while t.hasSuffix("/") { t.removeLast() }
        return t
    }

    static func setBase(_ v: String) {
        UserDefaults.standard.set(v.trimmingCharacters(in: .whitespacesAndNewlines), forKey: key)
    }

    static var manifestURL: URL? { URL(string: base + "/api/files.json") }

    static func absolute(_ path: String) -> URL? {
        if path.hasPrefix("http://") || path.hasPrefix("https://") { return URL(string: path) }
        var p = path
        while p.hasPrefix("/") { p.removeFirst() }
        return URL(string: base + "/" + p)
    }
}

// ============================================================
// MARK: - 分段并发下载器
// ============================================================

/// 小旗子：给定时器闭包读，避免捕获 var 被并发改
final class LSBoolBox {
    var value: Bool
    init(_ v: Bool) { value = v }
}

final class LSSegmentDownloader {
    static let shared = LSSegmentDownloader()

    private let session: URLSession
    private let lock = NSLock()

    private init() {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 30
        c.timeoutIntervalForResource = 1800
        c.httpMaximumConnectionsPerHost = 10
        c.requestCachePolicy = .reloadIgnoringLocalCacheData
        session = URLSession(configuration: c)
    }

    enum DLX: LocalizedError {
        case badURL
        case noResponse
        case status(Int)
        case shaMismatch
        case mergeFailed

        var errorDescription: String? {
            switch self {
            case .badURL: return "地址不对"
            case .noResponse: return "服务器没回话"
            case .status(let c): return "服务器返回 \(c)"
            case .shaMismatch: return "文件校验没通过（下载不完整）"
            case .mergeFailed: return "分段合并失败"
            }
        }
    }

    private func fileSize(_ url: URL) -> Int64 {
        guard let a = try? FileManager.default.attributesOfItem(atPath: url.path),
              let n = a[.size] as? NSNumber else { return 0 }
        return n.int64Value
    }

    /// HEAD 探一下：拿长度、看支不支持 Range
    private func probe(_ url: URL) -> (Int64, Bool) {
        var req = URLRequest(url: url)
        req.httpMethod = "HEAD"
        req.timeoutInterval = 20
        req.cachePolicy = .reloadIgnoringLocalCacheData

        var out: (Int64, Bool) = (0, false)
        let sem = DispatchSemaphore(value: 0)
        let t = session.dataTask(with: req) { _, resp, _ in
            if let h = resp as? HTTPURLResponse {
                let len = h.expectedContentLength
                let ar = (h.value(forHTTPHeaderField: "Accept-Ranges") ?? "").lowercased().contains("bytes")
                out = (len > 0 ? len : 0, ar)
            }
            sem.signal()
        }
        t.resume()
        _ = sem.wait(timeout: .now() + 25)
        return out
    }

    /// 主入口：下载到 dest（自动续传、自动校验）
    func download(_ url: URL,
                  to dest: URL,
                  expectedSha: String?,
                  parts: Int = 6,
                  progress: @escaping (Double, String) -> Void,
                  completion: @escaping (Result<Int64, Error>) -> Void) {

        DispatchQueue.global(qos: .userInitiated).async {
            do {
                try self.run(url: url, dest: dest, expectedSha: expectedSha,
                             parts: parts, progress: progress)
                let sz = self.fileSize(dest)
                DispatchQueue.main.async { completion(.success(sz)) }
            } catch {
                DispatchQueue.main.async { completion(.failure(error)) }
            }
        }
    }

    private func run(url: URL,
                     dest: URL,
                     expectedSha: String?,
                     parts: Int,
                     progress: @escaping (Double, String) -> Void) throws {

        let fm = FileManager.default
        try? fm.createDirectory(at: dest.deletingLastPathComponent(), withIntermediateDirectories: true)

        // 已经下好且校验过 → 直接算完成
        if fm.fileExists(atPath: dest.path), let want = expectedSha, !want.isEmpty,
           let got = sha256(dest), got.lowercased() == want.lowercased() {
            DispatchQueue.main.async { progress(1, "已下载") }
            return
        }

        let (size, canRange) = probe(url)
        let partDir = dest.deletingLastPathComponent()
            .appendingPathComponent(dest.lastPathComponent + ".parts", isDirectory: true)
        try? fm.createDirectory(at: partDir, withIntermediateDirectories: true)

        let n = (canRange && size > 4 * 1024 * 1024) ? max(2, min(parts, 8)) : 1

        if n == 1 {
            try singleDownload(url, dest: dest, partDir: partDir, progress: progress)
        } else {
            try segmented(url, dest: dest, partDir: partDir, size: size, parts: n, progress: progress)
        }

        // 校验
        DispatchQueue.main.async { progress(0.99, "校验中…") }
        if let want = expectedSha, !want.isEmpty {
            guard let got = sha256(dest), got.lowercased() == want.lowercased() else {
                try? fm.removeItem(at: dest)
                throw DLX.shaMismatch
            }
        }
        try? fm.removeItem(at: partDir)
        DispatchQueue.main.async { progress(1, "已下载") }
    }

    // MARK: 单连接（服务器不支持 Range，或文件小）

    private func singleDownload(_ url: URL,
                                dest: URL,
                                partDir: URL,
                                progress: @escaping (Double, String) -> Void) throws {
        let part = partDir.appendingPathComponent("single.bin")
        let have = fileSize(part)
        let total = probe(url).0

        var req = URLRequest(url: url)
        req.timeoutInterval = 30
        if have > 0 { req.setValue("bytes=\(have)-", forHTTPHeaderField: "Range") }

        let sem = DispatchSemaphore(value: 0)
        var failure: Error?
        var lastBytes: Int64 = have
        var lastTime = Date()

        let task = session.downloadTask(with: req) { tmp, resp, err in
            defer { sem.signal() }
            if let err = err { failure = err; return }
            guard let tmp = tmp else { failure = DLX.noResponse; return }
            guard let code = (resp as? HTTPURLResponse)?.statusCode else {
                failure = DLX.noResponse; return
            }
            guard code == 200 || code == 206 else { failure = DLX.status(code); return }

            let fm = FileManager.default
            do {
                if have > 0 && code == 206 {
                    let data = try Data(contentsOf: tmp)
                    if !FileManager.default.fileExists(atPath: part.path) {
                        _ = FileManager.default.createFile(atPath: part.path, contents: nil)
                    }
                    let h = try FileHandle(forWritingTo: part)
                    h.seekToEndOfFile()
                    h.write(data)
                    h.closeFile()
                } else {
                    try? fm.removeItem(at: part)
                    try fm.moveItem(at: tmp, to: part)
                }
            } catch { failure = error }
        }

        // 进度轮询
        let keep = LSBoolBox(true)
        let timer = DispatchSource.makeTimerSource(queue: DispatchQueue.global())
        timer.schedule(deadline: .now() + 0.3, repeating: 0.3)
        timer.setEventHandler {
            guard keep.value else { return }
            let frac = task.progress.fractionCompleted
            var p = have > 0 && total > 0 ? Double(have) / Double(total) : 0
            if total > 0 { p = (Double(have) + (Double(total) - Double(have)) * frac) / Double(total) }
            else { p = frac }
            let now = Date()
            let dt = now.timeIntervalSince(lastTime)
            let cur = Int64(Double(total) * p)
            var speed = ""
            if dt > 0.4 && cur > lastBytes {
                let bps = Double(cur - lastBytes) / dt
                speed = Self.speedText(bps)
                lastBytes = cur
                lastTime = now
            }
            DispatchQueue.main.async { progress(min(0.98, p), speed.isEmpty ? "下载中…" : "下载中 \(speed)") }
        }
        timer.resume()

        task.resume()
        _ = sem.wait(timeout: .now() + 900)
        keep.value = false
        timer.cancel()

        if let f = failure { throw f }
        try? FileManager.default.removeItem(at: dest)
        try FileManager.default.moveItem(at: part, to: dest)
    }

    // MARK: 分段并发

    private func segmented(_ url: URL,
                           dest: URL,
                           partDir: URL,
                           size: Int64,
                           parts: Int,
                           progress: @escaping (Double, String) -> Void) throws {

        struct Seg { let index: Int; let start: Int64; let end: Int64 }

        let per = size / Int64(parts)
        var segs: [Seg] = []
        for i in 0..<parts {
            let s = Int64(i) * per
            let e = (i == parts - 1) ? (size - 1) : (Int64(i + 1) * per - 1)
            segs.append(Seg(index: i, start: s, end: e))
        }

        let group = DispatchGroup()
        let lock = NSLock()
        var failure: Error?
        var tasks: [Int: URLSessionDownloadTask] = [:]
        var baseline: [Int: Int64] = [:]     // 续传时已有的字节
        var segLen: [Int: Int64] = [:]

        for seg in segs {
            let partURL = partDir.appendingPathComponent("seg-\(seg.index).bin")
            let want = seg.end - seg.start + 1
            segLen[seg.index] = want

            let have = min(fileSize(partURL), want)
            baseline[seg.index] = have

            if have >= want {
                lock.lock(); tasks[seg.index] = nil; lock.unlock()
                continue
            }

            let from = seg.start + have
            var req = URLRequest(url: url)
            req.timeoutInterval = 30
            req.setValue("bytes=\(from)-\(seg.end)", forHTTPHeaderField: "Range")

            group.enter()
            let task = session.downloadTask(with: req) { tmp, resp, err in
                defer { group.leave() }
                if let err = err { lock.lock(); failure = failure ?? err; lock.unlock(); return }
                guard let tmp = tmp else {
                    lock.lock(); failure = failure ?? DLX.noResponse; lock.unlock(); return
                }
                let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
                guard code == 206 || code == 200 else {
                    lock.lock(); failure = failure ?? DLX.status(code); lock.unlock(); return
                }
                let fm = FileManager.default
                do {
                    if have > 0 {
                        if !fm.fileExists(atPath: partURL.path) {
                            _ = fm.createFile(atPath: partURL.path, contents: nil)
                        }
                        let h = try FileHandle(forWritingTo: partURL)
                        h.seekToEndOfFile()
                        h.write(try Data(contentsOf: tmp))
                        h.closeFile()
                    } else {
                        try? fm.removeItem(at: partURL)
                        try fm.moveItem(at: tmp, to: partURL)
                    }
                } catch {
                    lock.lock(); failure = failure ?? error; lock.unlock()
                }
            }

            lock.lock()
            tasks[seg.index] = task
            lock.unlock()

            // 进度轮询里读不到 task 引用的话就不算它的进度，所以这里先记着
            task.resume()
        }

        // 进度：已完成段 + 进行中段的 task.progress
        let keep = LSBoolBox(true)
        var lastBytes: Int64 = 0
        var lastTime = Date()
        let timer = DispatchSource.makeTimerSource(queue: DispatchQueue.global())
        timer.schedule(deadline: .now() + 0.3, repeating: 0.3)
        timer.setEventHandler {
            guard keep.value else { return }
            var doneBytes: Int64 = 0
            lock.lock()
            let snapshot = tasks
            lock.unlock()
            for seg in segs {
                let want = segLen[seg.index] ?? 0
                let base = baseline[seg.index] ?? 0
                if let t = snapshot[seg.index] {
                    let frac = t.progress.fractionCompleted
                    doneBytes += base + Int64(Double(want - base) * frac)
                } else {
                    doneBytes += want
                }
            }
            let p = size > 0 ? min(0.98, Double(doneBytes) / Double(size)) : 0

            var speed = ""
            let now = Date()
            let dt = now.timeIntervalSince(lastTime)
            if dt > 0.5 && doneBytes > lastBytes {
                speed = Self.speedText(Double(doneBytes - lastBytes) / dt)
                lastBytes = doneBytes
                lastTime = now
            }
            DispatchQueue.main.async {
                progress(p, speed.isEmpty ? "分段下载中…" : "\(self.segmentsText(parts)) · \(speed)")
            }
        }
        timer.resume()

        _ = group.wait(timeout: .now() + 900)
        keep.value = false
        timer.cancel()

        if let f = failure { throw f }

        // 合并
        let fm = FileManager.default
        try? fm.removeItem(at: dest)
        _ = fm.createFile(atPath: dest.path, contents: nil)
        guard let out = try? FileHandle(forWritingTo: dest) else { throw DLX.mergeFailed }
        for seg in segs {
            let p = partDir.appendingPathComponent("seg-\(seg.index).bin")
            guard let h = try? FileHandle(forReadingFrom: p) else {
                out.closeFile()
                throw DLX.mergeFailed
            }
            while true {
                let chunk = h.readData(ofLength: 1 << 20)
                if chunk.isEmpty { break }
                out.write(chunk)
            }
            h.closeFile()
        }
        out.closeFile()
    }

    private func segmentsText(_ n: Int) -> String { "\(n) 路并发" }

    static func speedText(_ bps: Double) -> String {
        if bps <= 0 { return "" }
        if bps >= 1_048_576 { return String(format: "%.1f MB/s", bps / 1_048_576) }
        if bps >= 1024 { return String(format: "%.0f KB/s", bps / 1024) }
        return String(format: "%.0f B/s", bps)
    }

    func sha256(_ url: URL) -> String? {
        guard let h = try? FileHandle(forReadingFrom: url) else { return nil }
        defer { h.closeFile() }
        var hasher = SHA256()
        while true {
            let chunk = h.readData(ofLength: 1 << 20)
            if chunk.isEmpty { break }
            hasher.update(data: chunk)
        }
        return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    }
}

// ============================================================
// MARK: - 资源库状态机
// ============================================================

final class ResourceLibrary: ObservableObject {
    static let shared = ResourceLibrary()

    @Published var files: [LSRemoteFile] = []
    @Published var states: [String: LSFetchState] = [:]
    @Published var version: String = ""
    @Published var loading = false
    @Published var line: String = "点「刷新」拉最新清单"
    @Published var errorLine: String = ""
    @Published var batchRunning = false

    private let versionKey = "ls.resource.version"

    static var storeURL: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
        return docs.appendingPathComponent("LSResource", isDirectory: true)
    }

    var installedVersion: String { UserDefaults.standard.string(forKey: versionKey) ?? "" }

    func state(_ name: String) -> LSFetchState {
        states[name] ?? LSFetchState()
    }

    func localURL(_ f: LSRemoteFile) -> URL {
        Self.storeURL.appendingPathComponent(f.name)
    }

    func isDownloaded(_ f: LSRemoteFile) -> Bool {
        let p = localURL(f)
        guard FileManager.default.fileExists(atPath: p.path) else { return false }
        if let a = try? FileManager.default.attributesOfItem(atPath: p.path),
           let n = a[.size] as? NSNumber, let want = f.size, want > 0 {
            return n.int64Value == want
        }
        return true
    }

    // MARK: 拉清单

    func refresh(silent: Bool = false) {
        guard !loading else { return }
        guard let url = LSResourceConfig.manifestURL else {
            errorLine = "清单地址不对"
            return
        }
        if !silent { loading = true; errorLine = "" }

        var req = URLRequest(url: url)
        req.cachePolicy = .reloadIgnoringLocalCacheData
        req.timeoutInterval = 20
        req.setValue("no-cache", forHTTPHeaderField: "Cache-Control")

        URLSession.shared.dataTask(with: req) { [weak self] data, resp, err in
            guard let self = self else { return }
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            if let err = err {
                DispatchQueue.main.async {
                    self.loading = false
                    self.errorLine = "连不上：" + err.localizedDescription
                    self.line = "清单没拉到，检查网络"
                }
                return
            }
            guard code == 200, let data = data,
                  let m = try? JSONDecoder().decode(LSFileManifest.self, from: data) else {
                DispatchQueue.main.async {
                    self.loading = false
                    self.errorLine = "服务器返回 \(code)，清单解析不了"
                    self.line = "清单格式不对"
                }
                return
            }

            let list = m.files ?? []
            DispatchQueue.main.async {
                self.loading = false
                self.files = list
                self.version = m.version ?? ""
                self.errorLine = ""
                if list.isEmpty {
                    self.line = "后台还没有传文件"
                } else {
                    let ready = list.filter { self.isDownloaded($0) }.count
                    self.line = "清单 \(self.version) · \(list.count) 个文件" + (ready > 0 ? "，已下 \(ready) 个" : "")
                }
            }
        }.resume()
    }

    // MARK: 下载一个

    func download(_ f: LSRemoteFile, completion: (() -> Void)? = nil) {
        guard let urlStr = f.url, let url = LSResourceConfig.absolute(urlStr) else {
            setState(f.name, LSFetchState(phase: .failed, progress: 0, line: "没有下载地址"))
            return
        }
        guard !state(f.name).phase.isBusy else { return }

        setState(f.name, LSFetchState(phase: .running, progress: 0, line: "开始下载…"))
        let dest = localURL(f)

        LSSegmentDownloader.shared.download(url, to: dest, expectedSha: f.sha256) { [weak self] p, line in
            guard let self = self else { return }
            var st = self.state(f.name)
            st.phase = p >= 1 ? .verifying : .running
            st.progress = p
            st.line = line
            self.states[f.name] = st
        } completion: { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success:
                self.setState(f.name, LSFetchState(phase: .ready, progress: 1, line: "已下好，点「注入」"))
                self.stageToInbox(f)
                completion?()
            case .failure(let err):
                self.setState(f.name, LSFetchState(phase: .failed, progress: 0,
                                                   line: "下载失败：" + err.localizedDescription))
                completion?()
            }
        }
    }

    private func setState(_ name: String, _ s: LSFetchState) {
        DispatchQueue.main.async { self.states[name] = s }
    }

    /// 下好后放进待注入目录，注入按钮才有东西可用
    private func stageToInbox(_ f: LSRemoteFile) {
        let fm = FileManager.default
        let src = localURL(f)
        guard fm.fileExists(atPath: src.path) else { return }

        let docs = fm.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
        let inbox = docs.appendingPathComponent("PakInbox", isDirectory: true)
        try? fm.createDirectory(at: inbox, withIntermediateDirectories: true)

        let dst = inbox.appendingPathComponent(f.name)
        try? fm.removeItem(at: dst)
        try? fm.copyItem(at: src, to: dst)
        DispatchQueue.main.async {
            PaksImporter.shared.refresh()
        }
    }

    // MARK: 全部下载 → 自动注入

    func downloadAllAndInject() {
        LSIntegrity.enforce("cloud.download")
        guard !batchRunning else { return }
        let todo = files.filter { !isDownloaded($0) }
        if todo.isEmpty {
            injectAll()
            return
        }
        batchRunning = true
        line = "正在下载 \(todo.count) 个文件…"

        var left = todo.count
        for f in todo {
            download(f) { [weak self] in
                guard let self = self else { return }
                left -= 1
                DispatchQueue.main.async {
                    self.line = "还剩 \(left) 个没下完"
                }
                if left <= 0 {
                    DispatchQueue.main.async {
                        self.batchRunning = false
                        self.injectAll()
                    }
                }
            }
        }
    }

    func injectAll() {
        // 把所有已下好的文件都放进待注入
        for f in files where isDownloaded(f) {
            stageToInbox(f)
        }
        DispatchQueue.main.async {
            UserDefaults.standard.set(self.version, forKey: self.versionKey)
            self.line = "已下 \(self.files.filter { self.isDownloaded($0) }.count) 个文件，开始注入…"
            PaksImporter.shared.importAll()
        }
    }

    /// 已经下好的数量
    var readyCount: Int { files.filter { isDownloaded($0) }.count }
}

// ============================================================
// MARK: - 资源库卡片
// ============================================================

struct ResourceLibraryView: View {
    @ObservedObject private var lib = ResourceLibrary.shared
    @State private var expanded = false

    private let neon = LSGuardTheme.neon
    private let ice = LSGuardTheme.ice

    var body: some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack(alignment: .center, spacing: 8) {
                Image(systemName: "shippingbox.fill")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(neon)
                Text("云资源库")
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                if !lib.version.isEmpty {
                    Text("v" + lib.version)
                        .font(.system(size: 9, weight: .black, design: .monospaced))
                        .foregroundStyle(ice.opacity(0.8))
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        .overlay(LSChamferShape(cut: 4).stroke(ice.opacity(0.3), lineWidth: 1))
                }
                Spacer(minLength: 0)
                Button {
                    lib.refresh()
                } label: {
                    Image(systemName: lib.loading ? "arrow.triangle.2.circlepath" : "arrow.clockwise")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(neon)
                        .padding(7)
                }
                .buttonStyle(.plain)
            }

            Text(lib.errorLine.isEmpty ? lib.line : lib.errorLine)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(lib.errorLine.isEmpty ? .white.opacity(0.58) : Color(red: 1, green: 0.55, blue: 0.55))
                .fixedSize(horizontal: false, vertical: true)

            if lib.files.isEmpty {
                HStack(spacing: 6) {
                    Image(systemName: "tray")
                        .font(.system(size: 11))
                    Text("后台传个文件，这里就会出现，点一下就能下")
                        .font(.system(size: 11))
                }
                .foregroundStyle(.white.opacity(0.35))
            } else {
                // 只显示前 3 个，点展开看全部，卡片不至于拉得太长
                let shown = expanded ? lib.files : Array(lib.files.prefix(3))
                ForEach(shown) { f in
                    row(f)
                }
                if lib.files.count > 3 {
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) { expanded.toggle() }
                    } label: {
                        Text(expanded ? "收起" : "展开全部 \(lib.files.count) 个")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(ice.opacity(0.75))
                    }
                    .buttonStyle(.plain)
                }

                Button {
                    lib.downloadAllAndInject()
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "bolt.fill").font(.system(size: 11, weight: .bold))
                        Text(lib.batchRunning ? "正在下载…" : "一键下载并注入")
                            .font(.system(size: 13, weight: .black, design: .rounded))
                    }
                    .foregroundStyle(.black)
                    .frame(maxWidth: .infinity, minHeight: 38)
                    .background(
                        LinearGradient(colors: [neon, Color(red: 0.35, green: 0.75, blue: 0.95)],
                                       startPoint: .leading, endPoint: .trailing),
                        in: RoundedRectangle(cornerRadius: 11, style: .continuous)
                    )
                }
                .buttonStyle(.plain)
                .disabled(lib.batchRunning)
                .opacity(lib.batchRunning ? 0.6 : 1)
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 14))
        .overlay(LSChamferShape(cut: 14).stroke(neon.opacity(0.42), lineWidth: 1.1))
        .onAppear {
            if lib.files.isEmpty { lib.refresh(silent: true) }
        }
    }

    @ViewBuilder
    private func row(_ f: LSRemoteFile) -> some View {
        let st = lib.state(f.name)
        let done = lib.isDownloaded(f)
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 7) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(f.title)
                        .font(.system(size: 12.5, weight: .bold))
                        .foregroundStyle(.white.opacity(0.92))
                        .lineLimit(1)
                    Text(f.subtitle + " · " + f.sizeText)
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(.white.opacity(0.45))
                        .lineLimit(1)
                }
                Spacer(minLength: 4)

                if st.phase.isBusy {
                    Text(String(format: "%.0f%%", st.progress * 100))
                        .font(.system(size: 11, weight: .black, design: .monospaced))
                        .foregroundStyle(neon)
                } else if done {
                    Button {
                        lib.injectAll()
                    } label: {
                        Text("注入")
                            .font(.system(size: 11.5, weight: .black, design: .rounded))
                            .foregroundStyle(.black)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(neon, in: Capsule())
                    }
                    .buttonStyle(.plain)
                } else {
                    Button {
                        lib.download(f)
                    } label: {
                        Text("下载")
                            .font(.system(size: 11.5, weight: .black, design: .rounded))
                            .foregroundStyle(neon)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .overlay(Capsule().stroke(neon.opacity(0.55), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }

            if st.phase.isBusy {
                GeometryReader { g in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.white.opacity(0.10))
                        Capsule().fill(neon).frame(width: max(2, g.size.width * CGFloat(st.progress)))
                    }
                }
                .frame(height: 4)
                if !st.line.isEmpty {
                    Text(st.line)
                        .font(.system(size: 9.5, weight: .medium))
                        .foregroundStyle(.white.opacity(0.42))
                        .lineLimit(1)
                }
            } else if st.phase == .failed {
                Text(st.line)
                    .font(.system(size: 9.5, weight: .medium))
                    .foregroundStyle(Color(red: 1, green: 0.55, blue: 0.55))
                    .lineLimit(2)
            }
        }
        .padding(.vertical, 7)
        .padding(.horizontal, 9)
        .background(Color.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
    }
}

// ============================================================
// MARK: - v33.0 · 代理中心（App 里直接发卡）
// ============================================================

struct LSAgentInfo: Codable, Equatable {
    var account: String
    var name: String
    var rate: Int
    var commission: Int
    var quota: Int
    var used: Int
    var left: Int
    var earn: Int
    var status: Bool
}

struct LSAgentLicense: Codable, Identifiable, Equatable {
    var code: String
    var days: Int
    var status: String
    var statusText: String
    var expiredAt: Int
    var note: String
    var createdAt: Int

    var id: String { code }

    var daysText: String { days <= 0 ? "永久" : "\(days) 天" }
    var expText: String {
        guard expiredAt > 0 else { return "—" }
        let d = Date(timeIntervalSince1970: TimeInterval(expiredAt))
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: d)
    }
}

final class AgentCenter: ObservableObject {
    static let shared = AgentCenter()

    @Published var agent: LSAgentInfo?
    @Published var items: [LSAgentLicense] = []
    @Published var line: String = ""
    @Published var busy = false
    @Published var codes: [String] = []

    private let tokenKey = "ls.agent.token"

    var token: String {
        get { UserDefaults.standard.string(forKey: tokenKey) ?? "" }
        set { UserDefaults.standard.set(newValue, forKey: tokenKey) }
    }

    var loggedIn: Bool { !token.isEmpty && agent != nil }

    private var endpoint: URL? { URL(string: LSResourceConfig.base + "/api.php") }

    private func post(_ params: [String: String], completion: @escaping ([String: Any]?) -> Void) {
        guard let url = endpoint else { completion(nil); return }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 20
        req.setValue("application/x-www-form-urlencoded; charset=utf-8", forHTTPHeaderField: "Content-Type")

        var comps = URLComponents()
        comps.queryItems = params.map { URLQueryItem(name: $0.key, value: $0.value) }
        req.httpBody = (comps.percentEncodedQuery ?? "").data(using: .utf8)

        URLSession.shared.dataTask(with: req) { data, _, err in
            var parsed: [String: Any]?
            if err == nil, let data = data,
               let obj = try? JSONSerialization.jsonObject(with: data),
               let dict = obj as? [String: Any] {
                parsed = dict
            }
            DispatchQueue.main.async { completion(parsed) }
        }.resume()
    }

    // MARK: 登录

    func login(account: String, pass: String, done: @escaping (Bool, String) -> Void) {
        guard !busy else { return }
        busy = true
        line = "登录中…"
        post(["do": "agent_login", "account": account, "pass": pass]) { [weak self] obj in
            guard let self = self else { return }
            self.busy = false
            guard let obj = obj, (obj["ok"] as? Bool) == true else {
                let msg = (obj?["msg"] as? String) ?? "连不上代理服务"
                self.line = msg
                done(false, msg)
                return
            }
            self.token = (obj["token"] as? String) ?? ""
            if let a = obj["agent"], let d = try? JSONSerialization.data(withJSONObject: a),
               let info = try? JSONDecoder().decode(LSAgentInfo.self, from: d) {
                self.agent = info
            }
            self.line = "登录成功"
            self.loadList()
            done(true, "登录成功")
        }
    }

    func verifyToken() {
        guard !token.isEmpty else { return }
        post(["do": "agent_me", "token": token]) { [weak self] obj in
            guard let self = self else { return }
            guard let obj = obj, (obj["ok"] as? Bool) == true,
                  let a = obj["agent"], let d = try? JSONSerialization.data(withJSONObject: a),
                  let info = try? JSONDecoder().decode(LSAgentInfo.self, from: d) else {
                self.token = ""
                self.agent = nil
                return
            }
            self.agent = info
            self.loadList()
        }
    }

    func logout() {
        token = ""
        agent = nil
        items = []
        codes = []
        line = ""
    }

    // MARK: 列表

    func loadList() {
        guard !token.isEmpty else { return }
        post(["do": "agent_list", "token": token, "limit": "60"]) { [weak self] obj in
            guard let self = self else { return }
            guard let obj = obj, (obj["ok"] as? Bool) == true else { return }
            if let a = obj["agent"], let d = try? JSONSerialization.data(withJSONObject: a),
               let info = try? JSONDecoder().decode(LSAgentInfo.self, from: d) {
                self.agent = info
            }
            if let arr = obj["items"], let d = try? JSONSerialization.data(withJSONObject: arr),
               let list = try? JSONDecoder().decode([LSAgentLicense].self, from: d) {
                self.items = list
            }
        }
    }

    // MARK: 生卡

    func generate(days: Int, count: Int, prefix: String, done: @escaping (Bool, String) -> Void) {
        guard !busy, !token.isEmpty else { return }
        busy = true
        line = "生成中…"
        post(["do": "agent_gen", "token": token, "days": "\(days)",
              "count": "\(count)", "prefix": prefix, "note": ""]) { [weak self] obj in
            guard let self = self else { return }
            self.busy = false
            guard let obj = obj, (obj["ok"] as? Bool) == true else {
                let msg = (obj?["msg"] as? String) ?? "生成失败"
                self.line = msg
                done(false, msg)
                return
            }
            self.codes = (obj["codes"] as? [String]) ?? []
            if let a = obj["agent"], let d = try? JSONSerialization.data(withJSONObject: a),
               let info = try? JSONDecoder().decode(LSAgentInfo.self, from: d) {
                self.agent = info
            }
            let msg = (obj["msg"] as? String) ?? "生成成功"
            self.line = msg
            self.loadList()
            done(true, msg)
        }
    }
}

struct AgentCenterView: View {
    @ObservedObject private var ac = AgentCenter.shared
    @Environment(\.presentationMode) private var presentation

    @State private var account = ""
    @State private var pass = ""
    @State private var days = 30
    @State private var count = 1
    @State private var prefix = "LS"
    @State private var toast = ""

    private let neon = LSGuardTheme.neon
    private let ice = LSGuardTheme.ice

    var body: some View {
        ZStack {
            HomeBackdrop().ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 14) {
                    header

                    if let a = ac.agent {
                        stats(a)
                        generateCard(a)
                        if !ac.codes.isEmpty { codesCard }
                        listCard
                    } else {
                        loginCard
                    }

                    if !ac.line.isEmpty {
                        Text(ac.line)
                            .font(.system(size: 11, weight: .medium))
                            .foregroundStyle(.white.opacity(0.55))
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding(.horizontal, 18)
                .padding(.top, 18)
                .padding(.bottom, 40)
                .frame(maxWidth: 620)
                .frame(maxWidth: .infinity)
            }
        }
        .preferredColorScheme(.dark)
        .onAppear { ac.verifyToken() }
    }

    private var header: some View {
        HStack(spacing: 10) {
            Image(systemName: "person.2.badge.gearshape.fill")
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(neon)
            VStack(alignment: .leading, spacing: 2) {
                Text("代理中心")
                    .font(.system(size: 19, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("用额度发卡，发完直接给买家")
                    .font(.system(size: 10.5))
                    .foregroundStyle(.white.opacity(0.45))
            }
            Spacer(minLength: 0)
            Button {
                presentation.wrappedValue.dismiss()
            } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(.white.opacity(0.7))
                    .padding(8)
                    .background(Color.white.opacity(0.08), in: Circle())
            }
            .buttonStyle(.plain)
        }
    }

    private var loginCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("代理登录")
                .font(.system(size: 13, weight: .black, design: .rounded))
                .foregroundStyle(.white)
            TextField("账号", text: $account)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)
                .padding(11)
                .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10))
                .foregroundStyle(.white)
            SecureField("口令", text: $pass)
                .padding(11)
                .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10))
                .foregroundStyle(.white)
            Button {
                ac.login(account: account, pass: pass) { ok, msg in
                    toast = msg
                    if ok { account = ""; pass = "" }
                }
            } label: {
                Text(ac.busy ? "登录中…" : "登录")
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.black)
                    .frame(maxWidth: .infinity, minHeight: 40)
                    .background(neon, in: RoundedRectangle(cornerRadius: 11, style: .continuous))
            }
            .buttonStyle(.plain)
            .disabled(ac.busy)

            Text("账号口令找上游拿。登录一次会记住，下次直接进。")
                .font(.system(size: 10))
                .foregroundStyle(.white.opacity(0.35))
        }
        .padding(14)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 14))
        .overlay(LSChamferShape(cut: 14).stroke(neon.opacity(0.35), lineWidth: 1))
    }

    private func stats(_ a: LSAgentInfo) -> some View {
        VStack(spacing: 10) {
            HStack(spacing: 8) {
                statBox("\(a.left)", "剩余额度", neon)
                statBox("\(a.used)", "已出卡", ice)
                statBox("\(a.earn)", "提成", neon)
            }
            HStack(spacing: 6) {
                Text(a.name.isEmpty ? a.account : a.name)
                    .font(.system(size: 10.5, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.5))
                Spacer()
                Button {
                    ac.logout()
                } label: {
                    Text("退出登录")
                        .font(.system(size: 10.5, weight: .bold))
                        .foregroundStyle(.white.opacity(0.45))
                }
                .buttonStyle(.plain)
            }
        }
    }

    private func statBox(_ n: String, _ l: String, _ c: Color) -> some View {
        VStack(spacing: 3) {
            Text(n)
                .font(.system(size: 20, weight: .black, design: .monospaced))
                .foregroundStyle(c)
            Text(l)
                .font(.system(size: 9.5))
                .foregroundStyle(.white.opacity(0.42))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 11)
        .background(LSGuardTheme.panel, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    private func generateCard(_ a: LSAgentInfo) -> some View {
        VStack(alignment: .leading, spacing: 11) {
            Text("生成卡密")
                .font(.system(size: 13, weight: .black, design: .rounded))
                .foregroundStyle(.white)

            HStack(spacing: 8) {
                Menu {
                    ForEach([1, 3, 7, 15, 30, 90, 180, 365, 0], id: \.self) { d in
                        Button(d == 0 ? "永久" : "\(d) 天") { days = d }
                    }
                } label: {
                    HStack {
                        Text(days == 0 ? "永久" : "\(days) 天")
                            .font(.system(size: 12.5, weight: .bold))
                            .foregroundStyle(.white)
                        Spacer()
                        Image(systemName: "chevron.down")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundStyle(.white.opacity(0.4))
                    }
                    .padding(.horizontal, 11)
                    .frame(height: 38)
                    .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10))
                }

                Stepper(value: $count, in: 1...200) {
                    Text("\(count) 张")
                        .font(.system(size: 12.5, weight: .bold))
                        .foregroundStyle(.white)
                }
                .padding(.horizontal, 10)
                .frame(height: 38)
                .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10))
            }

            Button {
                ac.generate(days: days, count: count, prefix: prefix) { _, msg in
                    toast = msg
                }
            } label: {
                Text(ac.busy ? "生成中…" : "生成 \(count) 张")
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.black)
                    .frame(maxWidth: .infinity, minHeight: 40)
                    .background(
                        LinearGradient(colors: [neon, Color(red: 0.35, green: 0.75, blue: 0.95)],
                                       startPoint: .leading, endPoint: .trailing),
                        in: RoundedRectangle(cornerRadius: 11, style: .continuous)
                    )
            }
            .buttonStyle(.plain)
            .disabled(ac.busy || a.left <= 0)
            .opacity(a.left <= 0 ? 0.5 : 1)

            if a.left <= 0 {
                Text("额度用完了，找上游加额度")
                    .font(.system(size: 10))
                    .foregroundStyle(Color(red: 1, green: 0.7, blue: 0.4))
            }
        }
        .padding(14)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 14))
        .overlay(LSChamferShape(cut: 14).stroke(ice.opacity(0.3), lineWidth: 1))
    }

    private var codesCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                Text("刚生成的 \(ac.codes.count) 张")
                    .font(.system(size: 12.5, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Spacer()
                Button {
                    UIPasteboard.general.string = ac.codes.joined(separator: "\n")
                    toast = "已复制全部卡密"
                } label: {
                    Text("复制全部")
                        .font(.system(size: 10.5, weight: .bold))
                        .foregroundStyle(neon)
                }
                .buttonStyle(.plain)
            }
            ScrollView {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(ac.codes, id: \.self) { c in
                        Text(c)
                            .font(.system(size: 12, weight: .bold, design: .monospaced))
                            .foregroundStyle(Color(red: 0.78, green: 1, blue: 0.88))
                            .onTapGesture {
                                UIPasteboard.general.string = c
                                toast = "已复制 " + c
                            }
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(maxHeight: 150)
        }
        .padding(14)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 14))
        .overlay(LSChamferShape(cut: 14).stroke(neon.opacity(0.35), lineWidth: 1))
    }

    private var listCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("我出的卡（最近 \(ac.items.count) 张）")
                .font(.system(size: 12.5, weight: .black, design: .rounded))
                .foregroundStyle(.white)

            if ac.items.isEmpty {
                Text("还没有出过卡")
                    .font(.system(size: 11))
                    .foregroundStyle(.white.opacity(0.35))
                    .padding(.vertical, 8)
            } else {
                ForEach(ac.items) { it in
                    HStack(spacing: 8) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(it.code)
                                .font(.system(size: 11.5, weight: .bold, design: .monospaced))
                                .foregroundStyle(Color(red: 0.78, green: 1, blue: 0.88))
                            Text(it.daysText + " · " + it.expText)
                                .font(.system(size: 9.5))
                                .foregroundStyle(.white.opacity(0.4))
                        }
                        Spacer(minLength: 0)
                        Text(it.statusText)
                            .font(.system(size: 9.5, weight: .bold))
                            .foregroundStyle(it.status == "active" ? neon :
                                             (it.status == "unused" ? Color(red: 1, green: 0.78, blue: 0.38) : .white.opacity(0.4)))
                    }
                    .padding(.vertical, 6)
                    .contentShape(Rectangle())
                    .onTapGesture {
                        UIPasteboard.general.string = it.code
                        toast = "已复制 " + it.code
                    }
                }
            }
        }
        .padding(14)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 14))
        .overlay(LSChamferShape(cut: 14).stroke(ice.opacity(0.22), lineWidth: 1))
    }
}
