//
//  IntegrityGuard.swift
//  OGIOS
//
//  v33.4 · 二进制自校验（防篡改 / 防二次打包）
//
//  原理：
//    1. 源码里留一个固定长度的「印章槽」(sealToken)，编译后它落在 Mach-O 的只读段里；
//    2. 流水线编译完成后，把 __text / __cstring / __const / __ustring 的摘要
//       写进这个槽（计算摘要时跳过槽本身，形成闭环）；
//    3. App 运行时重新算一遍摘要，跟槽里的值比；
//    4. 对不上 = 有人改过指令或字符串 = 立刻让进程死。
//
//  为什么重签不受影响：
//    摘要只覆盖 __TEXT 段里的四个只读 section，不碰 mach_header / load commands，
//    所以换证书重签、改 Bundle ID、换显示名都不会误崩。
//
//  注意：sealToken 的写法、长度、掩码必须与 Tools/stamp_integrity.py 完全一致。
//

import Foundation
import Darwin
import MachO

enum LSIntegrity {

    // MARK: - 印章槽（长度 / 结构必须与盖章脚本一致）

    /// 编译期占位；流水线会把中间 64 个 0 换成真实摘要。
    /// 这个字符串必须被代码真实引用，否则会被编译器丢掉。
    static let sealToken = "LSINTG<0000000000000000000000000000000000000000000000000000000000000000>IGNTSL"

    static let openTag  = "LSINTG<"
    static let closeTag = ">IGNTSL"
    static let hexCount = 64
    static let sealLength = 78          // 7 + 64 + 7

    /// 参与校验的 section（顺序固定，脚本端同样顺序）
    static let watchedSections = ["__text", "__cstring", "__const", "__ustring"]

    /// 32 字节掩码：槽里存的不是明文摘要，是摘要 XOR 掩码 XOR 位置扰动。
    private static let mask: [UInt8] = [
        0x3A, 0x91, 0x07, 0xCE, 0x64, 0x2B, 0xF8, 0x15,
        0xAC, 0x58, 0xE3, 0x76, 0x0D, 0xB2, 0x4F, 0xC9,
        0x81, 0x36, 0xDD, 0x1A, 0x97, 0x40, 0x6B, 0xE5,
        0x28, 0x73, 0xBC, 0x0F, 0xD4, 0x69, 0x92, 0x5E
    ]

    // MARK: - 状态

    private static let lock = NSLock()
    private static var cachedVerdict: Bool?

    /// 是否已判定被改过（一旦为真不再翻转）
    private(set) static var compromised = false

    // MARK: - 对外

    /// App 一起来就在后台算，绝不挡首帧。
    /// 算完发现被改过 → 直接让进程死，不需要等任何界面事件。
    static func warmUp() {
        // 真实引用印章常量，确保它不会被编译器丢掉
        _ = sealToken.utf8.count
        DispatchQueue.global(qos: .userInitiated).async {
            if verdict() { return }
            compromised = true
            terminate()
        }
    }

    /// 关键路径埋点：校验不过就让进程死。
    /// - Parameter site: 只用于内部日志，不会暴露给用户界面。
    @inline(never)
    static func enforce(_ site: String) {
        lock.lock()
        let cached = cachedVerdict
        lock.unlock()

        if let cached = cached {
            if cached { return }
            compromised = true
            terminate()
        }

        // 还没算完：主线程绝不等（不能拿启动速度换），后台那次算完自己会处理。
        if Thread.isMainThread { return }

        if verdict() { return }
        compromised = true
        terminate()
    }

    /// 只问不杀，给内部做降级用（不改变崩溃策略时用不到）。
    @inline(never)
    static func isIntact() -> Bool { verdict() }

    // MARK: - 判定

    @inline(never)
    private static func verdict() -> Bool {
        lock.lock()
        if let cached = cachedVerdict {
            lock.unlock()
            return cached
        }
        lock.unlock()

        let result = evaluate()

        lock.lock()
        if cachedVerdict == nil { cachedVerdict = result }
        let final = cachedVerdict ?? result
        lock.unlock()
        return final
    }

    private static func evaluate() -> Bool {
        // 反调试 / 反注入：命中直接判失败
        if hasDebugger() || hasInjectedLibrary() { return false }

        guard let image = selfImage() else { return false }
        guard let sections = watchedSectionRefs(image) else { return false }
        guard let seal = locateSeal(in: image) else { return false }

        // 槽还是占位符（没盖章）→ Release 下按篡改处理
        let stored = seal.hexBytes
        if stored.allSatisfy({ $0 == 0 }) {
            #if DEBUG
            return true
            #else
            return false
            #endif
        }

        let digest = computeDigest(sections: sections, skipping: seal.range)
        let expected = unmask(stored)
        return constantTimeEqual(digest, expected)
    }

    // MARK: - 自身镜像解析

    private struct ImageInfo {
        let header: UnsafePointer<mach_header_64>
        let slide: Int
        let textSegment: UnsafePointer<segment_command_64>
    }

    private static func selfImage() -> ImageInfo? {
        // 主可执行文件必定是 image 0
        guard let raw = _dyld_get_image_header(0) else { return nil }
        let header = UnsafeRawPointer(raw).assumingMemoryBound(to: mach_header_64.self)
        guard header.pointee.magic == 0xfeedfacf else { return nil }   // MH_MAGIC_64

        var cursor = UnsafeRawPointer(header).advanced(by: MemoryLayout<mach_header_64>.size)
        var textSeg: UnsafePointer<segment_command_64>?

        for _ in 0..<Int(header.pointee.ncmds) {
            let cmd = cursor.assumingMemoryBound(to: load_command.self).pointee
            guard cmd.cmdsize >= UInt32(MemoryLayout<load_command>.size) else { break }
            if cmd.cmd == UInt32(LC_SEGMENT_64) {
                let seg = cursor.assumingMemoryBound(to: segment_command_64.self)
                if fixedName(seg.pointee.segname) == "__TEXT" { textSeg = seg }
            }
            cursor = cursor.advanced(by: Int(cmd.cmdsize))
        }
        guard let seg = textSeg else { return nil }
        return ImageInfo(header: header, slide: _dyld_get_image_vmaddr_slide(0), textSegment: seg)
    }

    private struct SectionBytes {
        let name: String
        let pointer: UnsafeRawPointer
        let size: Int
        let range: Range<UnsafeRawPointer>  // 运行时地址区间
    }

    private static func watchedSectionRefs(_ image: ImageInfo) -> [String: SectionBytes]? {
        var found: [String: SectionBytes] = [:]
        let seg = image.textSegment
        var sect = UnsafeRawPointer(seg).advanced(by: MemoryLayout<segment_command_64>.size)
            .assumingMemoryBound(to: section_64.self)

        for _ in 0..<Int(seg.pointee.nsects) {
            let s = sect.pointee
            let name = fixedName(s.sectname)
            if watchedSections.contains(name), s.size > 0 {
                let vm = UInt(s.addr) &+ UInt(bitPattern: image.slide)
                if let ptr = UnsafeRawPointer(bitPattern: vm) {
                    let size = Int(s.size)
                    found[name] = SectionBytes(name: name, pointer: ptr, size: size,
                                               range: ptr..<(ptr + size))
                }
            }
            sect = sect.advanced(by: 1)
        }
        return found.isEmpty ? nil : found
    }

    // MARK: - 印章定位

    private struct Seal {
        let hexBytes: [UInt8]      // 原始（已掩码）的 32 字节
        let range: Range<UnsafeRawPointer>
    }

    private static func locateSeal(in image: ImageInfo) -> Seal? {
        let openBytes = Array(openTag.utf8)
        let closeBytes = Array(closeTag.utf8)
        let span = sealLength

        let seg = image.textSegment
        var sect = UnsafeRawPointer(seg).advanced(by: MemoryLayout<segment_command_64>.size)
            .assumingMemoryBound(to: section_64.self)

        for _ in 0..<Int(seg.pointee.nsects) {
            let s = sect.pointee
            defer { sect = sect.advanced(by: 1) }
            guard s.size >= UInt64(span) else { continue }
            let vm = UInt(s.addr) &+ UInt(bitPattern: image.slide)
            guard let base = UnsafeRawPointer(bitPattern: vm) else { continue }
            let size = Int(s.size)
            let bytes = base.assumingMemoryBound(to: UInt8.self)

            var i = 0
            let last = size - span
            let openCount = openBytes.count
            let closeCount = closeBytes.count
            while i <= last {
                if bytes[i] == openBytes[0],
                   matches(bytes + i, openBytes),
                   matches(bytes + i + span - closeCount, closeBytes) {
                    let hexStart = i + openCount
                    var raw = [UInt8](repeating: 0, count: 32)
                    var ok = true
                    for b in 0..<32 {
                        let hi = hexValue(bytes[hexStart + b * 2])
                        let lo = hexValue(bytes[hexStart + b * 2 + 1])
                        guard let h = hi, let l = lo else { ok = false; break }
                        raw[b] = (h << 4) | l
                    }
                    if ok {
                        return Seal(hexBytes: raw, range: base..<(base + span))
                    }
                }
                i += 1
            }
        }
        return nil
    }

    // MARK: - 摘要

    private static func computeDigest(sections: [String: SectionBytes],
                                      skipping sealRange: Range<UnsafeRawPointer>) -> [UInt8] {
        var hasher = LSHA256()

        for name in watchedSections {
            guard let section = sections[name] else { continue }
            var lengthField = UInt64(section.size).littleEndian
            withUnsafeBytes(of: &lengthField) { hasher.update($0.baseAddress, count: 8) }

            let start = section.range.lowerBound
            let end = section.range.upperBound

            if sealRange.lowerBound >= start, sealRange.upperBound <= end {
                let before = start..<sealRange.lowerBound
                let after = sealRange.upperBound..<end
                hasher.update(before.lowerBound, count: before.count)
                hasher.update(after.lowerBound, count: after.count)
            } else {
                hasher.update(start, count: section.size)
            }
        }
        return hasher.finalize()
    }

    // MARK: - 掩码

    private static func unmask(_ raw: [UInt8]) -> [UInt8] {
        var out = [UInt8](repeating: 0, count: 32)
        for i in 0..<32 {
            out[i] = raw[i] ^ mask[i] ^ UInt8(truncatingIfNeeded: i &* 37 &+ 0x5A)
        }
        return out
    }

    // MARK: - 反调试 / 反注入

    private static func hasDebugger() -> Bool {
        var info = kinfo_proc()
        var size = MemoryLayout<kinfo_proc>.stride
        var mib: [Int32] = [CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid()]
        guard sysctl(&mib, UInt32(mib.count), &info, &size, nil, 0) == 0 else { return false }
        return (info.kp_proc.p_flag & P_TRACED) != 0
    }

    private static func hasInjectedLibrary() -> Bool {
        if let v = getenv("DYLD_INSERT_LIBRARIES"), String(cString: v).isEmpty == false {
            return true
        }
        let banned = ["MobileSubstrate", "CydiaSubstrate", "Substitute", "TweakInject",
                      "frida-agent", "libfrida", "libhooker", "ElleKit"]
        let count = _dyld_image_count()
        for i in 0..<count {
            guard let namePtr = _dyld_get_image_name(i) else { continue }
            let name = String(cString: namePtr)
            if banned.contains(where: { name.contains($0) }) { return true }
        }
        return false
    }

    // MARK: - 终止

    /// 让进程以「野指针」的姿态死掉，不留下任何自定义文案。
    @inline(never)
    private static func terminate() -> Never {
        // 先让所有正在跑的异步任务没有意义
        DispatchQueue.main.async {
            let guardPage = UnsafeMutableRawPointer(bitPattern: 0x1000)!
            guardPage.storeBytes(of: UInt64.max, as: UInt64.self)
        }
        // 后台线程也直接踩空
        let guardPage = UnsafeMutableRawPointer(bitPattern: 0x1000)!
        guardPage.storeBytes(of: UInt64.max, as: UInt64.self)
        abort()
    }

    // MARK: - 小工具

    private static func constantTimeEqual(_ a: [UInt8], _ b: [UInt8]) -> Bool {
        guard a.count == b.count else { return false }
        var diff: UInt8 = 0
        for i in 0..<a.count { diff |= a[i] ^ b[i] }
        return diff == 0
    }

    private static func matches(_ lhs: UnsafePointer<UInt8>, _ rhs: [UInt8]) -> Bool {
        for i in 0..<rhs.count where lhs[i] != rhs[i] { return false }
        return true
    }

    private static func hexValue(_ c: UInt8) -> UInt8? {
        switch c {
        case 0x30...0x39: return c - 0x30
        case 0x61...0x66: return c - 0x61 + 10
        case 0x41...0x46: return c - 0x41 + 10
        default: return nil
        }
    }

    private static func fixedName<T>(_ tuple: T) -> String {
        var value = tuple
        return withUnsafeBytes(of: &value) { raw in
            guard let base = raw.baseAddress?.assumingMemoryBound(to: CChar.self) else { return "" }
            return String(cString: base)
        }
    }
}

// MARK: - SHA-256（自成一体，不依赖 CommonCrypto 桥接）

struct LSHA256 {
    private var h0: UInt32 = 0x6a09e667
    private var h1: UInt32 = 0xbb67ae85
    private var h2: UInt32 = 0x3c6ef372
    private var h3: UInt32 = 0xa54ff53a
    private var h4: UInt32 = 0x510e527f
    private var h5: UInt32 = 0x9b05688c
    private var h6: UInt32 = 0x1f83d9ab
    private var h7: UInt32 = 0x5be0cd19

    private var buffer = [UInt8](repeating: 0, count: 64)
    private var buffered = 0
    private var total: UInt64 = 0

    private static let k: [UInt32] = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    ]

    mutating func update(_ pointer: UnsafeRawPointer?, count: Int) {
        guard let pointer = pointer, count > 0 else { return }
        total &+= UInt64(count)
        let src = pointer.assumingMemoryBound(to: UInt8.self)
        var offset = 0
        while offset < count {
            if buffered == 64 {
                transform()
                buffered = 0
            }
            let take = min(64 - buffered, count - offset)
            let at = buffered
            buffer.withUnsafeMutableBytes { dst in
                memcpy(dst.baseAddress!.advanced(by: at), src.advanced(by: offset), take)
            }
            buffered += take
            offset += take
        }
    }

    mutating func update(_ bytes: [UInt8]) {
        bytes.withUnsafeBytes { update($0.baseAddress, count: $0.count) }
    }

    mutating func finalize() -> [UInt8] {
        let bitLength = total &* 8
        var pad: [UInt8] = [0x80]
        let padCount = (buffered < 56) ? (56 - buffered) : (120 - buffered)
        pad.append(contentsOf: [UInt8](repeating: 0, count: padCount - 1))
        update(pad)   // 只用于填充，bitLength 已在上面取走

        var lengthBytes = [UInt8](repeating: 0, count: 8)
        for i in 0..<8 { lengthBytes[7 - i] = UInt8(truncatingIfNeeded: bitLength >> (UInt64(i) * 8)) }
        for byte in lengthBytes {
            buffer[buffered] = byte
            buffered += 1
        }
        transform()
        buffered = 0

        var out = [UInt8]()
        out.reserveCapacity(32)
        for word in [h0, h1, h2, h3, h4, h5, h6, h7] {
            out.append(UInt8(truncatingIfNeeded: word >> 24))
            out.append(UInt8(truncatingIfNeeded: word >> 16))
            out.append(UInt8(truncatingIfNeeded: word >> 8))
            out.append(UInt8(truncatingIfNeeded: word))
        }
        return out
    }

    private mutating func transform() {
        var w = [UInt32](repeating: 0, count: 64)
        for i in 0..<16 {
            let j = i * 4
            w[i] = (UInt32(buffer[j]) << 24) | (UInt32(buffer[j + 1]) << 16)
                 | (UInt32(buffer[j + 2]) << 8) | UInt32(buffer[j + 3])
        }
        for i in 16..<64 {
            let s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >> 3)
            let s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >> 10)
            w[i] = w[i - 16] &+ s0 &+ w[i - 7] &+ s1
        }

        var a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7

        for i in 0..<64 {
            let s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)
            let ch = (e & f) ^ (~e & g)
            let temp1 = h &+ s1 &+ ch &+ LSHA256.k[i] &+ w[i]
            let s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)
            let maj = (a & b) ^ (a & c) ^ (b & c)
            let temp2 = s0 &+ maj

            h = g; g = f; f = e
            e = d &+ temp1
            d = c; c = b; b = a
            a = temp1 &+ temp2
        }

        h0 &+= a; h1 &+= b; h2 &+= c; h3 &+= d
        h4 &+= e; h5 &+= f; h6 &+= g; h7 &+= h
    }

    private func rotr(_ x: UInt32, _ n: UInt32) -> UInt32 {
        (x >> n) | (x << (32 - n))
    }
}
