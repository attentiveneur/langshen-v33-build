#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
stamp_integrity.py — 给二进制盖章（防篡改校验值写入）

用法：
    python3 stamp_integrity.py <可执行文件>          # 盖章
    python3 stamp_integrity.py <可执行文件> --verify # 只校验

原理：
    源码里有一个固定长度的占位串 LSINTG<...>IGNTSL。
    本脚本找出它，算出 __text / __cstring / __const / __ustring 的摘要
    （计算时跳过占位串自身），把摘要混淆后写回占位串。
    运行时 App 用同一套算法重算，对不上就崩。

    >>> 算法细节必须与 Sources/helpers/IntegrityGuard.swift 完全一致 <<<
"""

import hashlib
import struct
import sys

OPEN_TAG = b"LSINTG<"
CLOSE_TAG = b">IGNTSL"
HEX_COUNT = 64
SEAL_LEN = len(OPEN_TAG) + HEX_COUNT + len(CLOSE_TAG)   # 78

WATCHED = ["__text", "__cstring", "__const", "__ustring"]

MASK = bytes([
    0x3A, 0x91, 0x07, 0xCE, 0x64, 0x2B, 0xF8, 0x15,
    0xAC, 0x58, 0xE3, 0x76, 0x0D, 0xB2, 0x4F, 0xC9,
    0x81, 0x36, 0xDD, 0x1A, 0x97, 0x40, 0x6B, 0xE5,
    0x28, 0x73, 0xBC, 0x0F, 0xD4, 0x69, 0x92, 0x5E,
])

MH_MAGIC_64 = 0xFEEDFACF
FAT_MAGIC = 0xCAFEBABE
FAT_MAGIC_64 = 0xCAFEBABF
LC_SEGMENT_64 = 0x19


class Fail(Exception):
    pass


def mask_digest(digest):
    """摘要 <-> 槽内容，双向同一个函数"""
    assert len(digest) == 32
    return bytes(digest[i] ^ MASK[i] ^ ((i * 37 + 0x5A) & 0xFF) for i in range(32))


def cstr(raw):
    return raw.split(b"\x00", 1)[0].decode("ascii", "ignore")


def slices(data):
    """返回 [(offset, size)]，支持 fat 与 thin"""
    if len(data) < 8:
        raise Fail("文件太短")
    magic = struct.unpack_from(">I", data, 0)[0]
    if magic in (FAT_MAGIC, FAT_MAGIC_64):
        n = struct.unpack_from(">I", data, 4)[0]
        if n == 0 or n > 32:
            raise Fail("fat 头异常 nfat=%d" % n)
        out = []
        for i in range(n):
            if magic == FAT_MAGIC:
                _, _, off, size, _ = struct.unpack_from(">iiIII", data, 8 + i * 20)
            else:
                _, _, off, size, _, _ = struct.unpack_from(">iiQQII", data, 8 + i * 32)
            out.append((off, size))
        return out
    return [(0, len(data))]


def parse_sections(data, base, size):
    """返回 {section_name: (file_offset, size)}"""
    magic = struct.unpack_from("<I", data, base)[0]
    if magic != MH_MAGIC_64:
        raise Fail("不是 64 位 Mach-O（magic=0x%08x）" % magic)
    ncmds = struct.unpack_from("<I", data, base + 16)[0]
    cur = base + 32
    sections = {}
    for _ in range(ncmds):
        cmd, cmdsize = struct.unpack_from("<II", data, cur)
        if cmdsize < 8:
            raise Fail("load command 异常")
        if cmd == LC_SEGMENT_64:
            segname = cstr(data[cur + 8:cur + 24])
            nsects = struct.unpack_from("<I", data, cur + 64)[0]
            if segname == "__TEXT":
                s = cur + 72
                for _ in range(nsects):
                    sectname = cstr(data[s:s + 16])
                    ssize = struct.unpack_from("<Q", data, s + 40)[0]
                    soff = struct.unpack_from("<I", data, s + 48)[0]
                    if sectname in WATCHED and ssize > 0:
                        if ssize > size:
                            raise Fail("section %s 尺寸越界" % sectname)
                        # 注意：section 的 offset 是相对本分片起点的，要加上分片基址
                        sections[sectname] = (base + soff, ssize)
                    s += 80
        cur += cmdsize
    return sections


def find_seal(data, sections):
    """在已解析的 section 里找印章，返回 (绝对文件偏移, 原始 32 字节)"""
    for name in WATCHED:
        if name not in sections:
            continue
        off, size = sections[name]
        blob = data[off:off + size]
        start = 0
        while True:
            i = blob.find(OPEN_TAG, start)
            if i < 0:
                break
            if i + SEAL_LEN <= len(blob):
                tail = blob[i + SEAL_LEN - len(CLOSE_TAG):i + SEAL_LEN]
                if tail == CLOSE_TAG:
                    hexpart = blob[i + len(OPEN_TAG):i + len(OPEN_TAG) + HEX_COUNT]
                    try:
                        raw = bytes.fromhex(hexpart.decode("ascii"))
                    except Exception:
                        raw = None
                    if raw is not None and len(raw) == 32:
                        return off + i, raw
            start = i + 1
    # 印章也可能落在没被 watch 的只读 section 里，兜底全链搜
    i = data.find(OPEN_TAG)
    while i >= 0:
        if i + SEAL_LEN <= len(data) and data[i + SEAL_LEN - len(CLOSE_TAG):i + SEAL_LEN] == CLOSE_TAG:
            try:
                raw = bytes.fromhex(data[i + len(OPEN_TAG):i + len(OPEN_TAG) + HEX_COUNT].decode("ascii"))
                if len(raw) == 32:
                    return i, raw
            except Exception:
                pass
        i = data.find(OPEN_TAG, i + 1)
    raise Fail("没找到印章槽 LSINTG<...>IGNTSL —— 源码里的 sealToken 是不是被改掉了？")


def compute_digest(data, sections, seal_off):
    h = hashlib.sha256()
    seal_end = seal_off + SEAL_LEN
    for name in WATCHED:
        if name not in sections:
            continue
        off, size = sections[name]
        h.update(struct.pack("<Q", size))
        if off <= seal_off and seal_end <= off + size:
            before = off
            after = seal_end
            h.update(data[before:seal_off])
            h.update(data[after:off + size])
        else:
            h.update(data[off:off + size])
    return h.digest()


def stamp(path, verify_only=False):
    with open(path, "rb") as f:
        data = bytearray(f.read())

    stems = slices(data)
    if len(stems) == 0:
        raise Fail("没有可处理的分片")

    report = []
    for base, size in stems:
        sections = parse_sections(data, base, size)
        if "__text" not in sections:
            raise Fail("分片里找不到 __text（offset=%d）" % base)
        seal_off, stored = find_seal(data, sections)
        digest = compute_digest(data, sections, seal_off)

        if stored == b"\x00" * 32:
            state = "未盖章"
        elif mask_digest(stored) == digest:
            state = "一致"
        else:
            state = "不一致"

        if verify_only:
            report.append("  分片 @%d：%s（当前摘要 %s）" % (base, state, digest.hex()[:16]))
            if state != "一致":
                raise Fail("校验失败：分片 @%d 状态 %s" % (base, state))
            continue

        new_raw = mask_digest(digest)
        hex_start = seal_off + len(OPEN_TAG)
        data[hex_start:hex_start + HEX_COUNT] = new_raw.hex().encode("ascii")

        # 回验：跳过槽位重算，必须还是同一个摘要
        check = compute_digest(data, sections, seal_off)
        if check != digest:
            raise Fail("盖章后回验失败（算法不一致）")
        report.append("  分片 @%d：%s → 已写入 %s" % (base, state, digest.hex()[:16]))

    if not verify_only:
        with open(path, "wb") as f:
            f.write(data)
    return report


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    path = sys.argv[1]
    verify_only = "--verify" in sys.argv[2:]
    try:
        rep = stamp(path, verify_only=verify_only)
    except Fail as e:
        print("STAMP_FAIL: %s" % e)
        return 1
    print("STAMP_%s" % ("VERIFIED" if verify_only else "OK"))
    for line in rep:
        print(line)
    return 0


if __name__ == "__main__":
    sys.exit(main())
