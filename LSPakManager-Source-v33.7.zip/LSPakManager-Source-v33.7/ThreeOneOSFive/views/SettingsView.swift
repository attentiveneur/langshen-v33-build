import SwiftUI
import UIKit

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @State private var securityReport: String?
    // v33.6 · 防篡改结论改成后台算好再显示。
    // 以前在 body 里同步调用两次，第一次要把整个程序算一遍摘要（主线程），
    // 进设置页会顿一下甚至一阵白。
    @State private var intactFlag: Bool?
    // v33.7 · 运行流畅度（卡顿记录）
    @State private var perfReport: String?

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 14) {
                        VStack(alignment: .leading, spacing: 3) {
                            Text("OGIOS").font(.headline)
                            Text(language.text("common.version", appVersion))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 4)
                }

                Section(language.text("settings.language")) {
                    Picker(language.text("settings.language"), selection: $languageCode) {
                        ForEach(AppLanguage.allCases) { option in
                            Text(option.displayName).tag(option.rawValue)
                        }
                    }
                    .pickerStyle(.segmented)
                    .labelsHidden()
                }

                Section(language.text("common.device")) {
                    LabeledContent(language.text("dashboard.hardware_model"), value: AppInfo.displayMachineName)
                    LabeledContent(language.text("settings.ios_version"), value: "\(AppInfo.osVersion) (\(AppInfo.osBuild))")
                }

                Section {
                    HStack {
                        Text(language.text("settings.current_version"))
                        Spacer()
                        Text(language.text(appState.isSupported ? "settings.supported" : "settings.unsupported"))
                        .foregroundStyle(appState.isSupported ? Color.green : Color.red)
                    }
                    LabeledContent("iOS 17", value: ExploitSupportPolicy.verifiedIOS17Range)
                    LabeledContent("iOS 18", value: ExploitSupportPolicy.verifiedIOS18Range)
                    LabeledContent("iOS 26", value: ExploitSupportPolicy.verifiedIOS26Range)
                    VStack(alignment: .leading, spacing: 8) {
                        Text("iOS 27.0")
                            .font(.body)
                        ForEach(ExploitSupportPolicy.verifiedIOS27Builds, id: \.build) { version in
                            Text(versionLabel(version))
                            .font(.caption.monospaced())
                            .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 2)
                } header: {
                    Text(language.text("settings.verified_versions"))
                } footer: {
                    Text(language.text("settings.supported_versions_footer"))
                }

                Section {
                    Button {
                        // 报告也在后台生成，别让主线程卡着
                        self.securityReport = "正在生成自检报告…"
                        DispatchQueue.global(qos: .userInitiated).async {
                            let text = LSIntegrity.diagnosticText()
                            DispatchQueue.main.async { self.securityReport = text }
                        }
                    } label: {
                        HStack(spacing: 12) {
                            Text("安全自检")
                                .foregroundStyle(.primary)
                            Spacer()
                            Text(intactFlag == nil ? "检测中…" : (intactFlag == true ? "正常" : "异常"))
                                .font(.subheadline)
                                .foregroundStyle(intactFlag == nil ? Color.secondary : (intactFlag == true ? Color.green : Color.orange))
                            Image(systemName: "chevron.right")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundStyle(.tertiary)
                        }
                        .contentShape(Rectangle())
                    }
                } header: {
                    Text("防篡改")
                } footer: {
                    Text("检查这版程序有没有被改过。显示「异常」就把整页截图发我。")
                }

                Section {
                    Button {
                        perfReport = LSPerf.report()
                    } label: {
                        HStack(spacing: 12) {
                            Text("运行流畅度")
                                .foregroundStyle(.primary)
                            Spacer()
                            Text("看卡顿记录")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                            Image(systemName: "chevron.right")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundStyle(.tertiary)
                        }
                        .contentShape(Rectangle())
                    }
                } header: {
                    Text("性能")
                } footer: {
                    Text("觉得卡就点开截图发我。这里记的是主线程真被堵住的次数和时长，不是感觉。")
                }

            }
            .tint(AppTheme.accent)
            .scrollContentBackground(.hidden)
            .background(AppTheme.pageBackground)
            .task {
                // v33.6 · 进页面先在后台把摘要算完，算好再更新结论，不挡主线程
                guard intactFlag == nil else { return }
                let value = await Task.detached(priority: .utility) { LSIntegrity.isIntact() }.value
                intactFlag = value
            }
            .sheet(isPresented: Binding(
                get: { securityReport != nil },
                set: { if !$0 { securityReport = nil } }
            )) {
                NavigationStack {
                    ScrollView {
                        Text(securityReport ?? "")
                            .font(.system(size: 12, weight: .regular, design: .monospaced))
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(16)
                    }
                    .background(AppTheme.pageBackground)
                    .navigationTitle("安全自检")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .navigationBarLeading) {
                            Button("复制") {
                                UIPasteboard.general.string = securityReport ?? ""
                            }
                        }
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button("完成") { securityReport = nil }
                                .fontWeight(.semibold)
                        }
                    }
                }
            }
            .sheet(isPresented: Binding(
                get: { perfReport != nil },
                set: { if !$0 { perfReport = nil } }
            )) {
                NavigationStack {
                    ScrollView {
                        Text(perfReport ?? "")
                            .font(.system(size: 12, weight: .regular, design: .monospaced))
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(16)
                    }
                    .background(AppTheme.pageBackground)
                    .navigationTitle("运行流畅度")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .navigationBarLeading) {
                            Button("复制") {
                                UIPasteboard.general.string = perfReport ?? ""
                            }
                        }
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button("完成") { perfReport = nil }
                                .fontWeight(.semibold)
                        }
                    }
                }
            }
            .navigationTitle(language.text("settings.title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(language.text("common.done")) { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "1.0"
    }

    private func versionLabel(
        _ version: (beta: Int, publicBeta: Int?, build: String)
    ) -> String {
        if let publicBeta = version.publicBeta {
            return language.text(
                "settings.developer_public_beta_build",
                Int64(version.beta),
                Int64(publicBeta),
                version.build
            )
        }
        return language.text(
            "settings.developer_beta_build",
            Int64(version.beta),
            version.build
        )
    }

    @ViewBuilder
    private func creditsRow(name: String, role: String, url: String) -> some View {
        if let destination = URL(string: url) {
            Link(destination: destination) {
                HStack(spacing: 12) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(name)
                            .font(.headline)
                            .foregroundStyle(.primary)
                        Text(role)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Image(systemName: "arrow.up.right")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(AppTheme.accent)
                        .frame(width: 28, height: 28)
                }
                .contentShape(Rectangle())
            }
            .accessibilityLabel(language.text("accessibility.open_profile", name))
        }
    }
}
