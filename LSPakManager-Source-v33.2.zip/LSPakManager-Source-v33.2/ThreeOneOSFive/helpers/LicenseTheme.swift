import Foundation
import SwiftUI
import UIKit
import Combine

// ============================================================
// v25.0 · 卡密窗口在线换装
// ------------------------------------------------------------
// 后台（ek.x8iu.com/index.php →「卡密窗口」）改文案 / 配色 / 背景图，
// 保存后写 api/license-theme.json，App 每次进卡密页拉一次：
//   · version 变了就整套换掉
//   · 背景图 / 标志图下载到本机 Caches，断网用上次那张
//   · 服务端没配、拉不到、内容坏了 → 一律回落到内置默认（就是现在这套）
// 不会因为后台挂了就把用户挡在门外。
// ============================================================

struct LicenseTheme: Codable, Equatable {
    /// 每次后台保存 +1，App 靠它判断要不要换
    var version: Int = 0

    // 文案
    var title: String = "浪神"
    var subtitle: String = "清残留 防封号 玩得稳"
    var section: String = "授权验证"
    var fieldLabel: String = "请输入浪神卡密"
    var placeholder: String = "请输入您的授权码"
    var button: String = "立即验证"
    var footer: String = "卡密可在官方渠道获取"
    var copyright: String = "浪神 2026 版权 @浪神所有"

    // 配色（#RRGGBB）
    var primary: String = "#29EB85"
    var secondary: String = "#12A38F"
    var accent: String = "#8F70F5"
    var inputText: String = "#1A1A1A"

    // 版式
    var dim: Double = 0.62          // 压暗强度 0.15 – 0.95
    var corner: Double = 28         // 输入框 / 按钮圆角
    var showShield: Bool = true     // 顶部盾牌
    var buttonGradient: Bool = true // 按钮渐变（关掉=纯主色）

    // 图片（存相对路径或全 URL，空 = 用启动视频定格）
    var background: String = ""
    var logo: String = ""

    // ============================================================
    // v32.0 · 卡密弹窗模板体系
    // ------------------------------------------------------------
    // style = 内置 20 套里的一个 id（neon / glass / minimal …），
    //         或 "custom"（下面那组字段全权生效，后台随便调）。
    // 面板「浪神卡密 → 弹窗模板」选一套保存 → 写 license-theme.json，
    // App 拉到就换；也能直接上传模板 JSON 文件覆盖。
    // ============================================================
    var style: String = "neon"

    // 仅 style = custom 时生效
    var layout: String = "card"          // card / bare / band / stripe / split / terminal
    var fieldShape: String = "rounded"   // rounded / pill / rect / underline
    var buttonShape: String = "rounded"  // pill / rounded / rect / outline
    var decor: String = "shield"         // shield / lock / ring / grid / dots / none
    var light: Bool = false              // 浅色版式（文字自动转深色）
    var cardAlpha: Double = 0.10         // 卡片底色不透明度
    var mono: Bool = false               // 等宽字体
    var alignLeft: Bool = false          // 左对齐（默认居中）
    var bgTop: String = ""               // 背景三段色，空 = 用版式默认
    var bgMid: String = ""
    var bgBottom: String = ""

    enum CodingKeys: String, CodingKey {
        case version, title, subtitle, section, fieldLabel, placeholder, button, footer, copyright
        case primary, secondary, accent, inputText, dim, corner, showShield, buttonGradient
        case background, logo
        case style, layout, fieldShape, buttonShape, decor, light, cardAlpha, mono, alignLeft
        case bgTop, bgMid, bgBottom
    }

    init() {}

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        let d = LicenseTheme()
        func str(_ k: CodingKeys, _ fb: String) -> String {
            let v = try? c.decode(String.self, forKey: k)
            return (v?.isEmpty == false) ? v! : fb
        }
        version         = (try? c.decode(Int.self, forKey: .version)) ?? d.version
        title           = str(.title, d.title)
        subtitle        = str(.subtitle, d.subtitle)
        section         = str(.section, d.section)
        fieldLabel      = str(.fieldLabel, d.fieldLabel)
        placeholder     = str(.placeholder, d.placeholder)
        button          = str(.button, d.button)
        footer          = str(.footer, d.footer)
        copyright       = str(.copyright, d.copyright)
        primary         = str(.primary, d.primary)
        secondary       = str(.secondary, d.secondary)
        accent          = str(.accent, d.accent)
        inputText       = str(.inputText, d.inputText)
        dim             = (try? c.decode(Double.self, forKey: .dim)) ?? d.dim
        corner          = (try? c.decode(Double.self, forKey: .corner)) ?? d.corner
        showShield      = (try? c.decode(Bool.self, forKey: .showShield)) ?? d.showShield
        buttonGradient  = (try? c.decode(Bool.self, forKey: .buttonGradient)) ?? d.buttonGradient
        background      = (try? c.decode(String.self, forKey: .background)) ?? ""
        logo            = (try? c.decode(String.self, forKey: .logo)) ?? ""
        // v32.0 · 模板
        let rawStyle = (try? c.decode(String.self, forKey: .style)) ?? ""
        style = LicenseStyleBook.isKnown(rawStyle) ? rawStyle : "neon"
        layout          = str(.layout, d.layout)
        fieldShape      = str(.fieldShape, d.fieldShape)
        buttonShape     = str(.buttonShape, d.buttonShape)
        decor           = str(.decor, d.decor)
        light           = (try? c.decode(Bool.self, forKey: .light)) ?? d.light
        cardAlpha       = min(0.92, max(0.0, (try? c.decode(Double.self, forKey: .cardAlpha)) ?? d.cardAlpha))
        mono            = (try? c.decode(Bool.self, forKey: .mono)) ?? d.mono
        alignLeft       = (try? c.decode(Bool.self, forKey: .alignLeft)) ?? d.alignLeft
        bgTop           = (try? c.decode(String.self, forKey: .bgTop)) ?? ""
        bgMid           = (try? c.decode(String.self, forKey: .bgMid)) ?? ""
        bgBottom        = (try? c.decode(String.self, forKey: .bgBottom)) ?? ""
        // 兜底：颜色格式不对就用默认，别让整页变透明
        if LSThemeColor.rgb(primary) == nil { primary = d.primary }
        if LSThemeColor.rgb(secondary) == nil { secondary = d.secondary }
        if LSThemeColor.rgb(accent) == nil { accent = d.accent }
        if LSThemeColor.rgb(inputText) == nil { inputText = d.inputText }
        dim = min(0.95, max(0.15, dim))
        corner = min(40, max(8, corner))
    }
}

/// #RRGGBB / #RGB → RGB(0–1)
enum LSThemeColor {
    static func rgb(_ hex: String) -> (Double, Double, Double)? {
        var s = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        if s.hasPrefix("#") { s.removeFirst() }
        if s.count == 3 {
            s = s.map { "\($0)\($0)" }.joined()
        }
        guard s.count == 6, let v = UInt32(s, radix: 16) else { return nil }
        return (Double((v >> 16) & 0xFF) / 255.0,
                Double((v >> 8) & 0xFF) / 255.0,
                Double(v & 0xFF) / 255.0)
    }

    static func color(_ hex: String, fallback: Color) -> Color {
        guard let c = rgb(hex) else { return fallback }
        return Color(red: c.0, green: c.1, blue: c.2)
    }
}

/// 不给这个类打 @MainActor：SwiftUI 里 @StateObject 的默认值在非隔离上下文求值，
/// 打了标注反而会在某些 Xcode 版本上报 "main actor-isolated initializer" 的错。
/// 所有 @Published 赋值都显式回到主线程。
final class LicenseThemeStore: ObservableObject {
    static let shared = LicenseThemeStore()

    /// ============================================================
    /// v32.0 · 模板地址自动找
    /// ------------------------------------------------------------
    /// 依次试：
    ///   1. 老后台的 api/license-theme.json
    ///   2. 「浪神卡密」面板的 langshen/api/theme.php（v32 新增）
    /// 哪个先回就用哪个；都拉不到就用本机缓存，不影响使用。
    /// ============================================================
    static let siteBase = "https://ek.x8iu.com"
    static let endpoints: [String] = [
        "https://ek.x8iu.com/api/license-theme.json",
        "https://ek.x8iu.com/langshen/api/theme.php"
    ]
    /// 兼容旧引用
    static var endpoint: String { endpoints[0] }

    @Published private(set) var theme: LicenseTheme = LicenseTheme()
    @Published private(set) var backgroundImage: UIImage?
    @Published private(set) var logoImage: UIImage?

    private let kTheme = "ls.theme.json"
    private let kBg = "ls.theme.bg"
    private let kLogo = "ls.theme.logo"
    private var refreshing = false

    private init() {
        loadCache()
    }

    // MARK: - 本机缓存

    private func loadCache() {
        if let data = UserDefaults.standard.data(forKey: kTheme),
           let cached = try? JSONDecoder().decode(LicenseTheme.self, from: data) {
            theme = cached
        }
        if let path = UserDefaults.standard.string(forKey: kBg) {
            backgroundImage = UIImage(contentsOfFile: path)
        }
        if let path = UserDefaults.standard.string(forKey: kLogo) {
            logoImage = UIImage(contentsOfFile: path)
        }
    }

    private func cacheDir() -> URL {
        let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("LSTheme", isDirectory: true)
        if !FileManager.default.fileExists(atPath: dir.path) {
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir
    }

    // MARK: - 拉最新

    /// 进卡密页时调一次；失败就继续用缓存，不弹任何错
    func refresh() async {
        guard !refreshing else { return }
        refreshing = true
        defer { refreshing = false }

        // 逐个地址试，第一个拿到有效模板的就用
        var payload: Data?
        for ep in Self.endpoints {
            guard let url = URL(string: ep) else { continue }
            var req = URLRequest(url: url)
            req.timeoutInterval = 8
            req.cachePolicy = .reloadIgnoringLocalCacheData
            req.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
            if let (data, resp) = try? await URLSession.shared.data(for: req),
               let http = resp as? HTTPURLResponse,
               (200...299).contains(http.statusCode),
               !data.isEmpty,
               Self.decode(data) != nil {
                payload = data
                break
            }
        }

        guard let data = payload, let incoming = Self.decode(data) else { return }

        // 同一版就不重复写盘 / 重复下图片
        let current = await MainActor.run { self.theme }
        if incoming == current {
            await syncImages(theme: incoming, force: false)
            return
        }

        await MainActor.run { self.theme = incoming }
        if let encoded = try? JSONEncoder().encode(incoming) {
            UserDefaults.standard.set(encoded, forKey: kTheme)
        }
        await syncImages(theme: incoming, force: true)
    }

    /// 兼容两种返回：{"ok":true,"theme":{...}} 或 {"version":...}
    private static func decode(_ data: Data) -> LicenseTheme? {
        struct Envelope: Codable { var theme: LicenseTheme? }
        if let env = try? JSONDecoder().decode(Envelope.self, from: data), let t = env.theme {
            return t
        }
        return try? JSONDecoder().decode(LicenseTheme.self, from: data)
    }

    private func absolute(_ path: String) -> URL? {
        let p = path.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !p.isEmpty else { return nil }
        if p.lowercased().hasPrefix("http") { return URL(string: p) }
        let base = Self.siteBase
        let tail = p.hasPrefix("/") ? p : "/" + p
        return URL(string: base + tail)
    }

    private func syncImages(theme t: LicenseTheme, force: Bool) async {
        let dir = cacheDir()

        var newBG: UIImage?
        var clearBG = false

        if let url = absolute(t.background) {
            let file = dir.appendingPathComponent("bg-\(t.version).jpg")
            if force || !FileManager.default.fileExists(atPath: file.path) {
                if let (img, _) = try? await fetchImage(url), let data = img.jpegData(compressionQuality: 0.92) {
                    try? data.write(to: file)
                    UserDefaults.standard.set(file.path, forKey: kBg)
                    newBG = img
                }
            } else if backgroundImage == nil {
                newBG = UIImage(contentsOfFile: file.path)
            }
        } else if t.background.isEmpty {
            // 后台把背景图清了 → 回到「启动视频定格」那一版
            clearBG = true
            UserDefaults.standard.removeObject(forKey: kBg)
        }
        // 配了但下载失败：保留缓存那张，别清空

        var newLogo: UIImage?
        var clearLogo = false

        if let url = absolute(t.logo) {
            let file = dir.appendingPathComponent("logo-\(t.version).png")
            if force || !FileManager.default.fileExists(atPath: file.path) {
                if let (img, _) = try? await fetchImage(url) {
                    try? img.pngData()?.write(to: file)
                    UserDefaults.standard.set(file.path, forKey: kLogo)
                    newLogo = img
                }
            } else if logoImage == nil {
                newLogo = UIImage(contentsOfFile: file.path)
            }
        } else {
            clearLogo = true
            UserDefaults.standard.removeObject(forKey: kLogo)
        }

        await MainActor.run {
            if clearBG { self.backgroundImage = nil }
            if let newBG { self.backgroundImage = newBG }
            if clearLogo { self.logoImage = nil }
            if let newLogo { self.logoImage = newLogo }
        }
    }

    private func fetchImage(_ url: URL) async throws -> (UIImage, Data) {
        var req = URLRequest(url: url)
        req.timeoutInterval = 12
        req.cachePolicy = .reloadIgnoringLocalCacheData
        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse, (200...299).contains(http.statusCode),
              let img = UIImage(data: data) else {
            throw URLError(.cannotDecodeContentData)
        }
        return (img, data)
    }
}

// ============================================================
// v32.0 · 卡密弹窗模板库
// ------------------------------------------------------------
// 20 套内置风格，每套的版式骨架、输入框形状、按钮形状、装饰、明暗
// 都不一样 —— 不是只换颜色。第 21 种 custom 由后台逐项调。
// 面板「浪神卡密 → 弹窗模板」里点一下就能切，App 这边无需重编。
// ============================================================

enum LSLayoutKind: String {
    case card       // 整块信息装在一张卡片里
    case bare       // 不套卡片，元素直接铺在背景上
    case band       // 顶部色带 / 下面浅色内容区（原生设置风）
    case stripe     // 左侧竖条 + 右侧内容
    case split      // 标题区与表单区上下分离
    case terminal   // 命令行风，等宽、左对齐、下划线输入框
}

enum LSFieldKind: String {
    case rounded    // 圆角矩形
    case pill       // 胶囊
    case rect       // 直角方块
    case underline  // 只有一条底线
}

enum LSButtonKind: String {
    case pill
    case rounded
    case rect
    case outline    // 描边镂空
}

enum LSDecorKind: String {
    case shield, lock, ring, grid, dots, none
}

struct LicenseStylePreset {
    var id: String
    var name: String
    var layout: LSLayoutKind = .card
    var field: LSFieldKind = .rounded
    var button: LSButtonKind = .rounded
    var decor: LSDecorKind = .shield
    var light = false
    var cardAlpha: Double = 0.10
    var mono = false
    var alignLeft = false
    var corner: CGFloat = 28
    var grad = true
    var primary = ""
    var secondary = ""
    var accent = ""
    var bgTop = ""
    var bgMid = ""
    var bgBottom = ""
}

struct LicenseSkin {
    var layout: LSLayoutKind
    var field: LSFieldKind
    var button: LSButtonKind
    var decor: LSDecorKind
    var light: Bool
    var cardAlpha: Double
    var mono: Bool
    var alignLeft: Bool
    var corner: CGFloat
    var grad: Bool
    var accent: Color
    var accent2: Color
    var accent3: Color
    var ink: Color
    var ink2: Color
    var ink3: Color
    var fieldFill: Color
    var fieldText: Color
    var cardFill: Color
    var cardStroke: Color
    var bgTop: Color
    var bgMid: Color
    var bgBottom: Color
    var bgIsLight: Bool
}

enum LicenseStyleBook {

    /// 20 套内置风格
    static let presets: [LicenseStylePreset] = [
        LicenseStylePreset(id: "neon", name: "霓虹深绿",
                           layout: .card, field: .rounded, button: .rounded, decor: .shield,
                           cardAlpha: 0.09,
                           primary: "#29EB85", secondary: "#12A38F", accent: "#8F70F5",
                           bgTop: "#08211A", bgMid: "#04120F", bgBottom: "#010708"),

        LicenseStylePreset(id: "glass", name: "毛玻璃",
                           layout: .card, field: .pill, button: .pill, decor: .none,
                           cardAlpha: 0.16, corner: 34,
                           primary: "#7FE3FF", secondary: "#3E8BFF", accent: "#B39DFF",
                           bgTop: "#0B2540", bgMid: "#07182B", bgBottom: "#030A14"),

        LicenseStylePreset(id: "minimal", name: "极简白卡",
                           layout: .band, field: .rect, button: .rect, decor: .none,
                           light: true, cardAlpha: 1.0, alignLeft: true, corner: 12, grad: false,
                           primary: "#111111", secondary: "#3A3A3A", accent: "#111111",
                           bgTop: "#F7F7F8", bgMid: "#F2F2F3", bgBottom: "#EDEDEF"),

        LicenseStylePreset(id: "cyber", name: "赛博斜切",
                           layout: .stripe, field: .rect, button: .rect, decor: .grid,
                           cardAlpha: 0.12, alignLeft: true, corner: 6,
                           primary: "#00F0FF", secondary: "#FF2E9A", accent: "#FF2E9A",
                           bgTop: "#12002A", bgMid: "#0A0020", bgBottom: "#04000C"),

        LicenseStylePreset(id: "ticket", name: "票券式",
                           layout: .card, field: .rounded, button: .rounded, decor: .dots,
                           cardAlpha: 0.13, corner: 22,
                           primary: "#F5C86B", secondary: "#C79A3E", accent: "#8BE0C0",
                           bgTop: "#241A08", bgMid: "#170F04", bgBottom: "#0A0502"),

        LicenseStylePreset(id: "badge", name: "徽章居中",
                           layout: .bare, field: .rounded, button: .pill, decor: .shield,
                           cardAlpha: 0.0, corner: 30,
                           primary: "#C4A1FF", secondary: "#7A57D1", accent: "#FF9AD5",
                           bgTop: "#1A1030", bgMid: "#100A20", bgBottom: "#06030E"),

        LicenseStylePreset(id: "locked", name: "保险柜",
                           layout: .bare, field: .rounded, button: .rounded, decor: .lock,
                           cardAlpha: 0.0, corner: 24,
                           primary: "#8FA8FF", secondary: "#5A6FD6", accent: "#8FA8FF",
                           bgTop: "#0A1230", bgMid: "#060B1E", bgBottom: "#02040C"),

        LicenseStylePreset(id: "gradient", name: "渐变大球",
                           layout: .card, field: .pill, button: .pill, decor: .ring,
                           cardAlpha: 0.10, corner: 32,
                           primary: "#FF9A5B", secondary: "#FF5A7E", accent: "#FFD166",
                           bgTop: "#2A0F14", bgMid: "#1B0910", bgBottom: "#0A0306"),

        LicenseStylePreset(id: "pixel", name: "像素方块",
                           layout: .bare, field: .rect, button: .rect, decor: .grid,
                           cardAlpha: 0.0, mono: true, corner: 2, grad: false,
                           primary: "#00E676", secondary: "#00B25A", accent: "#B2FF59",
                           bgTop: "#07140C", bgMid: "#04100A", bgBottom: "#000602"),

        LicenseStylePreset(id: "gold", name: "黑金",
                           layout: .card, field: .rounded, button: .rect, decor: .ring,
                           cardAlpha: 0.10, corner: 14,
                           primary: "#E8C46A", secondary: "#A8863A", accent: "#FFF0B8",
                           bgTop: "#14110A", bgMid: "#0C0A05", bgBottom: "#040301"),

        LicenseStylePreset(id: "ice", name: "冰蓝",
                           layout: .card, field: .pill, button: .rounded, decor: .none,
                           cardAlpha: 0.14, corner: 26,
                           primary: "#8AD8FF", secondary: "#4FA8E0", accent: "#D6F2FF",
                           bgTop: "#0B1E2E", bgMid: "#061420", bgBottom: "#020810"),

        LicenseStylePreset(id: "sunset", name: "落日",
                           layout: .split, field: .rounded, button: .pill, decor: .none,
                           cardAlpha: 0.10, corner: 28,
                           primary: "#FF8A4C", secondary: "#C9482A", accent: "#FFC48A",
                           bgTop: "#2B0E08", bgMid: "#1A0705", bgBottom: "#0A0202"),

        LicenseStylePreset(id: "paper", name: "纸质表单",
                           layout: .band, field: .underline, button: .rect, decor: .none,
                           light: true, cardAlpha: 1.0, alignLeft: true, corner: 8, grad: false,
                           primary: "#1C1C1C", secondary: "#5A5A5A", accent: "#1C1C1C",
                           bgTop: "#FBF8F1", bgMid: "#F4EFE3", bgBottom: "#EAE3D4"),

        LicenseStylePreset(id: "terminal", name: "终端",
                           layout: .terminal, field: .underline, button: .rect, decor: .none,
                           cardAlpha: 0.0, mono: true, alignLeft: true, corner: 4, grad: false,
                           primary: "#39FF88", secondary: "#1EA85C", accent: "#39FF88",
                           bgTop: "#00130A", bgMid: "#000C06", bgBottom: "#000402"),

        LicenseStylePreset(id: "capsule", name: "胶囊",
                           layout: .bare, field: .pill, button: .pill, decor: .dots,
                           cardAlpha: 0.0, corner: 40,
                           primary: "#5EEAD4", secondary: "#14B8A6", accent: "#A7F3D0",
                           bgTop: "#062522", bgMid: "#041614", bgBottom: "#010706"),

        LicenseStylePreset(id: "stripe", name: "红竖条",
                           layout: .stripe, field: .rounded, button: .rounded, decor: .none,
                           cardAlpha: 0.09, alignLeft: true, corner: 18,
                           primary: "#FF5A5A", secondary: "#C42B3A", accent: "#FF9AA2",
                           bgTop: "#1E0A0C", bgMid: "#12060A", bgBottom: "#060203"),

        LicenseStylePreset(id: "split", name: "上下分离",
                           layout: .split, field: .rounded, button: .rounded, decor: .shield,
                           cardAlpha: 0.11, corner: 24,
                           primary: "#6FB4FF", secondary: "#2F73D9", accent: "#6FE0FF",
                           bgTop: "#08182E", bgMid: "#050F1E", bgBottom: "#01050C"),

        LicenseStylePreset(id: "halo", name: "光环",
                           layout: .bare, field: .pill, button: .pill, decor: .ring,
                           cardAlpha: 0.0, corner: 36,
                           primary: "#F2D06B", secondary: "#9BC463", accent: "#9BC463",
                           bgTop: "#141C08", bgMid: "#0B1105", bgBottom: "#030602"),

        LicenseStylePreset(id: "native", name: "原生设置风",
                           layout: .band, field: .rect, button: .rect, decor: .none,
                           light: true, cardAlpha: 1.0, alignLeft: true, corner: 10, grad: false,
                           primary: "#0A84FF", secondary: "#5C5C60", accent: "#0A84FF",
                           bgTop: "#F2F2F7", bgMid: "#F2F2F7", bgBottom: "#E9E9EE"),

        LicenseStylePreset(id: "aurora", name: "极光",
                           layout: .card, field: .rounded, button: .pill, decor: .grid,
                           cardAlpha: 0.12, corner: 30,
                           primary: "#5CFFC8", secondary: "#3FA9FF", accent: "#B36BFF",
                           bgTop: "#0A1B2A", bgMid: "#0A0F26", bgBottom: "#03030F")
    ]

    static let customName = "自定义"

    static func isKnown(_ id: String) -> Bool {
        let s = id.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if s == "custom" { return true }
        return presets.contains { $0.id == s }
    }

    static func preset(_ id: String) -> LicenseStylePreset? {
        let s = id.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return presets.first { $0.id == s }
    }

    static func name(_ id: String) -> String {
        preset(id)?.name ?? customName
    }

    /// 把后台下发的一套主题，翻译成真正拿来渲染的皮肤
    static func skin(for t: LicenseTheme) -> LicenseSkin {
        let p = preset(t.style)

        func pick(_ presetValue: String, _ themeValue: String, _ fallback: String) -> String {
            if !presetValue.isEmpty { return presetValue }
            if !themeValue.isEmpty { return themeValue }
            return fallback
        }

        let c1 = pick(p?.primary ?? "", t.primary, "#29EB85")
        let c2 = pick(p?.secondary ?? "", t.secondary, "#12A38F")
        let c3 = pick(p?.accent ?? "", t.accent, "#8F70F5")

        let accent  = LSThemeColor.color(c1, fallback: Color(red: 0.16, green: 0.92, blue: 0.52))
        let accent2 = LSThemeColor.color(c2, fallback: Color(red: 0.07, green: 0.64, blue: 0.56))
        let accent3 = LSThemeColor.color(c3, fallback: Color(red: 0.56, green: 0.44, blue: 0.96))

        // custom 时候全听后台的；内置模板则以后台显式给的 layout 覆盖为空表示用预设
        let isCustom = (t.style.lowercased() == "custom")

        func kind<T: RawRepresentable>(_ raw: String, _ fallback: T) -> T where T.RawValue == String {
            T(rawValue: raw) ?? fallback
        }

        let layout: LSLayoutKind = isCustom
            ? kind(t.layout, LSLayoutKind.card)
            : (p?.layout ?? LSLayoutKind.card)
        let field: LSFieldKind = isCustom
            ? kind(t.fieldShape, LSFieldKind.rounded)
            : (p?.field ?? LSFieldKind.rounded)
        let button: LSButtonKind = isCustom
            ? kind(t.buttonShape, LSButtonKind.rounded)
            : (p?.button ?? LSButtonKind.rounded)
        let decorRaw = isCustom ? t.decor : (p?.decor.rawValue ?? "shield")
        let decor: LSDecorKind = kind(decorRaw, LSDecorKind.shield)

        let light = isCustom ? t.light : (p?.light ?? false)
        let cardAlpha = isCustom ? t.cardAlpha : (p?.cardAlpha ?? 0.10)
        let mono = isCustom ? t.mono : (p?.mono ?? false)
        let alignLeft = isCustom ? t.alignLeft : (p?.alignLeft ?? false)
        let corner = isCustom ? CGFloat(t.corner) : (p?.corner ?? CGFloat(t.corner))
        let grad = isCustom ? t.buttonGradient : (p?.grad ?? true)

        let ink  = light ? Color(red: 0.07, green: 0.07, blue: 0.08) : Color.white
        let ink2 = light ? Color(red: 0.36, green: 0.36, blue: 0.39) : Color.white.opacity(0.62)
        let ink3 = light ? Color(red: 0.52, green: 0.52, blue: 0.55) : Color.white.opacity(0.40)

        let fieldFill: Color = light ? Color(red: 0.95, green: 0.95, blue: 0.96) : Color.white.opacity(0.94)
        let fieldText: Color = LSThemeColor.color(t.inputText, fallback: Color(red: 0.10, green: 0.10, blue: 0.11))

        let cardFill: Color = light
            ? Color.white.opacity(max(0.55, cardAlpha))
            : Color.white.opacity(cardAlpha)
        let cardStroke: Color = light
            ? Color.black.opacity(0.08)
            : Color.white.opacity(0.12)

        let dBT = LightOrDark(light: light)
        let bgTopColor    = LSThemeColor.color(pick(p?.bgTop ?? "", t.bgTop, dBT.top),    fallback: dBT.topColor)
        let bgMidColor    = LSThemeColor.color(pick(p?.bgMid ?? "", t.bgMid, dBT.mid),    fallback: dBT.midColor)
        let bgBottomColor = LSThemeColor.color(pick(p?.bgBottom ?? "", t.bgBottom, dBT.bottom), fallback: dBT.bottomColor)

        return LicenseSkin(
            layout: layout,
            field: field,
            button: button,
            decor: decor,
            light: light,
            cardAlpha: cardAlpha,
            mono: mono,
            alignLeft: alignLeft,
            corner: corner,
            grad: grad,
            accent: accent,
            accent2: accent2,
            accent3: accent3,
            ink: ink,
            ink2: ink2,
            ink3: ink3,
            fieldFill: fieldFill,
            fieldText: fieldText,
            cardFill: cardFill,
            cardStroke: cardStroke,
            bgTop: bgTopColor,
            bgMid: bgMidColor,
            bgBottom: bgBottomColor,
            bgIsLight: light
        )
    }

    /// 默认背景色（浅色版式 / 深色版式各一套）
    private struct LightOrDark {
        let top: String
        let mid: String
        let bottom: String
        var topColor: Color { LSThemeColor.color(top, fallback: Color(red: 0.03, green: 0.13, blue: 0.10)) }
        var midColor: Color { LSThemeColor.color(mid, fallback: Color(red: 0.01, green: 0.06, blue: 0.06)) }
        var bottomColor: Color { LSThemeColor.color(bottom, fallback: Color(red: 0.00, green: 0.02, blue: 0.03)) }
        init(light: Bool) {
            if light {
                top = "#F7F7F8"; mid = "#F2F2F3"; bottom = "#EDEDEF"
            } else {
                top = "#08211A"; mid = "#04120F"; bottom = "#010708"
            }
        }
    }
}
