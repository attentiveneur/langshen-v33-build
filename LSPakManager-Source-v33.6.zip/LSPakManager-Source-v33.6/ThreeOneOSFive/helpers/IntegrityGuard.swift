//
//  IntegrityGuard.swift
//  OGIOS
//
//  v33.5 · 二进制自校验（防篡改）— 观察模式
//
//  v33.4 的教训：判定不过就直接把进程弄死，结果正常安装也被判成改过，
//  一装就闪退、连自己哪儿错了都看不到。这一版改成：
//
//    1. 照旧算摘要、照旧比对，但【不杀进程】；
//    2. 把算出来的东西全写进一份自检报告，界面上点一下就能看；
//    3. 硬崩的开关留着（hardKillEnabled），等自检把误判原因定位清楚再打开。
//
//  为什么重签不受影响：
//    摘要只覆盖 __TEXT 段里的四个 section，不碰 mach_header / load commands /
//    代码签名区，所以换证书重签、改 Bundle ID、换显示名都不会影响结果。
//
//  注意：sealToken 的写法、长度、掩码、校验顺序必须与 Tools/stamp_integrity.py 完全一致。
//

import Foundation
import Darwin
import MachO

enum LSIntegrity {

    // MARK: - 印章槽（长度 / 结构必须与盖章脚本一致）

    /// 编译期占位；流水线会把中间 64 个 0 换成真实摘要。
    /// 这个字符串必须被代码真实引用，否则会被编译器丢掉。
    static let sealToken = "LSINTG<0000000000000000000000000000000000000000000000000000000000000000>IGNTSL"

    static let openTag  = "LSINTG<"
    static let closeTag = ">IGNTSL"
    static let hexCount = 64
    static let sealLength = 78          // 7 + 64 + 7

    /// 参与校验的 section（顺序固定，脚本端同样顺序）
    static let watchedSections = ["__text", "__cstring", "__const", "__ustring"]

    /// v33.5 · 硬崩开关。
    /// 先关着：保证任何情况下 App 都能正常打开，判定结果只进报告。
    /// 等自检把「为什么会误判」查清楚，再把它改成 true。
    static let hardKillEnabled = false

    /// 32 字节掩码：槽里存的不是明文摘要，是摘要 XOR 掩码 XOR 位置扰动。
    private static let mask: [UInt8] = [
        0x3A, 0x91, 0x07, 0xCE, 0x64, 0x2B, 0xF8, 0x15,
        0xAC, 0x58, 0xE3, 0x76, 0x0D, 0xB2, 0x4F, 0xC9,
        0x81, 0x36, 0xDD, 0x1A, 0x97, 0x40, 0x6B, 0xE5,
        0x28, 0x73, 0xBC, 0x0F, 0xD4, 0x69, 0x92, 0x5E
    ]

    // MARK: - 报告

    struct Report {
        var sealFound = false
        var sealLocation = "-"
        var storedHex = "-"
        var computedHex = "-"
        var digestMatch = false
        var debuggerAttached = false
        var injectedHits: [String] = []
        var foreignImages: [String] = []
        var slideValue = 0
        var imageCount = 0
        var sectionCount = 0
        var sectionSummary = "-"
        var problem = ""

        /// 只有三件事全部正常才算「没被改过」
        var clean: Bool {
            sealFound && digestMatch && !debuggerAttached && injectedHits.isEmpty
        }
    }

    // MARK: - 状态

    private static let lock = NSLock()
    private static var cached: Report?

    /// 文档目录里那份报告的路径（有就写，写不进也不影响启动）
    static var reportFileURL: URL? {
        guard let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            return nil
        }
        return dir.appendingPathComponent("安全自检.txt")
    }

    // MARK: - 对外

    /// App 一起来就在后台算一次，绝不挡首帧，也绝不杀进程。
    static func warmUp() {
        // 真实引用印章常量，确保它不会被编译器丢掉
        _ = sealToken.utf8.count
        DispatchQueue.global(qos: .utility).async {
            _ = snapshot()
            if let url = reportFileURL {
                try? diagnosticText().write(to: url, atomically: true, encoding: .utf8)
            }
        }
    }

    /// 关键路径埋点。观察模式下只确保报告算过一次，不做任何拦截。
    @inline(never)
    static func enforce(_ site: String) {
        guard hardKillEnabled else { return }
        let report = snapshot()
        if report.clean { return }
        compromised = true
        terminate()
    }

    /// 是否已判定被改过（观察模式下仅供参考，不触发任何行为）
    private(set) static var compromised = false

    /// 只问不杀，给自检面板用
    static func isIntact() -> Bool { snapshot().clean }

    // MARK: - 单例式的报告缓存

    static func snapshot() -> Report {
        lock.lock()
        if let ready = cached {
            lock.unlock()
            return ready
        }
        lock.unlock()

        let fresh = evaluate()

        lock.lock()
        if cached == nil { cached = fresh }
        let final = cached ?? fresh
        lock.unlock()

        if !final.clean { compromised = true }
        return final
    }

    /// 给界面用的一段纯文本
    static func diagnosticText() -> String {
        let r = snapshot()
        var lines: [String] = []
        lines.append("浪神 · 安全自检")
        lines.append("")
        lines.append("结论：" + (r.clean ? "正常，程序没被改过" : "异常：" + (r.problem.isEmpty ? "原因不明" : r.problem)))
        lines.append("")
        lines.append("印章槽：" + (r.sealFound ? "找到了（" + r.sealLocation + "）" : "没找到"))
        lines.append("包里的值：" + r.storedHex)
        lines.append("运行时值：" + r.computedHex)
        lines.append("两者一致：" + (r.digestMatch ? "是" : "不是"))
        lines.append("")
        lines.append("调试器：" + (r.debuggerAttached ? "有" : "没有"))
        lines.append("可疑注入：" + (r.injectedHits.isEmpty ? "没有" : r.injectedHits.joined(separator: "，")))
        lines.append("")
        lines.append("镜像数：" + String(r.imageCount))
        lines.append("程序基址偏移：" + String(r.slideValue))
        lines.append("__TEXT 段数：" + String(r.sectionCount))
        lines.append("段大小：" + r.sectionSummary)
        if !r.foreignImages.isEmpty {
            lines.append("")
            lines.append("非系统镜像：")
            for name in r.foreignImages { lines.append("  " + name) }
        }
        lines.append("")
        lines.append("硬干模式：" + (hardKillEnabled ? "已开启" : "关闭（这版只记录，不闪退）"))
        return lines.joined(separator: "\n")
    }

    // MARK: - 判定

    private static func evaluate() -> Report {
        var report = Report()

        report.debuggerAttached = hasDebugger()
        report.injectedHits = injectedImages()
        report.imageCount = Int(_dyld_image_count())
        report.foreignImages = foreignImages()

        guard let image = selfImage() else {
            report.problem = "定位不到自己的主程序"
            return report
        }
        report.slideValue = image.slide

        var parts: [String] = []
        let seg = image.textSegment
        var cursor = UnsafeRawPointer(seg)
            .advanced(by: MemoryLayout<segment_command_64>.size)
            .assumingMemoryBound(to: section_64.self)
        for _ in 0..<Int(seg.pointee.nsects) {
            let section = cursor.pointee
            parts.append(fixedName(section.sectname) + ":" + String(section.size))
            cursor = cursor.advanced(by: 1)
        }
        report.sectionCount = Int(seg.pointee.nsects)
        report.sectionSummary = parts.joined(separator: " ")

        guard let sections = watchedSectionRefs(image) else {
            report.problem = "__TEXT 里没找到要校验的段"
            return report
        }
        guard let seal = locateSeal(in: image) else {
            report.problem = "包里找不到印章槽"
            return report
        }
        report.sealFound = true
        report.sealLocation = seal.location

        let stored = seal.hexBytes
        if stored.allSatisfy({ $0 == 0 }) {
            report.problem = "印章槽还是全零（没盖章）"
            return report
        }

        let expected = unmask(stored)
        let digest = computeDigest(sections: sections, skipping: seal.range)
        report.storedHex = expected.lsHex
        report.computedHex = digest.lsHex
        report.digestMatch = constantTimeEqual(digest, expected)

        if !report.digestMatch {
            report.problem = "运行时摘要和包里的对不上"
        }
        if report.debuggerAttached {
            report.problem = report.problem.isEmpty ? "检测到调试器" : report.problem + "；检测到调试器"
        }
        if !report.injectedHits.isEmpty {
            let extra = "检测到可疑注入"
            report.problem = report.problem.isEmpty ? extra : report.problem + "；" + extra
        }
        return report
    }

    // MARK: - 自身镜像解析

    private struct ImageInfo {
        let header: UnsafePointer<mach_header_64>
        let slide: Int
        let textSegment: UnsafePointer<segment_command_64>
    }

    private static func selfImage() -> ImageInfo? {
        // 主可执行文件必定是 image 0
        guard let raw = _dyld_get_image_header(0) else { return nil }
        let header = UnsafeRawPointer(raw).assumingMemoryBound(to: mach_header_64.self)
        guard header.pointee.magic == 0xfeedfacf else { return nil }   // MH_MAGIC_64

        var cursor = UnsafeRawPointer(header).advanced(by: MemoryLayout<mach_header_64>.size)
        var textSeg: UnsafePointer<segment_command_64>?

        for _ in 0..<Int(header.pointee.ncmds) {
            let cmd = cursor.assumingMemoryBound(to: load_command.self).pointee
            guard cmd.cmdsize >= UInt32(MemoryLayout<load_command>.size) else { break }
            if cmd.cmd == UInt32(LC_SEGMENT_64) {
                let seg = cursor.assumingMemoryBound(to: segment_command_64.self)
                if fixedName(seg.pointee.segname) == "__TEXT" { textSeg = seg }
            }
            cursor = cursor.advanced(by: Int(cmd.cmdsize))
        }
        guard let seg = textSeg else { return nil }
        return ImageInfo(header: header, slide: _dyld_get_image_vmaddr_slide(0), textSegment: seg)
    }

    private struct SectionBytes {
        let name: String
        let pointer: UnsafeRawPointer
        let size: Int
        let range: Range<UnsafeRawPointer>  // 运行时地址区间
    }

    private static func watchedSectionRefs(_ image: ImageInfo) -> [String: SectionBytes]? {
        var found: [String: SectionBytes] = [:]
        let seg = image.textSegment
        var sect = UnsafeRawPointer(seg).advanced(by: MemoryLayout<segment_command_64>.size)
            .assumingMemoryBound(to: section_64.self)

        for _ in 0..<Int(seg.pointee.nsects) {
            let s = sect.pointee
            let name = fixedName(s.sectname)
            if watchedSections.contains(name), s.size > 0 {
                let vm = UInt(s.addr) &+ UInt(bitPattern: image.slide)
                if let ptr = UnsafeRawPointer(bitPattern: vm) {
                    let size = Int(s.size)
                    found[name] = SectionBytes(name: name, pointer: ptr, size: size,
                                               range: ptr..<(ptr + size))
                }
            }
            sect = sect.advanced(by: 1)
        }
        return found.isEmpty ? nil : found
    }

    // MARK: - 印章定位

    private struct Seal {
        let hexBytes: [UInt8]      // 原始（已掩码）的 32 字节
        let range: Range<UnsafeRawPointer>
        let location: String
    }

    private static func locateSeal(in image: ImageInfo) -> Seal? {
        let openBytes = Array(openTag.utf8)
        let closeBytes = Array(closeTag.utf8)
        let span = sealLength
        let closeCount = closeBytes.count
        let openCount = openBytes.count

        let seg = image.textSegment
        var sect = UnsafeRawPointer(seg).advanced(by: MemoryLayout<segment_command_64>.size)
            .assumingMemoryBound(to: section_64.self)

        for _ in 0..<Int(seg.pointee.nsects) {
            let s = sect.pointee
            let name = fixedName(s.sectname)
            sect = sect.advanced(by: 1)
            guard s.size >= UInt64(span) else { continue }
            let vm = UInt(s.addr) &+ UInt(bitPattern: image.slide)
            guard let base = UnsafeRawPointer(bitPattern: vm) else { continue }
            let size = Int(s.size)
            let bytes = base.assumingMemoryBound(to: UInt8.self)

            var i = 0
            let last = size - span
            while i <= last {
                if bytes[i] == openBytes[0],
                   matches(bytes + i, openBytes),
                   matches(bytes + i + span - closeCount, closeBytes) {
                    let hexStart = i + openCount
                    var raw = [UInt8](repeating: 0, count: 32)
                    var ok = true
                    for b in 0..<32 {
                        guard let hi = hexValue(bytes[hexStart + b * 2]),
                              let lo = hexValue(bytes[hexStart + b * 2 + 1]) else {
                            ok = false
                            break
                        }
                        raw[b] = (hi << 4) | lo
                    }
                    if ok {
                        return Seal(hexBytes: raw,
                                    range: base..<(base + span),
                                    location: name + "+" + String(i))
                    }
                }
                i += 1
            }
        }
        return nil
    }

    // MARK: - 摘要

    private static func computeDigest(sections: [String: SectionBytes],
                                      skipping sealRange: Range<UnsafeRawPointer>) -> [UInt8] {
        var hasher = LSHA256()

        for name in watchedSections {
            guard let section = sections[name] else { continue }
            var lengthField = UInt64(section.size).littleEndian
            withUnsafeBytes(of: &lengthField) { hasher.update($0.baseAddress, count: 8) }

            let start = section.range.lowerBound
            let end = section.range.upperBound

            if sealRange.lowerBound >= start, sealRange.upperBound <= end {
                let before = start..<sealRange.lowerBound
                let after = sealRange.upperBound..<end
                hasher.update(before.lowerBound, count: before.count)
                hasher.update(after.lowerBound, count: after.count)
            } else {
                hasher.update(start, count: section.size)
            }
        }
        return hasher.finalize()
    }

    // MARK: - 掩码

    private static func unmask(_ raw: [UInt8]) -> [UInt8] {
        var out = [UInt8](repeating: 0, count: 32)
        for i in 0..<32 {
            out[i] = raw[i] ^ mask[i] ^ UInt8(truncatingIfNeeded: i &* 37 &+ 0x5A)
        }
        return out
    }

    // MARK: - 反调试 / 反注入

    private static func hasDebugger() -> Bool {
        var info = kinfo_proc()
        var size = MemoryLayout<kinfo_proc>.stride
        var mib: [Int32] = [CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid()]
        guard sysctl(&mib, UInt32(mib.count), &info, &size, nil, 0) == 0 else { return false }
        return (info.kp_proc.p_flag & P_TRACED) != 0
    }

    private static func injectedImages() -> [String] {
        var hits: [String] = []
        if let value = getenv("DYLD_INSERT_LIBRARIES"), String(cString: value).isEmpty == false {
            hits.append("环境变量注入")
        }
        let banned = ["MobileSubstrate", "CydiaSubstrate", "Substitute", "TweakInject",
                      "frida-agent", "libfrida", "libhooker", "ElleKit"]
        let count = _dyld_image_count()
        var i: UInt32 = 0
        while i < count {
            if let namePtr = _dyld_get_image_name(i) {
                let name = String(cString: namePtr)
                for tag in banned where name.contains(tag) {
                    hits.append(name)
                }
            }
            i += 1
        }
        return hits
    }

    /// 只用于自检报告：列出既不在系统目录、也不在自身 App 包里的镜像（最多 8 条）。
    private static func foreignImages() -> [String] {
        var out: [String] = []
        let mine = Bundle.main.bundlePath
        let count = _dyld_image_count()
        var i: UInt32 = 0
        while i < count {
            defer { i += 1 }
            guard let namePtr = _dyld_get_image_name(i) else { continue }
            let name = String(cString: namePtr)
            if name.hasPrefix("/System/") || name.hasPrefix("/usr/lib/") { continue }
            if !mine.isEmpty && name.hasPrefix(mine) { continue }
            out.append(name)
            if out.count >= 8 { break }
        }
        return out
    }

    // MARK: - 终止（只在硬干模式开启时才会走到）

    @inline(never)
    private static func terminate() {
        abort()
    }

    // MARK: - 小工具

    private static func constantTimeEqual(_ a: [UInt8], _ b: [UInt8]) -> Bool {
        guard a.count == b.count else { return false }
        var diff: UInt8 = 0
        for i in 0..<a.count { diff |= a[i] ^ b[i] }
        return diff == 0
    }

    private static func matches(_ lhs: UnsafePointer<UInt8>, _ rhs: [UInt8]) -> Bool {
        for i in 0..<rhs.count where lhs[i] != rhs[i] { return false }
        return true
    }

    private static func hexValue(_ c: UInt8) -> UInt8? {
        switch c {
        case 0x30...0x39: return c - 0x30
        case 0x61...0x66: return c - 0x61 + 10
        case 0x41...0x46: return c - 0x41 + 10
        default: return nil
        }
    }

    private static func fixedName<T>(_ tuple: T) -> String {
        var value = tuple
        return withUnsafeBytes(of: &value) { raw in
            guard let base = raw.baseAddress?.assumingMemoryBound(to: CChar.self) else { return "" }
            return String(cString: base)
        }
    }
}

extension Array where Element == UInt8 {
    /// 十六进制文本，供自检报告使用
    var lsHex: String {
        var out = ""
        out.reserveCapacity(count * 2)
        for byte in self { out += String(format: "%02x", byte) }
        return out
    }
}

// MARK: - SHA-256（自成一体，不依赖 CommonCrypto 桥接）

struct LSHA256 {
    private var h0: UInt32 = 0x6a09e667
    private var h1: UInt32 = 0xbb67ae85
    private var h2: UInt32 = 0x3c6ef372
    private var h3: UInt32 = 0xa54ff53a
    private var h4: UInt32 = 0x510e527f
    private var h5: UInt32 = 0x9b05688c
    private var h6: UInt32 = 0x1f83d9ab
    private var h7: UInt32 = 0x5be0cd19

    private var buffer = [UInt8](repeating: 0, count: 64)
    private var buffered = 0
    private var total: UInt64 = 0

    private static let k: [UInt32] = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    ]

    mutating func update(_ pointer: UnsafeRawPointer?, count: Int) {
        guard let pointer = pointer, count > 0 else { return }
        total &+= UInt64(count)
        let src = pointer.assumingMemoryBound(to: UInt8.self)
        var offset = 0
        while offset < count {
            if buffered == 64 {
                transform()
                buffered = 0
            }
            let take = min(64 - buffered, count - offset)
            let at = buffered
            buffer.withUnsafeMutableBytes { dst in
                memcpy(dst.baseAddress!.advanced(by: at), src.advanced(by: offset), take)
            }
            buffered += take
            offset += take
        }
    }

    mutating func update(_ bytes: [UInt8]) {
        bytes.withUnsafeBytes { update($0.baseAddress, count: $0.count) }
    }

    mutating func finalize() -> [UInt8] {
        let bitLength = total &* 8
        var pad: [UInt8] = [0x80]
        let padCount = (buffered < 56) ? (56 - buffered) : (120 - buffered)
        pad.append(contentsOf: [UInt8](repeating: 0, count: padCount - 1))
        update(pad)   // 只用于填充，bitLength 已在上面取走

        var lengthBytes = [UInt8](repeating: 0, count: 8)
        for i in 0..<8 { lengthBytes[7 - i] = UInt8(truncatingIfNeeded: bitLength >> (UInt64(i) * 8)) }
        for byte in lengthBytes {
            buffer[buffered] = byte
            buffered += 1
        }
        transform()
        buffered = 0

        var out = [UInt8]()
        out.reserveCapacity(32)
        for word in [h0, h1, h2, h3, h4, h5, h6, h7] {
            out.append(UInt8(truncatingIfNeeded: word >> 24))
            out.append(UInt8(truncatingIfNeeded: word >> 16))
            out.append(UInt8(truncatingIfNeeded: word >> 8))
            out.append(UInt8(truncatingIfNeeded: word))
        }
        return out
    }

    private mutating func transform() {
        var w = [UInt32](repeating: 0, count: 64)
        for i in 0..<16 {
            let j = i * 4
            w[i] = (UInt32(buffer[j]) << 24) | (UInt32(buffer[j + 1]) << 16)
                 | (UInt32(buffer[j + 2]) << 8) | UInt32(buffer[j + 3])
        }
        for i in 16..<64 {
            let s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >> 3)
            let s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >> 10)
            w[i] = w[i - 16] &+ s0 &+ w[i - 7] &+ s1
        }

        var a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7

        for i in 0..<64 {
            let s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)
            let ch = (e & f) ^ (~e & g)
            let temp1 = h &+ s1 &+ ch &+ LSHA256.k[i] &+ w[i]
            let s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)
            let maj = (a & b) ^ (a & c) ^ (b & c)
            let temp2 = s0 &+ maj

            h = g; g = f; f = e
            e = d &+ temp1
            d = c; c = b; b = a
            a = temp1 &+ temp2
        }

        h0 &+= a; h1 &+= b; h2 &+= c; h3 &+= d
        h4 &+= e; h5 &+= f; h6 &+= g; h7 &+= h
    }

    private func rotr(_ x: UInt32, _ n: UInt32) -> UInt32 {
        (x >> n) | (x << (32 - n))
    }
}
